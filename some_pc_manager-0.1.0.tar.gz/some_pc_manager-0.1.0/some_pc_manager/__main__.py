"""`python -m some_pc_manager` giriş noktası."""
import sys


def auto_clean() -> int:
    """Pencere açmadan güvenli kullanıcı önbelleklerini temizler (Depolama algılama zamanlayıcısı)."""
    from .core import cleaner
    from .core.store import Store
    from .core.util import format_size

    report = cleaner.run_cleanup(["tmp", "thumbnails", "browser_cache", "user_cache"], mode="boost")
    store = Store()
    store.add_cleaned(report.total_freed)
    print(f"Temizlendi: {format_size(report.total_freed)}")
    return 0


def main() -> int:
    if "--auto-clean" in sys.argv[1:]:
        return auto_clean()
    from .ui.app import main as run_gui
    return run_gui()


if __name__ == "__main__":
    sys.exit(main())
