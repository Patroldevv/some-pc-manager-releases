"""Some PC Manager — Linux için kompakt PC yönetim aracı."""
__version__ = "0.1.0"
