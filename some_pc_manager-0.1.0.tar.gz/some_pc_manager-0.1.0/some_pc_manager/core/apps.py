"""Çalışan ve yüklü uygulamalar (.desktop girdileri üzerinden)."""
from __future__ import annotations

import configparser
import os
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path

from .util import xdg_data_home

_PAGE = os.sysconf("SC_PAGE_SIZE")
_HZ = os.sysconf("SC_CLK_TCK")


@dataclass(frozen=True)
class DesktopEntry:
    id: str
    name: str
    exec_name: str
    icon: str
    comment: str
    path: str


@dataclass
class RunningApp:
    name: str
    icon: str
    pids: list[int] = field(default_factory=list)
    mem: int = 0
    cpu: float = 0.0


def application_dirs() -> list[Path]:
    dirs = [xdg_data_home() / "applications"]
    for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":"):
        if d:
            dirs.append(Path(d) / "applications")
    dirs += [Path("/var/lib/flatpak/exports/share/applications"),
             xdg_data_home() / "flatpak" / "exports" / "share" / "applications"]
    seen, out = set(), []
    for d in dirs:
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


def _first_exec_token(exec_line: str) -> str:
    parts = exec_line.split()
    i = 0
    if parts and Path(parts[0]).name == "env":
        i = 1
        while i < len(parts) and "=" in parts[i]:
            i += 1
    return Path(parts[i]).name.lower() if i < len(parts) else ""


def parse_desktop(path: Path, lang: str = "tr") -> tuple[DesktopEntry, dict] | None:
    cp = configparser.RawConfigParser(strict=False, interpolation=None)
    cp.optionxform = str  # type: ignore[assignment]
    try:
        cp.read_string(path.read_text(errors="replace"))
    except (OSError, configparser.Error):
        return None
    if not cp.has_section("Desktop Entry"):
        return None
    s = cp["Desktop Entry"]
    name = s.get(f"Name[{lang}]") or s.get("Name")
    if not name:
        return None
    entry = DesktopEntry(
        id=path.stem, name=name, exec_name=_first_exec_token(s.get("Exec", "")),
        icon=s.get("Icon", "application-x-executable"), comment=s.get(f"Comment[{lang}]") or s.get("Comment", ""),
        path=str(path),
    )
    flags = {
        "type": s.get("Type", ""),
        "nodisplay": s.get("NoDisplay", "false").lower() == "true",
        "hidden": s.get("Hidden", "false").lower() == "true",
    }
    return entry, flags


def installed_apps() -> list[DesktopEntry]:
    found: dict[str, DesktopEntry] = {}
    for d in application_dirs():
        if not d.is_dir():
            continue
        for p in sorted(d.glob("*.desktop")):
            if p.stem in found:
                continue
            parsed = parse_desktop(p)
            if not parsed:
                continue
            entry, flags = parsed
            if flags["type"] != "Application" or flags["nodisplay"] or flags["hidden"]:
                continue
            found[p.stem] = entry
    return sorted(found.values(), key=lambda e: e.name.lower())


def _read(path: str) -> str:
    try:
        with open(path, "rb") as f:
            return f.read().decode(errors="replace")
    except OSError:
        return ""


def _proc_names(pid: int) -> list[str]:
    """Süreci eşleştirmek için aday adlar: argv0, argv1 (yorumlayıcı) ve comm."""
    args = _read(f"/proc/{pid}/cmdline").split("\0")
    names = [Path(args[0]).name.lower()] if args and args[0] else []
    if len(args) > 1 and names and names[0].startswith(("python", "node", "java", "bash", "sh")):
        names.append(Path(args[1]).name.lower())
    comm = _read(f"/proc/{pid}/comm").strip().lower()
    if comm:
        names.append(comm)
    return names


def _cpu_ticks(pid: int) -> int:
    raw = _read(f"/proc/{pid}/stat")
    try:
        rest = raw[raw.rindex(")") + 2:].split()
        return int(rest[11]) + int(rest[12])   # utime + stime
    except (ValueError, IndexError):
        return 0


def _mem_bytes(pid: int) -> int:
    for line in _read(f"/proc/{pid}/smaps_rollup").splitlines():
        if line.startswith("Pss:"):
            return int(line.split()[1]) * 1024
    parts = _read(f"/proc/{pid}/statm").split()
    return int(parts[1]) * _PAGE if len(parts) > 1 else 0


class AppSampler:
    """Çalışan uygulamaları gruplar; CPU %'si iki örnek arasındaki farktan gelir."""

    def __init__(self) -> None:
        self._entries: dict[str, DesktopEntry] | None = None
        self._prev: dict[int, int] = {}
        self._prev_t = 0.0

    def _by_exec(self) -> dict[str, DesktopEntry]:
        if self._entries is None:
            m: dict[str, DesktopEntry] = {}
            for e in installed_apps():
                for key in {e.exec_name, e.id.split(".")[-1].lower()}:
                    if key:
                        m.setdefault(key, e)
            self._entries = m
        return self._entries

    def sample(self) -> list[RunningApp]:
        table = self._by_exec()
        me, uid = os.getpid(), os.getuid()
        now = time.monotonic()
        dt = now - self._prev_t if self._prev_t else 0.0
        ticks: dict[int, int] = {}
        apps: dict[str, RunningApp] = {}
        try:
            pids = [int(n) for n in os.listdir("/proc") if n.isdigit()]
        except OSError:
            return []
        for pid in pids:
            if pid == me:
                continue
            try:
                if os.stat(f"/proc/{pid}").st_uid != uid:
                    continue
            except OSError:
                continue
            entry = next((table[n] for n in _proc_names(pid) if n in table), None)
            if entry is None:
                continue
            app = apps.setdefault(entry.id, RunningApp(entry.name, entry.icon))
            t = _cpu_ticks(pid)
            ticks[pid] = t
            app.pids.append(pid)
            app.mem += _mem_bytes(pid)
            if dt > 0 and pid in self._prev:
                app.cpu += 100.0 * (t - self._prev[pid]) / (_HZ * dt)
        self._prev, self._prev_t = ticks, now
        return sorted(apps.values(), key=lambda a: a.mem, reverse=True)


def protected_pids() -> set[int]:
    """Kendimiz ve üst süreçlerimiz asla sonlandırılmaz."""
    pids = {os.getpid()}
    pid = os.getppid()
    while pid > 1:
        pids.add(pid)
        parts = _read(f"/proc/{pid}/stat")
        try:
            pid = int(parts[parts.rindex(")") + 2:].split()[1])
        except (ValueError, IndexError):
            break
    return pids


def terminate(app: RunningApp) -> int:
    """Uygulamanın süreçlerine SIGTERM gönderir; gönderilen süreç sayısını döndürür."""
    skip, uid, sent = protected_pids(), os.getuid(), 0
    for pid in app.pids:
        if pid in skip:
            continue
        try:
            if os.stat(f"/proc/{pid}").st_uid != uid:
                continue
            os.kill(pid, signal.SIGTERM)
            sent += 1
        except OSError:
            pass
    return sent
