"""Sistem ölçümleri. Yalnızca /proc, /sys ve standart kütüphane kullanır."""
from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass


@dataclass(frozen=True)
class Memory:
    total: int
    available: int

    @property
    def used(self) -> int:
        return self.total - self.available

    @property
    def percent(self) -> float:
        return 100.0 * self.used / self.total if self.total else 0.0


def parse_meminfo(text: str) -> Memory:
    values: dict[str, int] = {}
    for line in text.splitlines():
        m = re.match(r"(\w+):\s+(\d+)\s*kB", line)
        if m:
            values[m.group(1)] = int(m.group(2)) * 1024
    total = values.get("MemTotal", 0)
    avail = values.get("MemAvailable")
    if avail is None:  # çok eski çekirdekler
        avail = values.get("MemFree", 0) + values.get("Cached", 0) + values.get("Buffers", 0)
    return Memory(total, min(avail, total))


def parse_swap(text: str) -> tuple[int, int]:
    """/proc/meminfo -> (swap toplam, swap kullanılan) bayt."""
    vals: dict[str, int] = {}
    for line in text.splitlines():
        m = re.match(r"(Swap\w+):\s+(\d+)\s*kB", line)
        if m:
            vals[m.group(1)] = int(m.group(2)) * 1024
    total = vals.get("SwapTotal", 0)
    return total, max(0, total - vals.get("SwapFree", 0))


def swap() -> tuple[int, int]:
    try:
        with open("/proc/meminfo") as f:
            return parse_swap(f.read())
    except OSError:
        return 0, 0


def memory() -> Memory:
    try:
        with open("/proc/meminfo") as f:
            return parse_meminfo(f.read())
    except OSError:
        return Memory(0, 0)


@dataclass(frozen=True)
class Disk:
    path: str
    total: int
    used: int

    @property
    def free(self) -> int:
        return self.total - self.used


def disk(path: str = "/") -> Disk:
    try:
        u = shutil.disk_usage(path)
        return Disk(path, u.total, u.used)
    except OSError:
        return Disk(path, 0, 0)


_REAL_FS = {"ext4", "ext3", "btrfs", "xfs", "f2fs", "ntfs", "ntfs3", "fuseblk", "exfat", "vfat", "zfs"}


def parse_mounts(text: str) -> list[tuple[str, str]]:
    """/proc/mounts -> [(etiket, bağlama noktası)]; gerçek disk bölümleri, aynı aygıt bir kez."""
    seen: set[str] = set()
    out: list[tuple[str, str]] = []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 3 or not parts[0].startswith("/dev/") or parts[2] not in _REAL_FS:
            continue
        dev, mp = parts[0], parts[1].replace("\\040", " ")
        if dev in seen or mp.startswith(("/boot", "/efi")):
            continue
        seen.add(dev)
        if mp == "/":
            label = "Yerel Disk (/)"
        elif mp.startswith("/run/media/"):
            label = mp.rsplit("/", 1)[-1]
        else:
            label = mp
        out.append((label, mp))
    out.sort(key=lambda x: (x[1] != "/", x[1]))
    return out


def list_disks() -> list[tuple[str, str]]:
    try:
        with open("/proc/mounts") as f:
            disks = parse_mounts(f.read())
    except OSError:
        disks = []
    return disks[:3] or [("Yerel Disk (/)", "/")]


def uptime_seconds() -> float:
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return 0.0


_DUR = re.compile(r"([\d.]+)\s*(min|ms|us|s)")


def parse_duration(text: str) -> float:
    """systemd süre metni ('1min 2.345s', '850ms') -> saniye."""
    total = 0.0
    for num, unit in _DUR.findall(text):
        v = float(num)
        total += {"min": v * 60, "s": v, "ms": v / 1000, "us": v / 1e6}[unit]
    return total


def parse_analyze(text: str) -> float | None:
    """`systemd-analyze` çıktısından toplam açılış süresini (sn) çıkarır."""
    for line in text.splitlines():
        if "Startup finished in" not in line:
            continue
        body = line.split("Startup finished in", 1)[1]
        if "=" in body:
            return parse_duration(body.rsplit("=", 1)[1])
        # "= toplam" yoksa parçaların toplamı
        parts = re.sub(r"\([^)]*\)", "", body)
        return parse_duration(parts)
    return None


def boot_time_seconds() -> float | None:
    if not shutil.which("systemd-analyze"):
        return None
    try:
        out = subprocess.run(
            ["systemd-analyze"], capture_output=True, text=True, timeout=15
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    return parse_analyze(out)


def os_pretty_name() -> str:
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return "Linux"
