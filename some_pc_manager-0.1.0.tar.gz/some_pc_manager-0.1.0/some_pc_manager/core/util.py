"""Küçük, GUI'den bağımsız yardımcılar."""
from __future__ import annotations

import os
import re
from pathlib import Path

_UNITS = ("B", "KB", "MB", "GB", "TB")

# Referans uygulamadaki "10.24G ≈ 2.56kg" oranından türetilmiştir.
CARBON_KG_PER_GB = 0.25


def format_size(n: float, digits: int = 1) -> str:
    """Bayt sayısını Türkçe ondalık virgülle yazar: 1536 -> '1,5 KB'."""
    n = max(0.0, float(n))
    i = 0
    while n >= 1024 and i < len(_UNITS) - 1:
        n /= 1024
        i += 1
    if i == 0:
        return f"{int(n)} B"
    return f"{n:.{digits}f}".replace(".", ",") + f" {_UNITS[i]}"


def format_duration(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    if seconds < 90:
        return f"{round(seconds)} sn"
    m, s = divmod(int(round(seconds)), 60)
    return f"{m} dk {s} sn"


def format_number(x: float, digits: int = 2) -> str:
    return f"{x:.{digits}f}".replace(".", ",")


def carbon_kg(bytes_cleaned: int) -> float:
    return bytes_cleaned / 1024**3 * CARBON_KG_PER_GB


def parse_size(text: str) -> int:
    """'1.4G', '200M', '12.5 MiB' gibi metinleri bayta çevirir."""
    m = re.match(r"\s*([\d.,]+)\s*([KMGT]?)(?:i?B)?", text.strip(), re.I)
    if not m:
        return 0
    value = float(m.group(1).replace(",", "."))
    unit = m.group(2).upper()
    mult = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}[unit]
    return int(value * mult)


def disk_usage_of(path: Path | str, follow_symlinks: bool = False) -> int:
    """Bir dosya ya da dizinin diskte kapladığı bayt (st_blocks * 512)."""
    total = 0
    stack = [str(path)]
    while stack:
        cur = stack.pop()
        try:
            st = os.lstat(cur)
        except OSError:
            continue
        total += st.st_blocks * 512
        if os.path.isdir(cur) and not os.path.islink(cur):
            try:
                with os.scandir(cur) as it:
                    for entry in it:
                        stack.append(entry.path)
            except OSError:
                continue
    return total


def xdg_state_home() -> Path:
    return Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state")


def xdg_config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def xdg_data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")


def xdg_cache_home() -> Path:
    return Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")


def format_ago(ts: float, now: float) -> str:
    """Zaman damgasını 'az önce', '5 dk önce', 'dün' gibi Türkçe göreli ifadeye çevirir."""
    d = max(0.0, now - ts)
    if d < 60:
        return "az önce"
    if d < 3600:
        return f"{int(d // 60)} dk önce"
    if d < 86400:
        return f"{int(d // 3600)} sa önce"
    days = int(d // 86400)
    return "dün" if days == 1 else f"{days} gün önce"
