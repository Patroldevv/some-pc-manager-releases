"""Yetki gerektiren işler için `pkexec` köprüsü.

Yalnızca `some-pc-manager-helper` betiğinin beyaz listedeki eylemleri çağrılır;
serbest komut ya da yol geçirilmez. Parolayı polkit sorar, uygulama görmez.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

ACTIONS = ("clean-pkg-cache", "vacuum-journal", "drop-caches")

_INSTALLED = Path("/usr/lib/some-pc-manager/some-pc-manager-helper")
_DEV = Path(__file__).resolve().parent.parent / "data" / "some-pc-manager-helper"


@dataclass(frozen=True)
class HelperResult:
    action: str
    ok: bool
    freed: int = 0
    message: str = ""
    cancelled: bool = False


def helper_path() -> Path | None:
    for p in (_INSTALLED, _DEV):
        if p.is_file():
            return p
    return None


def available() -> bool:
    return shutil.which("pkexec") is not None and helper_path() is not None


def parse_output(text: str) -> dict[str, HelperResult]:
    results: dict[str, HelperResult] = {}
    for line in text.splitlines():
        try:
            obj = json.loads(line)
            action = obj["action"]
        except (ValueError, KeyError, TypeError):
            continue
        if action not in ACTIONS:
            continue
        results[action] = HelperResult(
            action=action,
            ok=bool(obj.get("ok")),
            freed=int(obj.get("freed", 0)),
            message=str(obj.get("message", "")),
        )
    return results


def run(actions: list[str], timeout: int = 600) -> dict[str, HelperResult]:
    """Eylemleri tek bir yetki isteğiyle çalıştırır."""
    actions = [a for a in actions if a in ACTIONS]
    if not actions:
        return {}

    def fail(msg: str, cancelled: bool = False) -> dict[str, HelperResult]:
        return {a: HelperResult(a, False, 0, msg, cancelled) for a in actions}

    helper = helper_path()
    if not shutil.which("pkexec") or helper is None:
        return fail("pkexec ya da yardımcı betik bulunamadı")
    try:
        proc = subprocess.run(
            ["pkexec", str(helper), *actions],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return fail("Zaman aşımı")
    except OSError as e:
        return fail(str(e))

    if proc.returncode in (126, 127):  # kullanıcı iptal etti / yetkilendirilemedi
        return fail("Yetki verilmedi", cancelled=True)
    parsed = parse_output(proc.stdout)
    for a in actions:
        parsed.setdefault(a, HelperResult(a, False, 0, proc.stderr.strip()[:200] or "Sonuç alınamadı"))
    return parsed
