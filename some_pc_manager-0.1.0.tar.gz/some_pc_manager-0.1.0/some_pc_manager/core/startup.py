"""Başlangıç öğeleri: XDG autostart girdileri ve systemd kullanıcı hizmetleri."""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .apps import parse_desktop
from .sysinfo import parse_duration
from .util import xdg_config_home

MARKER = "X-SomePCManager-Override=true"


@dataclass
class StartupEntry:
    id: str            # dosya adı (örn. foo.desktop)
    name: str
    comment: str
    icon: str
    enabled: bool
    source: str        # "user" | "system"


def user_dir() -> Path:
    return xdg_config_home() / "autostart"


def system_dirs() -> list[Path]:
    dirs = (os.environ.get("XDG_CONFIG_DIRS") or "/etc/xdg").split(":")
    return [Path(d) / "autostart" for d in dirs if d]


def _is_enabled(path: Path) -> bool:
    try:
        text = path.read_text(errors="replace")
    except OSError:
        return False
    if re.search(r"^Hidden\s*=\s*true\s*$", text, re.I | re.M):
        return False
    if re.search(r"^X-GNOME-Autostart-enabled\s*=\s*false\s*$", text, re.I | re.M):
        return False
    return True


def list_autostart() -> list[StartupEntry]:
    entries: dict[str, StartupEntry] = {}
    for source, d in [("user", user_dir())] + [("system", s) for s in system_dirs()]:
        if not d.is_dir():
            continue
        for p in sorted(d.glob("*.desktop")):
            if p.name in entries:
                continue  # kullanıcı dosyası sistemi geçersiz kılar
            parsed = parse_desktop(p)
            if not parsed:
                continue
            e, _flags = parsed
            entries[p.name] = StartupEntry(p.name, e.name, e.comment, e.icon, _is_enabled(p), source)
    return sorted(entries.values(), key=lambda e: (not e.enabled, e.name.lower()))


def _strip_keys(text: str) -> str:
    return re.sub(r"^(Hidden|X-GNOME-Autostart-enabled)\s*=.*\n?", "", text, flags=re.I | re.M)


def set_autostart(entry: StartupEntry, enable: bool) -> None:
    """Girdiyi kullanıcı dizininde Hidden=true ile geçersiz kılarak kapatır."""
    udir = user_dir()
    target = udir / entry.id
    if enable:
        if not target.exists():
            return
        text = target.read_text(errors="replace")
        if MARKER in text and any((d / entry.id).exists() for d in system_dirs()):
            target.unlink()  # yalnızca bizim oluşturduğumuz geçersiz kılma: kaldır
        else:
            target.write_text(_strip_keys(text))
        return
    udir.mkdir(parents=True, exist_ok=True)
    if target.exists():
        text = _strip_keys(target.read_text(errors="replace"))
    else:
        src = next(((d / entry.id) for d in system_dirs() if (d / entry.id).exists()), None)
        text = _strip_keys(src.read_text(errors="replace")) if src else \
            f"[Desktop Entry]\nType=Application\nName={entry.name}\n"
        if MARKER not in text:
            text = text.rstrip("\n") + f"\n{MARKER}\n"
    target.write_text(text.rstrip("\n") + "\nHidden=true\n")


# ---- systemd kullanıcı hizmetleri ----

@dataclass
class Service:
    name: str
    enabled: bool


def parse_unit_files(text: str) -> list[Service]:
    out = []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].endswith(".service") and parts[1] in ("enabled", "disabled", "enabled-runtime"):
            out.append(Service(parts[0], parts[1].startswith("enabled")))
    return out


def list_services() -> list[Service]:
    if not shutil.which("systemctl"):
        return []
    try:
        out = subprocess.run(
            ["systemctl", "--user", "list-unit-files", "--type=service", "--no-legend", "--no-pager"],
            capture_output=True, text=True, timeout=15,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    svcs = [s for s in parse_unit_files(out) if "@" not in s.name]
    return sorted(svcs, key=lambda s: (not s.enabled, s.name))


def set_service(name: str, enable: bool) -> bool:
    if not re.fullmatch(r"[\w.\-]+\.service", name):
        return False
    try:
        r = subprocess.run(["systemctl", "--user", "enable" if enable else "disable", name],
                           capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return False
    return r.returncode == 0


# ---- açılış analizi ----

def parse_blame(text: str) -> list[tuple[str, float]]:
    """`systemd-analyze blame` çıktısı -> [(birim, saniye)], en yavaştan başlayarak."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^\s*(.+?)\s+(\S+\.(?:service|mount|device|target|socket|timer|automount|swap|path|slice|scope))\s*$", line)
        if m:
            out.append((m.group(2), parse_duration(m.group(1))))
    return sorted(out, key=lambda x: x[1], reverse=True)


def boot_blame(n: int = 8) -> list[tuple[str, float]]:
    if not shutil.which("systemd-analyze"):
        return []
    try:
        r = subprocess.run(["systemd-analyze", "blame", "--no-pager"], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return []
    # .device birimleri yalnızca bekleme süresini gösterir; anlamlı olan servis ve bağlama noktalarıdır.
    return [x for x in parse_blame(r.stdout) if x[0].endswith((".service", ".mount"))][:n]
