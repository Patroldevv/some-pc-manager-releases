"""Yinelenen dosya bulucu (salt okunur): önce boyuta, sonra kısmi, sonra tam içerik özetine göre gruplar."""
from __future__ import annotations

import hashlib
import os
import stat
import threading
from dataclasses import dataclass
from typing import Callable

SKIP_DIRS = {".cache", ".git", "node_modules", "Trash", ".var", ".npm", ".cargo", "__pycache__", "proc", "sys", "dev"}
PARTIAL_BYTES = 64 * 1024
CHUNK = 1024 * 1024


@dataclass(frozen=True)
class DupGroup:
    size: int
    paths: tuple[str, ...]      # en eskiden en yeniye; ilki 'saklanacak' olarak önerilir

    @property
    def wasted(self) -> int:
        return self.size * (len(self.paths) - 1)


def _hash(path: str, limit: int | None = None) -> bytes | None:
    h = hashlib.blake2b(digest_size=16)
    try:
        with open(path, "rb") as f:
            if limit is not None:
                h.update(f.read(limit))
            else:
                while chunk := f.read(CHUNK):
                    h.update(chunk)
    except OSError:
        return None
    return h.digest()


def find_duplicates(root: str, min_bytes: int = 1024 * 1024, limit: int = 200,
                    progress: Callable[[str, str], None] | None = None,
                    cancel: threading.Event | None = None) -> list[DupGroup]:
    """`root` altında, en az `min_bytes` boyutunda yinelenen dosya gruplarını döndürür.
    Aynı dosyaya işaret eden sabit bağlar (hard link) yinelenen sayılmaz."""
    def stopped() -> bool:
        return cancel is not None and cancel.is_set()

    # 1) boyuta göre topla
    by_size: dict[int, list[tuple[str, float]]] = {}
    seen_inodes: set[tuple[int, int]] = set()
    stack = [root]
    n = 0
    while stack and not stopped():
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except OSError:
            continue
        with it:
            for e in it:
                try:
                    st = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.S_ISDIR(st.st_mode):
                    if e.name not in SKIP_DIRS:
                        stack.append(e.path)
                elif stat.S_ISREG(st.st_mode) and st.st_size >= min_bytes:
                    ino = (st.st_dev, st.st_ino)
                    if ino in seen_inodes:
                        continue
                    seen_inodes.add(ino)
                    by_size.setdefault(st.st_size, []).append((e.path, st.st_mtime))
        n += 1
        if progress and n % 100 == 0:
            progress("Dosyalar listeleniyor", cur)

    candidates = {s: f for s, f in by_size.items() if len(f) > 1}

    # 2) kısmi özet, 3) tam özet
    groups: list[DupGroup] = []
    for size, files in candidates.items():
        if stopped():
            break
        partial: dict[bytes, list[tuple[str, float]]] = {}
        for path, mtime in files:
            if progress:
                progress("Karşılaştırılıyor", path)
            d = _hash(path, PARTIAL_BYTES)
            if d is not None:
                partial.setdefault(d, []).append((path, mtime))
        for same in partial.values():
            if len(same) < 2 or stopped():
                continue
            full: dict[bytes, list[tuple[str, float]]] = {}
            for path, mtime in same:
                d = _hash(path) if size > PARTIAL_BYTES else _hash(path, PARTIAL_BYTES)
                if d is not None:
                    full.setdefault(d, []).append((path, mtime))
            for dup in full.values():
                if len(dup) > 1:
                    dup.sort(key=lambda x: x[1])
                    groups.append(DupGroup(size, tuple(p for p, _m in dup)))
    groups.sort(key=lambda g: g.wasted, reverse=True)
    return groups[:limit]
