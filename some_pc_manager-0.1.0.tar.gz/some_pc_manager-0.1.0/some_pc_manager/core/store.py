"""Kalıcı durum: toplam temizlenen miktar, son sağlık kontrolü, ayarlar."""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path

from .util import xdg_state_home

DEFAULTS = {
    "total_cleaned": 0,
    "last_boost_freed": 0,
    "last_health_check": None,
    "bg_notice_shown": False,
    "last_smart_boost": 0.0,
    "history": [],
    "settings": {
        "theme": "system",          # system | light | dark
        "reduce_motion": False,
        "drop_caches": False,       # Boost sırasında RAM önbelleğini de boşalt (yetki ister)
        "auto_float": True,         # Hyprland'de pencereyi kayan (floating) yap
        "background": True,         # Pencere kapanınca arka planda çalışmaya devam et
        "smart_notify": True,       # Bellek/disk uyarıları (yalnızca bildirim, otomatik silme yok)
        "autostart": False,         # Oturum açılışında arka planda başlat
        "notify_results": True,     # İşlem sonuçlarını (RAM optimizasyonu, temizlik) bildirim olarak gönder
        "smart_boost": False,       # Boşta iken düzenli olarak geçici dosyaları temizle (bildirimle)
    },
}


class Store:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else xdg_state_home() / "some-pc-manager" / "state.json"
        self.data = json.loads(json.dumps(DEFAULTS))
        self._load()

    def _load(self) -> None:
        try:
            raw = json.loads(self.path.read_text())
        except (OSError, ValueError):
            return
        if not isinstance(raw, dict):
            return
        for key, default in DEFAULTS.items():
            if key == "settings":
                if isinstance(raw.get(key), dict):
                    self.data[key].update({k: v for k, v in raw[key].items() if k in default})
            elif key in raw:
                self.data[key] = raw[key]

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
            with os.fdopen(fd, "w") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)
        except OSError:
            pass  # durum kaydedilemese de uygulama çalışmaya devam eder

    # Kısayollar
    def get(self, key: str):
        return self.data[key]

    def set(self, key: str, value) -> None:
        self.data[key] = value
        self.save()

    def setting(self, key: str):
        return self.data["settings"][key]

    def set_setting(self, key: str, value) -> None:
        self.data["settings"][key] = value
        self.save()

    HISTORY_LIMIT = 200

    def add_history(self, kind: str, freed: int = 0, note: str = "", ts: float | None = None) -> None:
        """İşlem geçmişine kayıt ekler (kind: boost | cleanup | health | smart | quick)."""
        h = self.data["history"]
        h.append({"ts": ts if ts is not None else time.time(), "kind": kind, "freed": int(max(0, freed)), "note": note})
        del h[:-self.HISTORY_LIMIT]
        self.save()

    def clear_history(self) -> None:
        self.data["history"] = []
        self.save()

    def daily_totals(self, days: int = 7, now: float | None = None) -> list[tuple[str, int]]:
        """Son `days` gün için (YYYY-MM-DD, temizlenen bayt); en eskiden bugüne."""
        import datetime
        today = datetime.date.fromtimestamp(now if now is not None else time.time())
        keys = [(today - datetime.timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
        totals = dict.fromkeys(keys, 0)
        for e in self.data["history"]:
            try:
                k = datetime.date.fromtimestamp(float(e["ts"])).isoformat()
            except (KeyError, TypeError, ValueError, OSError):
                continue
            if k in totals:
                totals[k] += int(e.get("freed", 0))
        return list(totals.items())

    def add_cleaned(self, n: int) -> None:
        self.data["total_cleaned"] = int(self.data["total_cleaned"]) + max(0, int(n))
        self.save()
