"""Büyük dosya bulucu. Yalnızca listeler; silme çöp kutusuna taşıyarak UI'da yapılır."""
from __future__ import annotations

import heapq
import os
import stat
import threading
from dataclasses import dataclass
from typing import Callable

SKIP_DIRS = {"proc", "sys", "dev", "run", ".cache", "Trash"}


@dataclass(frozen=True)
class BigFile:
    path: str
    size: int
    mtime: float


def find_large(root: str, min_bytes: int, limit: int = 100,
               progress: Callable[[str], None] | None = None,
               cancel: threading.Event | None = None) -> list[BigFile]:
    """`root` altında `min_bytes` ve üstü en büyük `limit` dosyayı döndürür."""
    heap: list[tuple[int, str, float]] = []
    stack = [root]
    visited = 0
    while stack:
        if cancel is not None and cancel.is_set():
            break
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except OSError:
            continue
        with it:
            for e in it:
                try:
                    st = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.S_ISDIR(st.st_mode):
                    if e.name not in SKIP_DIRS:
                        stack.append(e.path)
                elif stat.S_ISREG(st.st_mode) and st.st_size >= min_bytes:
                    item = (st.st_size, e.path, st.st_mtime)
                    if len(heap) < limit:
                        heapq.heappush(heap, item)
                    else:
                        heapq.heappushpop(heap, item)
        visited += 1
        if progress and visited % 200 == 0:
            progress(cur)
    return [BigFile(p, s, m) for s, p, m in sorted(heap, reverse=True)]
