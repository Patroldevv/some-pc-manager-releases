"""Oturum açılışında uygulamayı arka planda başlatan XDG autostart girdisi."""
from __future__ import annotations

import shutil
from pathlib import Path

from .util import xdg_config_home

DESKTOP_ID = "dev.somepcmanager.PCManager.desktop"


def path() -> Path:
    return xdg_config_home() / "autostart" / DESKTOP_ID


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def exec_line() -> str:
    if shutil.which("some-pc-manager"):
        return "some-pc-manager --background"
    # Kaynak koddan çalışıyorsa modül yolu gerekir; boşluklu argüman çift tırnakla yazılır.
    return f'env "PYTHONPATH={project_root()}" python3 -m some_pc_manager --background'


def render() -> str:
    return (
        "[Desktop Entry]\nType=Application\nName=Some PC Manager\n"
        "Comment=Arka planda çalışarak bellek ve disk durumunu izler\n"
        f"Exec={exec_line()}\nIcon=dev.somepcmanager.PCManager\n"
        "X-GNOME-Autostart-enabled=true\nX-SomePCManager-Autostart=true\n"
    )


def is_enabled() -> bool:
    p = path()
    if not p.exists():
        return False
    text = p.read_text(errors="replace")
    return "Hidden=true" not in text and "X-GNOME-Autostart-enabled=false" not in text


def enable() -> bool:
    try:
        path().parent.mkdir(parents=True, exist_ok=True)
        path().write_text(render())
    except OSError:
        return False
    return True


def disable() -> bool:
    try:
        path().unlink(missing_ok=True)
    except OSError:
        return False
    return True
