"""Koruma durumu: güvenlik duvarı, bekleyen güncellemeler, ClamAV taraması."""
from __future__ import annotations

import shutil
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .cleaner import pkg_manager


def _run(cmd: list[str], timeout: int = 20) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None


def firewall_status() -> str:
    """'active' | 'inactive' | 'missing'"""
    seen = False
    for unit, binary in (("ufw", "ufw"), ("firewalld", "firewall-cmd"), ("nftables", "nft")):
        if not shutil.which(binary):
            continue
        seen = True
        r = _run(["systemctl", "is-active", unit])
        if r is not None and r.stdout.strip() == "active":
            return "active"
    return "inactive" if seen else "missing"


def count_lines(text: str) -> int:
    return sum(1 for line in text.splitlines() if line.strip())


def pending_updates() -> int | None:
    """Bekleyen güncelleme sayısı; belirlenemezse None."""
    pm = pkg_manager()
    if pm == "pacman" and shutil.which("checkupdates"):
        r = _run(["checkupdates"], 60)
        return None if r is None else count_lines(r.stdout)
    if pm == "apt-get" and shutil.which("apt"):
        r = _run(["apt", "list", "--upgradable"], 60)
        return None if r is None else max(0, count_lines(r.stdout) - 1)
    if pm == "dnf":
        r = _run(["dnf", "check-update", "-q"], 90)
        if r is None:
            return None
        return count_lines(r.stdout) if r.returncode == 100 else 0
    return None


def clamav_available() -> bool:
    return shutil.which("clamscan") is not None


@dataclass
class ScanResult:
    infected: list[str] = field(default_factory=list)
    scanned_paths: list[str] = field(default_factory=list)
    cancelled: bool = False
    error: str = ""


def parse_clam_line(line: str) -> str | None:
    """'/yol/dosya: Eicar-Test FOUND' -> '/yol/dosya: Eicar-Test'"""
    line = line.strip()
    return line[: -len(" FOUND")] if line.endswith(" FOUND") else None


def quick_scan_paths() -> list[Path]:
    home = Path.home()
    return [p for p in (home / "Downloads", home / "İndirilenler", home / "Desktop", home / "Masaüstü") if p.is_dir()]


def clam_scan(paths: list[Path], on_file: Callable[[str], None] | None = None,
              cancel: threading.Event | None = None) -> ScanResult:
    res = ScanResult(scanned_paths=[str(p) for p in paths])
    if not paths:
        res.error = "Taranacak klasör bulunamadı"
        return res
    try:
        proc = subprocess.Popen(
            ["clamscan", "-r", "-i", "--no-summary", "--verbose", *map(str, paths)],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
        )
    except OSError as e:
        res.error = str(e)
        return res
    assert proc.stdout is not None
    for line in proc.stdout:
        if cancel is not None and cancel.is_set():
            proc.terminate()
            res.cancelled = True
            break
        hit = parse_clam_line(line)
        if hit:
            res.infected.append(hit)
        elif line.startswith("Scanning ") and on_file:
            on_file(line[len("Scanning "):].strip())
    proc.wait()
    return res
