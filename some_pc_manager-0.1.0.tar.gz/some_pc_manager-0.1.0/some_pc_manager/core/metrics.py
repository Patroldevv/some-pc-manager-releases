"""Canlı sistem metrikleri: CPU, ağ, sıcaklık, pil. Yalnızca /proc ve /sys okur."""
from __future__ import annotations

import glob
import os
import time
from pathlib import Path


def parse_cpu_stat(text: str) -> tuple[int, int] | None:
    """/proc/stat -> (boşta, toplam) jiffy; ilk 'cpu ' satırı."""
    for line in text.splitlines():
        if line.startswith("cpu "):
            v = [int(x) for x in line.split()[1:9]]
            if len(v) < 4:
                return None
            idle = v[3] + (v[4] if len(v) > 4 else 0)
            return idle, sum(v)
    return None


class CpuSampler:
    def __init__(self) -> None:
        self._prev: tuple[int, int] | None = None

    def percent(self) -> float:
        try:
            cur = parse_cpu_stat(Path("/proc/stat").read_text())
        except OSError:
            return 0.0
        if cur is None:
            return 0.0
        prev, self._prev = self._prev, cur
        if prev is None:
            return 0.0
        didle, dtotal = cur[0] - prev[0], cur[1] - prev[1]
        return max(0.0, min(100.0, 100.0 * (dtotal - didle) / dtotal)) if dtotal > 0 else 0.0


_VIRTUAL = ("lo", "veth", "docker", "br-", "virbr", "tun", "tap")


def parse_net_dev(text: str) -> tuple[int, int]:
    """/proc/net/dev -> (toplam alınan, toplam gönderilen) bayt; sanal arayüzler hariç."""
    rx = tx = 0
    for line in text.splitlines()[2:]:
        if ":" not in line:
            continue
        name, data = line.split(":", 1)
        name = name.strip()
        if name.startswith(_VIRTUAL):
            continue
        f = data.split()
        if len(f) >= 9:
            rx += int(f[0])
            tx += int(f[8])
    return rx, tx


class NetSampler:
    def __init__(self) -> None:
        self._prev: tuple[int, int, float] | None = None

    def rates(self) -> tuple[float, float]:
        """(indirme, yükleme) bayt/sn."""
        try:
            rx, tx = parse_net_dev(Path("/proc/net/dev").read_text())
        except OSError:
            return 0.0, 0.0
        now = time.monotonic()
        prev, self._prev = self._prev, (rx, tx, now)
        if prev is None or now <= prev[2]:
            return 0.0, 0.0
        dt = now - prev[2]
        return max(0.0, (rx - prev[0]) / dt), max(0.0, (tx - prev[1]) / dt)


_CPU_HWMON = ("coretemp", "k10temp", "zenpower", "cpu_thermal", "acpitz", "cpu")


def read_temperature() -> float | None:
    """CPU sıcaklığı (°C); bulunamazsa None."""
    best: float | None = None
    for hw in glob.glob("/sys/class/hwmon/hwmon*"):
        try:
            name = Path(hw, "name").read_text().strip()
        except OSError:
            continue
        if name not in _CPU_HWMON:
            continue
        for f in glob.glob(os.path.join(hw, "temp*_input")):
            try:
                v = int(Path(f).read_text()) / 1000.0
            except (OSError, ValueError):
                continue
            if 0 < v < 150 and (best is None or v > best):
                best = v
    if best is None:
        for f in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
            try:
                v = int(Path(f).read_text()) / 1000.0
            except (OSError, ValueError):
                continue
            if 0 < v < 150 and (best is None or v > best):
                best = v
    return best


def battery() -> tuple[int, str] | None:
    """(yüzde, durum) ya da pil yoksa None."""
    for d in sorted(glob.glob("/sys/class/power_supply/BAT*")):
        try:
            pct = int(Path(d, "capacity").read_text())
            status = Path(d, "status").read_text().strip()
        except (OSError, ValueError):
            continue
        return pct, status
    return None


def load_average() -> tuple[float, float, float]:
    try:
        a, b, c = os.getloadavg()
        return a, b, c
    except OSError:
        return 0.0, 0.0, 0.0


def format_rate(bps: float) -> str:
    units = ("B/sn", "KB/sn", "MB/sn", "GB/sn")
    i = 0
    while bps >= 1024 and i < len(units) - 1:
        bps /= 1024
        i += 1
    return (f"{bps:.0f}" if i == 0 else f"{bps:.1f}".replace(".", ",")) + f" {units[i]}"
