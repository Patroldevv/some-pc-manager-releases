"""PC Boost: geçici dosyaları temizler, isteğe bağlı olarak RAM önbelleğini boşaltır."""
from __future__ import annotations

from dataclasses import dataclass

from . import cleaner, privileged, sysinfo
from .util import format_size

BOOST_TARGETS = ["tmp", "thumbnails", "user_cache"]


@dataclass
class BoostResult:
    temp_freed: int = 0
    cache_released: int = 0
    mem_before: sysinfo.Memory | None = None
    mem_after: sysinfo.Memory | None = None
    note: str = ""


def boost(drop_caches: bool = False) -> BoostResult:
    res = BoostResult(mem_before=sysinfo.memory())
    report = cleaner.run_cleanup(BOOST_TARGETS, mode="boost")
    res.temp_freed = report.total_freed
    if drop_caches:
        r = privileged.run(["drop-caches"]).get("drop-caches")
        if r and r.ok:
            res.cache_released = r.freed
        elif r and r.cancelled:
            res.note = "RAM önbelleği için yetki verilmedi"
    res.mem_after = sysinfo.memory()
    return res


MEM_GAIN_MIN = 8 * 1024**2     # bundan küçük bellek farkı anlamlı sayılmaz


def memory_gain(res: BoostResult) -> int:
    if res.mem_before and res.mem_after:
        return max(0, res.mem_after.available - res.mem_before.available)
    return 0


def summarize(res: BoostResult) -> str:
    """Bildirim/toast için tek satırlık sonuç özeti."""
    parts = [f"{format_size(res.temp_freed)} geçici dosya temizlendi" if res.temp_freed
             else "Temizlenecek geçici dosya yoktu"]
    gain = memory_gain(res)
    if res.cache_released:
        parts.append(f"{format_size(res.cache_released)} RAM önbelleği boşaltıldı")
    elif gain >= MEM_GAIN_MIN:
        parts.append(f"{format_size(gain)} bellek kazanıldı")
    if res.mem_after:
        parts.append(f"bellek %{res.mem_after.percent:.0f}")
    return " · ".join(parts)
