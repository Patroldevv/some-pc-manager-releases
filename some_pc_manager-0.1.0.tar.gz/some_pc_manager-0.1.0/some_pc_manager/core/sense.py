"""Depolama algılama: haftalık otomatik temizlik için systemd kullanıcı zamanlayıcısı."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .util import xdg_config_home

SERVICE = "some-pc-manager-sense.service"
TIMER = "some-pc-manager-sense.timer"


def unit_dir() -> Path:
    return xdg_config_home() / "systemd" / "user"


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def render_service(root: Path | None = None) -> str:
    root = root if root is not None else project_root()
    env = ""
    if (root / "some_pc_manager").is_dir():   # paket standart yolda değilse (kaynak/yerleşik kurulum)
        env = f'Environment="PYTHONPATH={root}"\n'
    return (
        "[Unit]\nDescription=Some PC Manager otomatik temizlik\n\n"
        "[Service]\nType=oneshot\n" + env +
        "ExecStart=/usr/bin/env python3 -m some_pc_manager --auto-clean\n"
        "Nice=19\nIOSchedulingClass=idle\n"
    )


TIMER_UNIT = (
    "[Unit]\nDescription=Some PC Manager haftalık otomatik temizlik\n\n"
    "[Timer]\nOnCalendar=weekly\nPersistent=true\nRandomizedDelaySec=1h\n\n"
    "[Install]\nWantedBy=timers.target\n"
)


def _systemctl(*args: str) -> bool:
    if not shutil.which("systemctl"):
        return False
    try:
        return subprocess.run(["systemctl", "--user", *args], capture_output=True, timeout=30).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def is_enabled() -> bool:
    return (unit_dir() / TIMER).exists() and _systemctl("is-enabled", TIMER)


def enable() -> bool:
    d = unit_dir()
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / SERVICE).write_text(render_service())
        (d / TIMER).write_text(TIMER_UNIT)
    except OSError:
        return False
    return _systemctl("daemon-reload") and _systemctl("enable", "--now", TIMER)


def disable() -> bool:
    ok = _systemctl("disable", "--now", TIMER)
    for name in (TIMER, SERVICE):
        try:
            (unit_dir() / name).unlink()
        except OSError:
            pass
    _systemctl("daemon-reload")
    return ok
