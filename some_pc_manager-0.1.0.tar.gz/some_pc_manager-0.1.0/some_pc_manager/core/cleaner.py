"""Temizleme hedefleri: önce tara (boyut), sonra temizle.

Yalnızca burada tanımlı beyaz listedeki yollara dokunulur. Yalnızca normal
dosyalar ve sembolik bağlar silinir (soket/fifo/aygıt asla).
"""
from __future__ import annotations

import os
import re
import shutil
import stat
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterator

from . import privileged
from .util import disk_usage_of, parse_size, xdg_cache_home, xdg_data_home

JOURNAL_KEEP_BYTES = 200 * 1024**2
TMP_MIN_AGE_DAYS = 2
BOOST_AGE_DAYS = 7
DEEP_CACHE_AGE_DAYS = 1

BROWSER_CACHE_DIRS = (
    "mozilla", "chromium", "google-chrome", "BraveSoftware",
    "microsoft-edge", "vivaldi", "opera",
)
# Yeniden indirmesi pahalı ya da başlangıcı yavaşlatan önbellekler korunur.
CACHE_KEEP = {"thumbnails", "fontconfig", "huggingface", "torch", "keyring", "ssh", "ollama"}


@dataclass(frozen=True)
class Target:
    id: str
    label: str
    description: str
    group: str                 # "user" | "system"
    root: bool = False         # yetki gerektirir
    default_selected: bool = True


TARGETS: dict[str, Target] = {t.id: t for t in (
    Target("tmp", "Geçici dosyalar", "/tmp içindeki eski dosyalarınız", "user"),
    Target("thumbnails", "Küçük resim önbelleği", "Dosya yöneticisi önizlemeleri", "user"),
    Target("browser_cache", "Tarayıcı önbellekleri", "Firefox, Chromium, Chrome ve benzerleri", "user"),
    Target("user_cache", "Uygulama önbellekleri", "~/.cache içindeki yeniden üretilebilir veriler", "user"),
    Target("trash", "Çöp kutusu", "Kalıcı olarak silinir", "user", default_selected=False),
    Target("pkg_cache", "Paket önbelleği", "Eski paket sürümleri", "system", root=True),
    Target("journal", "Sistem günlükleri", "Journal kayıtları (200 MB'a düşürülür)", "system", root=True),
)}

_ROOT_ACTIONS = {"pkg_cache": "clean-pkg-cache", "journal": "vacuum-journal"}


@dataclass
class ScanItem:
    target: Target
    size: int = 0
    available: bool = True
    note: str = ""


@dataclass
class CleanResult:
    target_id: str
    label: str
    status: str                # "cleaned" | "skipped" | "error"
    freed: int = 0
    note: str = ""


@dataclass
class CleanupReport:
    results: list[CleanResult] = field(default_factory=list)

    @property
    def total_freed(self) -> int:
        return sum(r.freed for r in self.results if r.status == "cleaned")


# --------------------------------------------------------------------------
# Güvenli dizin gezme / silme
# --------------------------------------------------------------------------

def _guard(root: Path) -> None:
    """Tehlikeli kökleri reddeder."""
    if not root.is_absolute():
        raise ValueError(f"mutlak yol gerekli: {root}")
    if root.is_symlink():
        raise ValueError(f"sembolik bağ kök olamaz: {root}")
    if root == Path("/") or root == Path.home():
        raise ValueError(f"güvenli olmayan kök: {root}")
    home, tmp = Path.home().resolve(), Path("/tmp").resolve()
    real = root.resolve()
    if not (real == tmp or tmp in real.parents or home in real.parents):
        raise ValueError(f"izin verilen konumların dışında: {root}")


def _eligible(st: os.stat_result, cutoff: float | None, owner_only: bool) -> bool:
    if not (stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode)):
        return False
    if owner_only and st.st_uid != os.getuid():
        return False
    if cutoff is not None and (st.st_mtime > cutoff or st.st_atime > cutoff):
        return False
    return True


def iter_files(root: Path, *, min_age_days: float | None = None,
               skip_top: frozenset[str] | set[str] = frozenset(),
               skip_hidden_top: bool = False, owner_only: bool = False,
               cancel: threading.Event | None = None) -> Iterator[tuple[str, int]]:
    """Silinmeye uygun dosyaları (yol, diskteki bayt) olarak üretir."""
    if not root.is_dir() or root.is_symlink():
        return
    _guard(root)
    cutoff = time.time() - min_age_days * 86400 if min_age_days else None
    stack: list[tuple[str, int]] = [(str(root), 0)]
    while stack:
        if cancel is not None and cancel.is_set():
            return
        cur, depth = stack.pop()
        try:
            it = os.scandir(cur)
        except OSError:
            continue
        with it:
            for e in it:
                if depth == 0 and (e.name in skip_top or (skip_hidden_top and e.name.startswith("."))):
                    continue
                try:
                    st = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.S_ISDIR(st.st_mode):
                    stack.append((e.path, depth + 1))
                elif _eligible(st, cutoff, owner_only):
                    yield e.path, st.st_blocks * 512


def prune_empty_dirs(root: Path, *, min_age_days: float | None = None,
                     skip_top=frozenset(), skip_hidden_top: bool = False) -> None:
    cutoff = time.time() - min_age_days * 86400 if min_age_days else None

    def walk(path: str, depth: int) -> None:
        try:
            entries = list(os.scandir(path))
        except OSError:
            return
        for e in entries:
            if depth == 0 and (e.name in skip_top or (skip_hidden_top and e.name.startswith("."))):
                continue
            try:
                if not e.is_dir(follow_symlinks=False):
                    continue
                walk(e.path, depth + 1)
                st = e.stat(follow_symlinks=False)
                if st.st_uid != os.getuid():
                    continue
                if cutoff is not None and st.st_mtime > cutoff:
                    continue
                os.rmdir(e.path)  # yalnızca boşsa başarılı olur
            except OSError:
                pass

    if root.is_dir() and not root.is_symlink():
        walk(str(root), 0)


# --------------------------------------------------------------------------
# Hedef tanımları
# --------------------------------------------------------------------------

@dataclass
class _Spec:
    roots: Callable[[], list[Path]]
    skip_top: Callable[[], set[str]] = lambda: set()
    skip_hidden_top: bool = False
    owner_only: bool = False
    deep_age: float | None = None       # Derin temizlikte asgari dosya yaşı (gün)
    boost_age: float | None = None      # Boost'ta asgari dosya yaşı (gün)


def _browser_roots() -> list[Path]:
    return [xdg_cache_home() / n for n in BROWSER_CACHE_DIRS]


_SPECS: dict[str, _Spec] = {
    "tmp": _Spec(lambda: [Path("/tmp")], skip_hidden_top=True, owner_only=True,
                 deep_age=TMP_MIN_AGE_DAYS, boost_age=TMP_MIN_AGE_DAYS),
    "thumbnails": _Spec(lambda: [xdg_cache_home() / "thumbnails", Path.home() / ".thumbnails"],
                        deep_age=None, boost_age=None),
    "browser_cache": _Spec(_browser_roots, deep_age=None, boost_age=None),
    "user_cache": _Spec(lambda: [xdg_cache_home()],
                        skip_top=lambda: CACHE_KEEP | set(BROWSER_CACHE_DIRS),
                        deep_age=DEEP_CACHE_AGE_DAYS, boost_age=BOOST_AGE_DAYS),
    "trash": _Spec(lambda: [xdg_data_home() / "Trash" / "files", xdg_data_home() / "Trash" / "info"]),
}


def _age(spec: _Spec, mode: str) -> float | None:
    return spec.boost_age if mode == "boost" else spec.deep_age


def _scan_user(tid: str, mode: str, cancel=None) -> int:
    spec = _SPECS[tid]
    total = 0
    for root in spec.roots():
        for _p, size in iter_files(root, min_age_days=_age(spec, mode), skip_top=spec.skip_top(),
                                   skip_hidden_top=spec.skip_hidden_top, owner_only=spec.owner_only,
                                   cancel=cancel):
            total += size
    return total


def _clean_user(tid: str, mode: str, cancel=None) -> CleanResult:
    spec = _SPECS[tid]
    t = TARGETS[tid]
    freed, errors = 0, 0
    for root in spec.roots():
        age = _age(spec, mode)
        for path, size in iter_files(root, min_age_days=age, skip_top=spec.skip_top(),
                                     skip_hidden_top=spec.skip_hidden_top,
                                     owner_only=spec.owner_only, cancel=cancel):
            try:
                os.unlink(path)
                freed += size
            except OSError:
                errors += 1
        prune_empty_dirs(root, min_age_days=age, skip_top=spec.skip_top(),
                         skip_hidden_top=spec.skip_hidden_top)
    note = f"{errors} dosya silinemedi" if errors else ""
    return CleanResult(tid, t.label, "cleaned", freed, note)


# ---- sistem hedefleri (boyut tarama) ----

def pkg_manager() -> str | None:
    for name in ("pacman", "apt-get", "dnf"):
        if shutil.which(name):
            return name
    return None


def parse_paccache(text: str) -> int:
    m = re.search(r"disk space saved:\s*([\d.,]+\s*\w+)", text)
    return parse_size(m.group(1)) if m else 0


def parse_journal_usage(text: str) -> int:
    m = re.search(r"take up\s+([\d.,]+\s*[KMGT]?)", text)
    return parse_size(m.group(1)) if m else 0


def _scan_pkg_cache() -> ScanItem:
    t = TARGETS["pkg_cache"]
    pm = pkg_manager()
    if pm == "pacman":
        if not shutil.which("paccache"):
            return ScanItem(t, 0, False, "pacman-contrib yüklü değil")
        try:
            out = subprocess.run(["paccache", "-dk2"], capture_output=True, text=True, timeout=60).stdout
            out2 = subprocess.run(["paccache", "-duk0"], capture_output=True, text=True, timeout=60).stdout
        except (OSError, subprocess.SubprocessError):
            return ScanItem(t, 0, False, "Taranamadı")
        return ScanItem(t, parse_paccache(out) + parse_paccache(out2))
    if pm == "apt-get":
        return ScanItem(t, disk_usage_of("/var/cache/apt/archives"))
    if pm == "dnf":
        return ScanItem(t, disk_usage_of("/var/cache/libdnf5") + disk_usage_of("/var/cache/dnf"))
    return ScanItem(t, 0, False, "Paket yöneticisi bulunamadı")


def _scan_journal() -> ScanItem:
    t = TARGETS["journal"]
    if not shutil.which("journalctl"):
        return ScanItem(t, 0, False, "systemd-journal yok")
    try:
        out = subprocess.run(["journalctl", "--disk-usage"], capture_output=True, text=True, timeout=15).stdout
    except (OSError, subprocess.SubprocessError):
        return ScanItem(t, 0, False, "Okunamadı")
    usage = parse_journal_usage(out)
    return ScanItem(t, max(0, usage - JOURNAL_KEEP_BYTES))


# --------------------------------------------------------------------------
# Genel API
# --------------------------------------------------------------------------

def scan(tid: str, mode: str = "deep", cancel=None) -> ScanItem:
    t = TARGETS[tid]
    if tid == "pkg_cache":
        return _scan_pkg_cache()
    if tid == "journal":
        return _scan_journal()
    return ScanItem(t, _scan_user(tid, mode, cancel))


def scan_all(ids: list[str] | None = None, mode: str = "deep",
             progress: Callable[[ScanItem], None] | None = None,
             cancel: threading.Event | None = None) -> list[ScanItem]:
    items: list[ScanItem] = []
    for tid in ids or list(TARGETS):
        if cancel is not None and cancel.is_set():
            break
        item = scan(tid, mode, cancel)
        items.append(item)
        if progress:
            progress(item)
    return items


def temporary_files_size() -> int:
    """Home ekranındaki 'Geçici dosyalar' değeri: Boost'un temizleyeceği miktar."""
    return sum(_scan_user(tid, "boost") for tid in ("tmp", "thumbnails", "user_cache"))


def run_cleanup(ids: list[str], mode: str = "deep",
                progress: Callable[[str, int, int], None] | None = None,
                cancel: threading.Event | None = None) -> CleanupReport:
    """Seçili hedefleri temizler. Yetki gerektirenler tek pkexec çağrısında toplanır."""
    report = CleanupReport()
    ordered = [i for i in ids if i in TARGETS]
    user_ids = [i for i in ordered if not TARGETS[i].root]
    root_ids = [i for i in ordered if TARGETS[i].root]
    total = len(ordered)
    done = 0

    for tid in user_ids:
        if cancel is not None and cancel.is_set():
            break
        if progress:
            progress(tid, done, total)
        try:
            report.results.append(_clean_user(tid, mode, cancel))
        except (ValueError, OSError) as e:
            report.results.append(CleanResult(tid, TARGETS[tid].label, "error", 0, str(e)))
        done += 1

    if root_ids and not (cancel is not None and cancel.is_set()):
        if progress:
            progress(root_ids[0], done, total)
        res = privileged.run([_ROOT_ACTIONS[i] for i in root_ids])
        for tid in root_ids:
            r = res.get(_ROOT_ACTIONS[tid])
            label = TARGETS[tid].label
            if r is None:
                report.results.append(CleanResult(tid, label, "skipped", 0, "Sonuç alınamadı"))
            elif r.ok:
                report.results.append(CleanResult(tid, label, "cleaned", r.freed))
            elif r.cancelled:
                report.results.append(CleanResult(tid, label, "skipped", 0, "Yetki verilmedi"))
            else:
                report.results.append(CleanResult(tid, label, "skipped", 0, r.message))
            done += 1
    if progress:
        progress("", total, total)
    return report
