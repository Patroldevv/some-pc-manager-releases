"""Disk analizi: bir klasörün alt öğelerinin diskte kapladığı yeri hesaplar (salt okunur)."""
from __future__ import annotations

import os
import stat
import threading
from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class Entry:
    name: str
    path: str
    size: int
    is_dir: bool


def dir_size(path: str, cancel: threading.Event | None = None) -> int:
    """Dizinin içeriği dahil diskte kapladığı bayt. Sembolik bağları ve başka dosya sistemlerini izlemez."""
    try:
        dev = os.lstat(path).st_dev
    except OSError:
        return 0
    total = 0
    stack = [path]
    while stack:
        if cancel is not None and cancel.is_set():
            return total
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except OSError:
            continue
        with it:
            for e in it:
                try:
                    st = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                total += st.st_blocks * 512
                if stat.S_ISDIR(st.st_mode) and st.st_dev == dev:
                    stack.append(e.path)
    return total


def scan_children(path: str, on_entry: Callable[[Entry], None] | None = None,
                  cancel: threading.Event | None = None) -> list[Entry]:
    """`path` altındaki her öğenin boyutunu hesaplar; her biri bitince `on_entry` çağrılır."""
    entries: list[Entry] = []
    try:
        children = list(os.scandir(path))
    except OSError:
        return entries
    for e in children:
        if cancel is not None and cancel.is_set():
            break
        try:
            st = e.stat(follow_symlinks=False)
        except OSError:
            continue
        is_dir = stat.S_ISDIR(st.st_mode)
        size = dir_size(e.path, cancel) if is_dir else st.st_blocks * 512
        entry = Entry(e.name, e.path, size, is_dir)
        entries.append(entry)
        if on_entry:
            on_entry(entry)
    entries.sort(key=lambda x: x.size, reverse=True)
    return entries
