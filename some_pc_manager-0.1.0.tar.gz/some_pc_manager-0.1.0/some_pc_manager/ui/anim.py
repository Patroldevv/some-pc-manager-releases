"""Akıcı animasyon yardımcıları (Adw.TimedAnimation üzerine ince bir katman)."""
from __future__ import annotations

from typing import Callable

import gi

gi.require_version("Adw", "1")
from gi.repository import Adw, GLib  # noqa: E402

EASE_OUT = Adw.Easing.EASE_OUT_CUBIC
EASE_IN_OUT = Adw.Easing.EASE_IN_OUT_CUBIC
LINEAR = Adw.Easing.LINEAR

_reduce_motion = False
_live: set = set()  # oynarken animasyonları canlı tutar


def set_reduce_motion(value: bool) -> None:
    global _reduce_motion
    _reduce_motion = bool(value)


def reduce_motion() -> bool:
    return _reduce_motion


def duration(ms: int) -> int:
    return 0 if _reduce_motion else ms


def animate(widget, start: float, end: float, ms: int, apply: Callable[[float], None],
            done: Callable[[], None] | None = None, easing=EASE_OUT):
    """`start`'tan `end`'e `ms` süresince `apply(değer)` çağırır."""
    if _reduce_motion or ms <= 0:
        apply(end)
        if done:
            GLib.idle_add(lambda: (done(), False)[1])
        return None
    target = Adw.CallbackAnimationTarget.new(apply)
    anim = Adw.TimedAnimation.new(widget, start, end, ms, target)
    anim.set_easing(easing)
    _live.add(anim)

    def finished(*_):
        _live.discard(anim)
        if done:
            done()

    anim.connect("done", finished)
    anim.play()
    return anim


def animate_number(widget, lbl, start: float, end: float, fmt: Callable[[float], str], ms: int = 700):
    """Etiketteki sayıyı `start`'tan `end`'e yumuşakça sayarak değiştirir."""
    return animate(widget, start, end, ms, lambda v: lbl.set_text(fmt(v)))


def fade(widget, to: float, ms: int = 200, done=None, easing=EASE_OUT):
    return animate(widget, widget.get_opacity(), to, ms, widget.set_opacity, done, easing)


def fade_swap(widget, swap: Callable[[], None], out_ms: int = 90, in_ms: int = 220) -> None:
    """Önce eski içeriği söndürür, sonra `swap()` çağırır, yenisini belirir.
    Crossfade'in aksine iki içerik asla aynı anda görünmez (üst üste binme olmaz)."""
    if _reduce_motion:
        swap()
        return

    def after_out() -> None:
        swap()
        animate(widget, 0.0, 1.0, in_ms, widget.set_opacity)

    animate(widget, widget.get_opacity(), 0.0, out_ms, widget.set_opacity, after_out, EASE_IN_OUT)


def stagger(widgets, step: int = 45, ms: int = 340, lift: int = 10, delay: int = 0) -> None:
    """Widget'ları sırayla aşağıdan yukarı süzülerek belirt."""
    for i, w in enumerate(widgets):
        base = getattr(w, "_spm_base_mt", None)
        if base is None:
            base = w._spm_base_mt = w.get_margin_top()
        if _reduce_motion:
            w.set_opacity(1.0)
            w.set_margin_top(base)
            continue
        w.set_opacity(0.0)
        w.set_margin_top(base + lift)

        def start(w=w, base=base) -> bool:
            def apply(t: float) -> None:
                w.set_opacity(t)
                w.set_margin_top(round(base + lift * (1 - t)))

            def done() -> None:
                w.set_opacity(1.0)
                w.set_margin_top(base)

            animate(w, 0.0, 1.0, ms, apply, done)
            return GLib.SOURCE_REMOVE

        GLib.timeout_add(delay + i * step, start)


def breathe(widget, low: float = 0.72, ms: int = 2200):
    """Opaklığı yavaşça azalıp artan, sonsuz 'nefes alma' animasyonu."""
    if _reduce_motion:
        return None
    target = Adw.CallbackAnimationTarget.new(widget.set_opacity)
    a = Adw.TimedAnimation.new(widget, 1.0, low, ms, target)
    a.set_easing(EASE_IN_OUT)
    a.set_alternate(True)
    a.set_repeat_count(0)
    a.play()
    return a


def loop(widget, apply: Callable[[float], None], ms: int = 1000):
    """0→1 arası sonsuz döngü (dönen halka vb.). Döndürülen animasyonu `.pause()` ile durdur."""
    target = Adw.CallbackAnimationTarget.new(apply)
    anim = Adw.TimedAnimation.new(widget, 0.0, 1.0, ms, target)
    anim.set_easing(LINEAR)
    anim.set_repeat_count(0)  # sonsuz
    anim.play()
    return anim


def stop(anim) -> None:
    if anim is not None:
        anim.pause()
        _live.discard(anim)
