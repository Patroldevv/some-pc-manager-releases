"""Ağır işleri iş parçacığında çalıştırıp sonucu UI iş parçacığına döndürür."""
from __future__ import annotations

import sys
import threading
import traceback
from typing import Callable

import gi

gi.require_version("GLib", "2.0")
from gi.repository import GLib  # noqa: E402


def call_ui(fn: Callable, *args) -> None:
    GLib.idle_add(lambda: (fn(*args), False)[1])


def run_async(work: Callable, on_done: Callable | None = None, on_error: Callable | None = None) -> threading.Thread:
    def runner() -> None:
        try:
            result = work()
        except Exception as e:  # noqa: BLE001 - UI'ı çökertmemek için
            traceback.print_exc(file=sys.stderr)
            if on_error:
                call_ui(on_error, e)
            return
        if on_done:
            call_ui(on_done, result)

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    return t
