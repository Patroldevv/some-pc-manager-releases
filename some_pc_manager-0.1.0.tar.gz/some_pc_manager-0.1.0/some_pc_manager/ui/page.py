"""Sayfa tabanı ve uygulama bağlamı."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from . import anim


class Context:
    """Sayfaların paylaştığı durum ve gezinme erişimi."""

    def __init__(self, store, theme):
        self.store = store
        self.theme = theme
        self.window = None  # MainWindow tarafından atanır

    def go(self, name: str, **kw) -> None:
        self.window.go(name, **kw)

    def toast(self, text: str) -> None:
        self.window.toast(text)

    def show_banner(self, title: str, subtitle: str, on_done=None, done_label: str = "Bitti", warn: bool = False) -> None:
        self.window.show_banner(title, subtitle, on_done, done_label, warn)

    def notify(self, nid: str, title: str, body: str, page: str = "home", button: str | None = None) -> None:
        """İşlem sonucunu masaüstü bildirimi olarak gönderir (Ayarlar'dan kapatılabilir)."""
        app = self.window.get_application()
        if hasattr(app, "notify_user"):
            app.notify_user(nid, title, body, page, button, kind="result")

    def hide_banner(self) -> None:
        self.window.hide_banner()


class Page(Gtk.Box):
    """Pencere içindeki bir ekran. Kaydırılabilir kapsayıcıya window.py sarar."""

    name = ""
    tab = "home"          # kenar çubuğunda hangi sekme vurgulanır
    parent: str | None = None   # None: üst düzey sekme; aksi halde geri gidilecek sayfa
    footer: Gtk.Widget | None = None   # kaydırma alanının dışında, altta sabit duran birincil eylem

    def __init__(self, ctx: Context):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.ctx = ctx
        self.set_margin_start(14)
        self.set_margin_end(14)
        self.set_margin_top(4)
        self.set_margin_bottom(14)

    def animate_in(self) -> None:
        """Sayfanın ilk düzey öğelerini sırayla süzülerek belirt."""
        kids, c = [], self.get_first_child()
        while c is not None:
            if c.get_visible():
                kids.append(c)
            c = c.get_next_sibling()
        anim.stagger(kids)

    def scroll_to_top(self) -> None:
        sw = self.get_ancestor(Gtk.ScrolledWindow)
        if sw is not None:
            sw.get_vadjustment().set_value(0)

    def on_show(self, **kw) -> None:  # sayfa görünür olunca
        pass

    def on_hide(self) -> None:
        pass

    # Pencere gizlenince/yeniden görününce: varsayılan olarak zamanlayıcıları durdur/başlat.
    # Süren bir tarama/işlem olan sayfalar bunları boş bırakarak durumunu korur.
    def on_suspend(self) -> None:
        self.on_hide()

    def on_resume(self) -> None:
        self.on_show()
