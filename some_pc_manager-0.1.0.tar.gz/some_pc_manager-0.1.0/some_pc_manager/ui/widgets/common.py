"""Ortak widget'lar: kart, ölçüm çubuğu, dönen halka, kayan göstergeli şerit."""
from __future__ import annotations

import math
from typing import Callable, Iterable

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import Gdk, GLib, Graphene, Gtk, Pango  # noqa: E402

from .. import anim
from ..icons import Icon


# ---------------------------------------------------------------- yardımcılar

def label(text: str = "", css: str | Iterable[str] | None = None, *, xalign: float = 0.0,
          wrap: bool = False, ellipsize: bool = False, markup: bool = False) -> Gtk.Label:
    lb = Gtk.Label(xalign=xalign)
    if markup:
        lb.set_markup(text)
    else:
        lb.set_text(text)
    if css:
        for c in ([css] if isinstance(css, str) else css):
            for name in c.split():   # "muted small" gibi birleşik sınıf dizgelerini ayır
                lb.add_css_class(name)
    if wrap:
        lb.set_wrap(True)
        lb.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if ellipsize:
        lb.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
    return lb


def box(orientation=Gtk.Orientation.VERTICAL, spacing: int = 0, css: str | None = None, **kw) -> Gtk.Box:
    b = Gtk.Box(orientation=orientation, spacing=spacing, **kw)
    if css:
        b.add_css_class(css)
    return b


def hbox(spacing: int = 0, css: str | None = None, **kw) -> Gtk.Box:
    return box(Gtk.Orientation.HORIZONTAL, spacing, css, **kw)


def vbox(spacing: int = 0, css: str | None = None, **kw) -> Gtk.Box:
    return box(Gtk.Orientation.VERTICAL, spacing, css, **kw)


def button(text: str, css: str = "secondary", on_click: Callable | None = None) -> Gtk.Button:
    b = Gtk.Button(label=text)
    b.add_css_class(css)
    b.set_cursor_from_name("pointer")
    if on_click:
        b.connect("clicked", lambda *_: on_click())
    return b


def separator() -> Gtk.Box:
    s = Gtk.Box()
    s.add_css_class("sep")
    return s


WHEEL_STEP = 120     # fare tekerleği çentiği başına piksel


def enable_smooth_scroll(sw: Gtk.ScrolledWindow) -> None:
    """Fare tekerleğiyle kaydırmayı ani sıçrama yerine yumuşak (ease-out) animasyonla yapar.
    Art arda çentikler hedefi biriktirir; dokunmatik yüzey gibi hassas girdiler GTK'ye bırakılır."""
    state: dict = {"target": None}
    ctl = Gtk.EventControllerScroll.new(Gtk.EventControllerScrollFlags.VERTICAL)
    ctl.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)

    def on_scroll(c, _dx, dy) -> bool:
        if anim.reduce_motion() or c.get_unit() != Gdk.ScrollUnit.WHEEL:
            return False
        adj = sw.get_vadjustment()
        top = adj.get_upper() - adj.get_page_size()
        if top <= 0:
            return False
        cur = adj.get_value()
        base = state["target"] if state["target"] is not None else cur
        target = max(0.0, min(top, base + dy * WHEEL_STEP))
        if target == cur and state["target"] is None:
            return True
        state["target"] = target
        anim.stop(state.get("anim"))          # önceki animasyon çakışmasın
        dist = abs(target - cur)
        state["anim"] = anim.animate(sw, cur, target, int(240 + min(dist, 480) * 0.35), adj.set_value,
                                     done=lambda: state.update(target=None))
        return True

    ctl.connect("scroll", on_scroll)
    sw.add_controller(ctl)


def scrolled(child: Gtk.Widget) -> Gtk.ScrolledWindow:
    sw = Gtk.ScrolledWindow()
    enable_smooth_scroll(sw)
    sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sw.set_propagate_natural_height(False)
    sw.set_vexpand(True)
    sw.set_child(child)
    return sw


def rows_card(rows: list[Gtk.Widget]) -> Gtk.Box:
    """Satırları ince ayırıcılarla tek kart içinde dizer."""
    card = vbox(0, "rows-card")
    for i, r in enumerate(rows):
        if i:
            sep = Gtk.Box()
            sep.add_css_class("row-sep")
            card.append(sep)
        card.append(r)
    return card


# ---------------------------------------------------------------- ölçüm çubuğu

class StatBar(Gtk.Overlay):
    """Dikey ince çubuk; değeri yumuşakça değişir."""

    HEIGHT = 34

    def __init__(self) -> None:
        super().__init__()
        self._f = 0.0
        trough = Gtk.Box()
        trough.add_css_class("statbar-trough")
        trough.set_size_request(5, self.HEIGHT)
        self.set_child(trough)
        self._fill = Gtk.Box()
        self._fill.add_css_class("statbar-fill")
        self._fill.set_valign(Gtk.Align.END)
        self._fill.set_halign(Gtk.Align.FILL)
        self.add_overlay(self._fill)
        self.set_valign(Gtk.Align.CENTER)
        self.set_fraction(0)

    def set_fraction(self, f: float) -> None:
        self._f = max(0.0, min(1.0, f))
        self._fill.set_size_request(5, max(0, round(self.HEIGHT * self._f)))
        self._fill.set_visible(self._f > 0.01)

    def animate_to(self, f: float, ms: int = 700) -> None:
        anim.animate(self, self._f, f, ms, self.set_fraction)


# ---------------------------------------------------------------- dönen halka

class ProgressRing(Gtk.DrawingArea):
    """Belirsiz (dönen), belirli ilerleme ya da başarı (halka kapanır + tik çizilir) halkası.

    Dönerken yay uzunluğu soluk alır gibi büyüyüp küçülür (WinUI tarzı); `play_success`
    halkayı tamamlar ve tiki çizerek çizer. Rengi CSS `color` belirler.
    """

    def __init__(self, size: int = 20, line: float = 2.4, css: str = "ring-blue") -> None:
        super().__init__()
        self.set_content_width(size)
        self.set_content_height(size)
        self.add_css_class(css)
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self._line = line
        self._t = 0.0
        self._frac: float | None = None
        self._anim = None
        self._want_spin = False
        self._mode = "idle"            # idle | spin | frac | success
        self._p1 = self._p2 = 0.0
        self.set_draw_func(self._draw)
        self.connect("map", lambda *_: self._want_spin and self._begin())
        self.connect("unmap", lambda *_: self._halt())

    def _begin(self) -> None:
        if self._anim is None and not anim.reduce_motion():
            self._anim = anim.loop(self, self._tick, 1900)
        elif anim.reduce_motion():
            self.queue_draw()

    def _halt(self) -> None:
        anim.stop(self._anim)
        self._anim = None

    def _tick(self, v: float) -> None:
        self._t = v
        self.queue_draw()

    def start(self) -> None:
        self._frac, self._mode = None, "spin"
        self._p1 = self._p2 = 0.0
        self._want_spin = True
        if self.get_mapped():
            self._begin()
        self.queue_draw()

    def stop(self) -> None:
        self._want_spin = False
        self._mode = "idle"
        self._halt()
        self.queue_draw()

    def set_fraction(self, f: float) -> None:
        self._want_spin = False
        self._halt()
        self._mode, self._frac = "frac", max(0.0, min(1.0, f))
        self.queue_draw()

    def play_success(self, done=None) -> None:
        """Halkayı kapat, sonra tiki çiz; bitince `done()` çağır."""
        self._want_spin = False
        self._halt()
        self._mode = "success"
        self._p1 = self._p2 = 0.0

        def set1(v: float) -> None:
            self._p1 = v
            self.queue_draw()

        def set2(v: float) -> None:
            self._p2 = v
            self.queue_draw()

        def phase2() -> None:
            anim.animate(self, 0.0, 1.0, 340, set2, done, anim.EASE_OUT)

        anim.animate(self, 0.0, 1.0, 420, set1, phase2, anim.EASE_IN_OUT)

    def reset(self) -> None:
        self.stop()
        self._p1 = self._p2 = 0.0

    def _draw(self, _area, cr, w, h) -> None:
        c = self.get_color()
        cx, cy, r = w / 2, h / 2, min(w, h) / 2 - self._line
        cr.set_line_width(self._line)
        cr.set_line_cap(1)  # ROUND
        cr.set_line_join(1)
        cr.set_source_rgba(c.red, c.green, c.blue, 0.22 * c.alpha)
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.stroke()
        cr.set_source_rgba(c.red, c.green, c.blue, c.alpha)
        if self._mode == "spin":
            k = 0.5 - 0.5 * math.cos(2 * math.pi * self._t)          # 0 → 1 → 0
            sweep = math.radians(28) + math.radians(232) * k
            start = self._t * 4 * math.pi - math.pi / 2
            cr.arc(cx, cy, r, start, start + sweep)
            cr.stroke()
        elif self._mode == "frac" and self._frac is not None:
            cr.arc(cx, cy, r, -math.pi / 2, -math.pi / 2 + 2 * math.pi * self._frac)
            cr.stroke()
        elif self._mode == "success":
            if self._p1 > 0:
                cr.arc(cx, cy, r, -math.pi / 2, -math.pi / 2 + 2 * math.pi * self._p1)
                cr.stroke()
            if self._p2 > 0:
                s = min(w, h)
                p0, p1, p2 = (s * 0.29, s * 0.53), (s * 0.44, s * 0.67), (s * 0.72, s * 0.36)
                l1, l2 = math.dist(p0, p1), math.dist(p1, p2)
                d = self._p2 * (l1 + l2)
                cr.move_to(*p0)
                if d <= l1:
                    f = d / l1
                    cr.line_to(p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f)
                else:
                    f = (d - l1) / l2
                    cr.line_to(*p1)
                    cr.line_to(p1[0] + (p2[0] - p1[0]) * f, p1[1] + (p2[1] - p1[1]) * f)
                cr.stroke()


# ---------------------------------------------------------------- kayan gösterge

class SlideTrack(Gtk.Overlay):
    """İçeriğin üstünde, seçili öğeye kayan bir gösterge çizer.

    mode="bar": sol kenarda dikey çubuk (kenar çubuğu)
    mode="underline": öğenin altında yatay çizgi (sekme şeridi)
    """

    def __init__(self, content: Gtk.Widget, mode: str = "bar") -> None:
        super().__init__()
        self.mode = mode
        self.set_child(content)
        self._fixed = Gtk.Fixed()
        self._fixed.set_can_target(False)
        self._ind = Gtk.Box()
        self._ind.add_css_class("nav-indicator" if mode == "bar" else "tab-indicator")
        self._fixed.put(self._ind, 0, 0)
        self._ind.set_visible(False)
        self.add_overlay(self._fixed)
        self._cur: tuple[float, float, float] | None = None
        self._anim = None
        self._want = None

    def _rect(self, item: Gtk.Widget):
        if item.get_width() <= 0:
            return None
        ok, pt = item.compute_point(self, Graphene.Point().init(0, 0))
        if not ok:
            return None
        w, h = item.get_width(), item.get_height()
        if self.mode == "bar":
            return (0.0, pt.y + (h - 22) / 2, 3.0)
        return (pt.x + 6, pt.y + h - 3, max(8.0, w - 12.0))

    def move_to(self, item: Gtk.Widget, animate: bool = True) -> None:
        self._want = item          # son istenen öğe; eski bekleyen çağrılar bunu ezmesin
        rect = self._rect(item)
        if rect is None:  # henüz yerleşmedi: ilk kareyi bekle
            def tick(_w, _clock):
                if item is not self._want:
                    return GLib.SOURCE_REMOVE
                r = self._rect(item)
                if r is None:
                    return GLib.SOURCE_CONTINUE
                self._go(r, False)
                return GLib.SOURCE_REMOVE
            self.add_tick_callback(tick)
            return
        self._go(rect, animate)

    def _apply(self, x: float, y: float, w: float) -> None:
        self._cur = (x, y, w)
        self._fixed.move(self._ind, x, y)
        if self.mode == "underline":
            self._ind.set_size_request(round(w), 3)

    def _go(self, rect, animate: bool) -> None:
        self._ind.set_visible(True)
        anim.stop(self._anim)
        if self._cur is None or not animate:
            self._apply(*rect)
            return
        x0, y0, w0 = self._cur
        x1, y1, w1 = rect
        self._anim = anim.animate(
            self, 0.0, 1.0, 260,
            lambda t: self._apply(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, w0 + (w1 - w0) * t),
        )


class TabStrip(Gtk.Box):
    """Altı çizgili sekmeler. `on_select(index)` seçimde çağrılır."""

    def __init__(self, labels: list[str], on_select: Callable[[int], None]) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self._on_select = on_select
        row = hbox(2)
        self._tabs: list[Gtk.Button] = []
        for i, text in enumerate(labels):
            b = Gtk.Button()
            b.add_css_class("tab")
            b.set_child(Gtk.Label(label=text))
            b.set_cursor_from_name("pointer")
            b.connect("clicked", lambda _b, i=i: self.select(i))
            row.append(b)
            self._tabs.append(b)
        self._track = SlideTrack(row, "underline")
        self.append(self._track)
        self.index = -1

    def set_labels(self, labels: list[str]) -> None:
        for b, t in zip(self._tabs, labels):
            b.get_child().set_text(t)

    def select(self, i: int, animate: bool = True, notify: bool = True) -> None:
        if i == self.index:
            return
        self.index = i
        for j, b in enumerate(self._tabs):
            (b.add_css_class if j == i else b.remove_css_class)("active")
        self._track.move_to(self._tabs[i], animate)
        if notify:
            self._on_select(i)


class Segmented(Gtk.Box):
    """Küçük hap şeklinde seçim (örn. tema: Sistem / Açık / Koyu)."""

    def __init__(self, options: list[tuple[str, str]], value: str, on_change: Callable[[str], None]) -> None:
        super().__init__(spacing=2)
        self.add_css_class("segmented")
        self._on_change = on_change
        self._buttons: dict[str, Gtk.Button] = {}
        for key, text in options:
            b = Gtk.Button(label=text)
            b.add_css_class("seg")
            b.set_cursor_from_name("pointer")
            b.connect("clicked", lambda _b, k=key: self.set_value(k, True))
            self.append(b)
            self._buttons[key] = b
        self.set_value(value, False)

    def set_value(self, key: str, notify: bool = False) -> None:
        for k, b in self._buttons.items():
            (b.add_css_class if k == key else b.remove_css_class)("active")
        self.value = key
        if notify:
            self._on_change(key)


# ---------------------------------------------------------------- satır oluşturucular

def setting_row(title: str, subtitle: str | None, trailing: Gtk.Widget, icon: str | None = None) -> Gtk.Box:
    row = hbox(12, "row")
    if icon:
        row.append(Icon(icon, 20))
    text = vbox(2)
    text.set_hexpand(True)
    text.set_valign(Gtk.Align.CENTER)
    text.append(label(title))
    if subtitle:
        text.append(label(subtitle, "muted", wrap=True))
    row.append(text)
    trailing.set_valign(Gtk.Align.CENTER)
    row.append(trailing)
    return row


def switch(active: bool, on_toggle: Callable[[bool], None]) -> Gtk.Switch:
    sw = Gtk.Switch()
    sw.set_active(active)
    sw.set_cursor_from_name("pointer")
    sw.connect("notify::active", lambda s, _p: on_toggle(s.get_active()))
    return sw
