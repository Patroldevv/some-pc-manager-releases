"""Canlı çizgi grafik (sparkline): yumuşak eğri, gradyan dolgu, akıcı kayan zaman ekseni."""
from __future__ import annotations

import collections
import math

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gtk  # noqa: E402

from .. import anim
from ..icons import Icon


def _rgba(role: str) -> Gdk.RGBA:
    c = Gdk.RGBA()
    theme = Icon.theme
    c.parse(theme.color(role) if theme else "#0F5FBF")
    return c


class Sparkline(Gtk.DrawingArea):
    """`push(*değerler)` ile yeni örnek ekler; çizgi bir adım kayarken yumuşakça ilerler."""

    def __init__(self, series: int = 1, capacity: int = 48, max_value: float | None = 100.0,
                 roles: tuple[str, ...] = ("blue", "green"), height: int = 64, interval_ms: int = 1000) -> None:
        super().__init__()
        self.set_content_height(height)
        self.set_hexpand(True)
        self.add_css_class("sparkline")
        self._cap = capacity
        self._max = max_value
        self._roles = roles
        self._interval = interval_ms
        self._data = [collections.deque([0.0] * capacity, maxlen=capacity) for _ in range(series)]
        self._t = 1.0
        self._anim = None
        self._primed = False
        self.set_draw_func(self._draw)

    def push(self, *values: float) -> None:
        if not self._primed:     # ilk örnekte geçmişi aynı değerle doldur: sıfırdan sıçrama olmasın
            for d, v in zip(self._data, values):
                d.extend([float(v)] * self._cap)
            self._primed = True
        for d, v in zip(self._data, values):
            d.append(float(v))
        anim.stop(self._anim)
        self._t = 0.0
        self._anim = anim.animate(self, 0.0, 1.0, int(self._interval * 0.95), self._set_t, easing=anim.LINEAR)

    def _set_t(self, t: float) -> None:
        self._t = t
        self.queue_draw()

    def _scale(self) -> float:
        if self._max is not None:
            return self._max
        return max(1.0, max(max(d) for d in self._data) * 1.25)

    def _draw(self, _area, cr, w, h) -> None:
        import cairo
        pad = 4.0
        step = w / (self._cap - 1)
        top = self._scale()
        cr.rectangle(0, 0, w, h)
        cr.clip()
        # Hafif yatay kılavuz çizgileri
        c0 = self.get_color()
        cr.set_line_width(1)
        for frac in (0.25, 0.5, 0.75):
            y = round(h - pad - frac * (h - 2 * pad)) + 0.5
            cr.set_source_rgba(c0.red, c0.green, c0.blue, 0.10)
            cr.move_to(0, y)
            cr.line_to(w, y)
            cr.stroke()

        for idx, d in enumerate(self._data):
            col = _rgba(self._roles[idx % len(self._roles)])
            pts = []
            for i, v in enumerate(d):
                x = w - (self._cap - 1 - i) * step + (1 - self._t) * step
                y = h - pad - min(1.0, v / top) * (h - 2 * pad)
                pts.append((x, y))
            # Catmull-Rom -> kübik Bézier
            cr.new_path()
            cr.move_to(*pts[0])
            for i in range(len(pts) - 1):
                p0 = pts[i - 1] if i > 0 else pts[i]
                p1, p2 = pts[i], pts[i + 1]
                p3 = pts[i + 2] if i + 2 < len(pts) else p2
                cr.curve_to(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
                            p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1])
            path = cr.copy_path()
            if idx == 0 or len(self._data) == 1:       # yalnızca ilk seri altına dolgu
                cr.line_to(pts[-1][0], h)
                cr.line_to(pts[0][0], h)
                cr.close_path()
                g = cairo.LinearGradient(0, 0, 0, h)
                g.add_color_stop_rgba(0, col.red, col.green, col.blue, 0.30)
                g.add_color_stop_rgba(1, col.red, col.green, col.blue, 0.0)
                cr.set_source(g)
                cr.fill()
            cr.new_path()
            cr.append_path(path)
            cr.set_line_width(1.9)
            cr.set_line_join(cairo.LINE_JOIN_ROUND)
            cr.set_line_cap(cairo.LINE_CAP_ROUND)
            cr.set_source_rgba(col.red, col.green, col.blue, 1)
            cr.stroke()
            # Son değer noktası ve hale
            lx, ly = min(pts[-1][0], w - 4), pts[-1][1]
            cr.set_source_rgba(col.red, col.green, col.blue, 0.22)
            cr.arc(lx, ly, 6, 0, 2 * math.pi)
            cr.fill()
            cr.set_source_rgba(col.red, col.green, col.blue, 1)
            cr.arc(lx, ly, 2.8, 0, 2 * math.pi)
            cr.fill()
