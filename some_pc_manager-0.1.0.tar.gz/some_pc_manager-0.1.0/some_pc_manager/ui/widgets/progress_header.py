"""Çizim + başlık + ilerleme çubuğu + durum satırı (Sağlık Kontrolü / Temizleme)."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from .. import anim
from ..icons import Icon, illustration
from .bar import SmoothBar
from .common import hbox, label, vbox


class ProgressHeader(Gtk.Box):
    def __init__(self, art: str = "laptop", size: tuple[int, int] = (88, 66)) -> None:
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        self._frac = 0.0

        ov = Gtk.Overlay()
        ov.set_child(illustration(art, *size))
        self._badge = Gtk.Revealer()
        self._badge.set_transition_type(Gtk.RevealerTransitionType.CROSSFADE)
        self._badge.set_transition_duration(300)
        self._badge.set_halign(Gtk.Align.END)
        self._badge.set_valign(Gtk.Align.END)
        b = Gtk.CenterBox()
        b.add_css_class("badge-ok")
        b.set_center_widget(Icon("check", 14, "white"))
        self._badge.set_child(b)
        ov.add_overlay(self._badge)
        ov.set_valign(Gtk.Align.CENTER)
        self.append(ov)

        col = vbox(6)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        top = hbox(8)
        self.title = label("", "title-2", wrap=True)
        self.title.set_hexpand(True)
        top.append(self.title)
        self.side = hbox(6)            # sağ üstte İptal / Bitti düğmeleri için
        self.side.set_valign(Gtk.Align.START)
        top.append(self.side)
        col.append(top)
        self._bar_row = hbox(10)
        self.bar = SmoothBar(6)
        self._bar_row.append(self.bar)
        self._pct = label("", "muted small")
        self._pct.set_width_chars(4)
        self._pct.set_xalign(1.0)
        self._bar_row.append(self._pct)
        col.append(self._bar_row)
        self.status = label("", "muted", wrap=True)
        col.append(self.status)
        self.append(col)

    def set_progress(self, f: float, ms: int = 400) -> None:
        """Çubuğu ve yüzdeyi yumuşakça ilerletir; %100'e ulaşınca ışık hüzmesi söner."""
        ms = max(ms, 550)
        anim.animate(self, self._frac, f, ms, lambda v: self._pct.set_text(f"%{round(v * 100)}"))
        self.bar.animate_to(f, ms)
        self.bar.set_busy(f < 1.0)
        self._frac = f

    def reset(self) -> None:
        self._frac = 0.0
        self.bar.set_fraction(0)
        self._pct.set_text("%0")
        self._bar_row.set_visible(True)
        self._bar_row.set_opacity(1.0)
        self.bar.set_tone("blue")
        self.bar.set_busy(True)
        self._badge.set_reveal_child(False)

    def set_done(self, done: bool = True) -> None:
        self._badge.set_reveal_child(done)
        self.bar.set_busy(False)
        if done:
            anim.fade(self._bar_row, 0.0, 300, lambda: self._bar_row.set_visible(False))
        else:
            self._bar_row.set_visible(True)
            self._bar_row.set_opacity(1.0)
