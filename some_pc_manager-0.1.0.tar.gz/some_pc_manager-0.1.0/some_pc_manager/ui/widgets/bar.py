"""Akıcı ilerleme çubuğu: yumuşak dolum, parlayan ışık hüzmesi ve belirsiz (kayan) kip."""
from __future__ import annotations

import math

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from .. import anim

TONES = ("blue", "green", "warn", "danger")


def rounded_rect(cr, x: float, y: float, w: float, h: float, r: float) -> None:
    r = max(0.0, min(r, h / 2, w / 2))
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


class SmoothBar(Gtk.DrawingArea):
    """İnce ilerleme çubuğu. Rengi CSS `color` (ton sınıfları) belirler.

    - `animate_to(f)`: değere yumuşakça ilerler (ease-out)
    - `set_busy(True)`: dolu kısımda sürekli süzülen bir ışık hüzmesi
    - `set_indeterminate(True)`: süre belli değilken kayan parça
    """

    def __init__(self, height: int = 5, tone: str = "blue") -> None:
        super().__init__()
        self.set_content_height(height)
        self.set_hexpand(True)
        self.set_valign(Gtk.Align.CENTER)
        self.add_css_class("smoothbar")
        self._tone = ""
        self.set_tone(tone)
        self._shown = 0.0
        self._target = 0.0
        self._phase = 0.0
        self._busy = False
        self._indet = False
        self._loop = None
        self._anim = None
        self.set_draw_func(self._draw)
        self.connect("map", lambda *_: self._sync_loop())
        self.connect("unmap", lambda *_: self._halt())

    # ------------------------------------------------------------ durum
    @property
    def fraction(self) -> float:
        return self._target

    def set_tone(self, tone: str) -> None:
        if tone == self._tone:
            return
        if self._tone:
            self.remove_css_class(f"tone-{self._tone}")
        self._tone = tone
        self.add_css_class(f"tone-{tone}")
        self.queue_draw()

    def set_fraction(self, f: float) -> None:
        anim.stop(self._anim)
        self._target = self._shown = max(0.0, min(1.0, f))
        self.queue_draw()

    def animate_to(self, f: float, ms: int = 650) -> None:
        f = max(0.0, min(1.0, f))
        anim.stop(self._anim)
        self._target = f
        self._anim = anim.animate(self, self._shown, f, ms, self._set_shown)

    def _set_shown(self, v: float) -> None:
        self._shown = v
        self.queue_draw()

    def set_busy(self, on: bool) -> None:
        self._busy = on
        self._sync_loop()

    def set_indeterminate(self, on: bool) -> None:
        self._indet = on
        self._sync_loop()

    # ------------------------------------------------------------ döngü
    def _sync_loop(self) -> None:
        want = (self._busy or self._indet) and self.get_mapped() and not anim.reduce_motion()
        if want and self._loop is None:
            self._loop = anim.loop(self, self._tick, 1600)
        elif not want:
            self._halt()
            self.queue_draw()

    def _halt(self) -> None:
        anim.stop(self._loop)
        self._loop = None

    def _tick(self, v: float) -> None:
        self._phase = v
        self.queue_draw()

    # ------------------------------------------------------------ çizim
    def _draw(self, _area, cr, w, h) -> None:
        c = self.get_color()
        r = h / 2
        cr.set_source_rgba(c.red, c.green, c.blue, 0.18 * c.alpha)
        rounded_rect(cr, 0, 0, w, h, r)
        cr.fill()

        if self._indet:
            cr.save()
            rounded_rect(cr, 0, 0, w, h, r)
            cr.clip()
            t = self._phase * self._phase * (3 - 2 * self._phase)      # ease-in-out
            seg = w * 0.4
            x = -seg + (w + seg) * t
            cr.set_source_rgba(c.red, c.green, c.blue, c.alpha)
            rounded_rect(cr, x, 0, seg, h, r)
            cr.fill()
            t2 = min(1.0, max(0.0, self._phase * 1.15 - 0.15))          # ikinci, daha kısa parça
            x2 = -seg * 0.5 + (w + seg * 0.5) * (t2 * t2 * (3 - 2 * t2))
            cr.set_source_rgba(c.red, c.green, c.blue, 0.55 * c.alpha)
            rounded_rect(cr, x2, 0, seg * 0.5, h, r)
            cr.fill()
            cr.restore()
            return

        fw = w * self._shown
        if fw <= 0.5:
            return
        fw = max(fw, h)
        import cairo  # yerel içe aktarma: yalnızca çizimde gerekli
        grad = cairo.LinearGradient(0, 0, fw, 0)
        grad.add_color_stop_rgba(0, c.red, c.green, c.blue, c.alpha)
        grad.add_color_stop_rgba(1, min(1, c.red + 0.16), min(1, c.green + 0.16), min(1, c.blue + 0.16), c.alpha)
        cr.set_source(grad)
        rounded_rect(cr, 0, 0, fw, h, r)
        cr.fill()

        if self._busy and fw > h * 3:
            cr.save()
            rounded_rect(cr, 0, 0, fw, h, r)
            cr.clip()
            band = min(70.0, fw * 0.7)
            x = self._phase * (fw + band) - band
            sh = cairo.LinearGradient(x, 0, x + band, 0)
            sh.add_color_stop_rgba(0, 1, 1, 1, 0)
            sh.add_color_stop_rgba(0.5, 1, 1, 1, 0.42)
            sh.add_color_stop_rgba(1, 1, 1, 1, 0)
            cr.set_source(sh)
            cr.rectangle(x, 0, band, h)
            cr.fill()
            cr.restore()
