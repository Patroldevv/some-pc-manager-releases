"""Sistem tepsisi simgesi (StatusNotifierItem, DBus). Menü içermez:
sol tık pencereyi açar/gizler, orta tık hızlı hızlandırma yapar, sağ tık pencereyi açar.
Tepsi (watcher) yoksa sessizce devre dışı kalır."""
from __future__ import annotations

import os
from typing import Callable

import gi

gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gio, GLib, GdkPixbuf  # noqa: E402

from .icons import ICON_DIR

PATH = "/StatusNotifierItem"
IFACE = "org.kde.StatusNotifierItem"
WATCHER = "org.kde.StatusNotifierWatcher"

XML = """
<node>
  <interface name="org.kde.StatusNotifierItem">
    <property name="Category" type="s" access="read"/>
    <property name="Id" type="s" access="read"/>
    <property name="Title" type="s" access="read"/>
    <property name="Status" type="s" access="read"/>
    <property name="WindowId" type="u" access="read"/>
    <property name="IconName" type="s" access="read"/>
    <property name="IconPixmap" type="a(iiay)" access="read"/>
    <property name="OverlayIconName" type="s" access="read"/>
    <property name="AttentionIconName" type="s" access="read"/>
    <property name="ToolTip" type="(sa(iiay)ss)" access="read"/>
    <property name="ItemIsMenu" type="b" access="read"/>
    <method name="ContextMenu"><arg type="i" name="x" direction="in"/><arg type="i" name="y" direction="in"/></method>
    <method name="Activate"><arg type="i" name="x" direction="in"/><arg type="i" name="y" direction="in"/></method>
    <method name="SecondaryActivate"><arg type="i" name="x" direction="in"/><arg type="i" name="y" direction="in"/></method>
    <method name="Scroll"><arg type="i" name="delta" direction="in"/><arg type="s" name="orientation" direction="in"/></method>
    <signal name="NewIcon"/>
    <signal name="NewToolTip"/>
    <signal name="NewStatus"><arg type="s" name="status"/></signal>
  </interface>
</node>
"""


def argb_pixmap(size: int) -> tuple[int, int, list[int]]:
    """Uygulama logosunu StatusNotifierItem'ın beklediği ARGB32 (ağ bayt sırası) dizisine çevirir."""
    pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(ICON_DIR / "app-logo.svg"), size, size, True)
    if not pix.get_has_alpha():
        pix = pix.add_alpha(False, 0, 0, 0)
    w, h, stride, data = pix.get_width(), pix.get_height(), pix.get_rowstride(), pix.get_pixels()
    out: list[int] = []
    for y in range(h):
        row = y * stride
        for x in range(w):
            r, g, b, a = data[row + x * 4: row + x * 4 + 4]
            out += [a, r, g, b]
    return w, h, out


class Tray:
    def __init__(self, on_activate: Callable[[], None], on_secondary: Callable[[], None],
                 on_context: Callable[[], None] | None = None) -> None:
        self._on_activate = on_activate
        self._on_secondary = on_secondary
        self._on_context = on_context or on_activate
        self._tooltip = "Some PC Manager"
        self.registered = False
        self.error = ""
        self._conn: Gio.DBusConnection | None = None
        self._reg_id = 0
        self._info = Gio.DBusNodeInfo.new_for_xml(XML).interfaces[0]
        try:
            self._pixmaps = [argb_pixmap(24), argb_pixmap(48)]
        except GLib.Error:
            self._pixmaps = []
        self.name = f"org.kde.StatusNotifierItem-{os.getpid()}-1"
        self._own = Gio.bus_own_name(Gio.BusType.SESSION, self.name, Gio.BusNameOwnerFlags.NONE,
                                     self._bus_acquired, None, None)
        self._watch = Gio.bus_watch_name(Gio.BusType.SESSION, WATCHER, Gio.BusNameWatcherFlags.NONE,
                                         self._watcher_appeared, self._watcher_vanished)

    # ------------------------------------------------------------ DBus
    def _bus_acquired(self, conn: Gio.DBusConnection, _name: str) -> None:
        self._conn = conn
        try:
            self._reg_id = conn.register_object(PATH, self._info, self._on_method, self._get_prop, None)
        except GLib.Error:
            self._conn = None

    def _watcher_appeared(self, conn: Gio.DBusConnection, _name: str, _owner: str) -> None:
        def done(src, res) -> None:
            try:
                src.call_finish(res)
                self.registered = True
            except GLib.Error as e:
                self.registered = False
                self.error = e.message

        conn.call(WATCHER, "/StatusNotifierWatcher", WATCHER, "RegisterStatusNotifierItem",
                  GLib.Variant("(s)", (self.name,)), None, Gio.DBusCallFlags.NONE, 2000, None, done)

    def _watcher_vanished(self, _conn, _name) -> None:
        self.registered = False

    def _on_method(self, _conn, _sender, _path, _iface, method, _params, invocation) -> None:
        if os.environ.get("SPM_DEBUG"):
            print("tray method:", method, "from", _sender, flush=True)
        handler = {"Activate": self._on_activate, "SecondaryActivate": self._on_secondary,
                   "ContextMenu": self._on_context}.get(method)
        if handler:
            GLib.idle_add(lambda: (handler(), False)[1])
        invocation.return_value(None)

    def _get_prop(self, _conn, _sender, _path, _iface, prop: str):
        simple = {
            "Category": ("s", "ApplicationStatus"), "Id": ("s", "some-pc-manager"),
            "Title": ("s", "Some PC Manager"), "Status": ("s", "Active"), "WindowId": ("u", 0),
            "IconName": ("s", ""), "OverlayIconName": ("s", ""), "AttentionIconName": ("s", ""),
            "ItemIsMenu": ("b", False),
        }
        if prop in simple:
            t, v = simple[prop]
            return GLib.Variant(t, v)
        if prop == "IconPixmap":
            return GLib.Variant("a(iiay)", [(w, h, data) for w, h, data in self._pixmaps])
        if prop == "ToolTip":
            return GLib.Variant("(sa(iiay)ss)", ("", [], "Some PC Manager", self._tooltip))
        return None

    # ------------------------------------------------------------ dışarıya
    def set_tooltip(self, text: str) -> None:
        self._tooltip = text
        if self._conn is not None:
            try:
                self._conn.emit_signal(None, PATH, IFACE, "NewToolTip", None)
            except GLib.Error:
                pass

    def close(self) -> None:
        if self._conn is not None and self._reg_id:
            self._conn.unregister_object(self._reg_id)
            self._reg_id = 0
        Gio.bus_unown_name(self._own)
        Gio.bus_unwatch_name(self._watch)
