"""Pencere gizliyken de çalışan hafif izleyici. Yalnızca bildirim gönderir; kendiliğinden hiçbir şey silmez."""
from __future__ import annotations

import time

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib  # noqa: E402

from ..core import boost, sysinfo
from ..core.apps import AppSampler
from ..core.util import format_size
from .tasks import run_async

TICK_SECONDS = 60
MEM_ALERT_PERCENT = 90.0
MEM_ALERT_TICKS = 3                 # ardışık 3 dakika yüksekse uyar
MEM_COOLDOWN = 30 * 60
DISK_FREE_FRACTION = 0.10
DISK_FREE_BYTES = 5 * 1024**3
DISK_COOLDOWN = 12 * 3600


def should_alert_memory(percent: float, high_ticks: int, now: float, last_alert: float) -> bool:
    return percent >= MEM_ALERT_PERCENT and high_ticks >= MEM_ALERT_TICKS and now - last_alert >= MEM_COOLDOWN


SMART_INTERVAL = 6 * 3600
SMART_NOTIFY_MIN = 5 * 1024**2      # bundan az temizlendiyse bildirim gönderme


def should_run_smart_boost(enabled: bool, now: float, last: float, interval: float = SMART_INTERVAL) -> bool:
    return enabled and now - last >= interval


def should_alert_disk(total: int, free: int, now: float, last_alert: float) -> bool:
    if total <= 0 or now - last_alert < DISK_COOLDOWN:
        return False
    return free / total < DISK_FREE_FRACTION or free < DISK_FREE_BYTES


class Background:
    def __init__(self, app, ctx, tray=None) -> None:
        self.app, self.ctx, self.tray = app, ctx, tray
        self._sampler = AppSampler()
        self._high_ticks = 0
        self._last_mem = 0.0
        self._last_disk = 0.0
        self._busy = False
        GLib.timeout_add_seconds(TICK_SECONDS, self._tick)
        GLib.timeout_add_seconds(5, self._tick_once)

    def _tick_once(self) -> bool:
        self._tick()
        return GLib.SOURCE_REMOVE

    # ------------------------------------------------------------ bildirim
    def notify(self, nid: str, title: str, body: str, page: str = "home", button: str | None = None,
               kind: str = "alert") -> None:
        self.app.notify_user(nid, title, body, page, button, kind)

    # ------------------------------------------------------------ izleme
    def _tick(self) -> bool:
        if self._busy:
            return GLib.SOURCE_CONTINUE
        self._busy = True

        def gather():
            mem = sysinfo.memory()
            disk = sysinfo.disk("/")
            top = [a.name for a in self._sampler.sample()[:3]] if mem.percent >= MEM_ALERT_PERCENT else []
            return mem, disk, top

        run_async(gather, self._evaluate, lambda _e: setattr(self, "_busy", False))
        return GLib.SOURCE_CONTINUE

    def _evaluate(self, r) -> None:
        self._busy = False
        mem, disk, top = r
        if self.tray:
            self.tray.set_tooltip(f"Bellek %{mem.percent:.0f} · Disk boş {format_size(disk.free)}")
        now = time.time()
        store = self.ctx.store
        if should_run_smart_boost(store.setting("smart_boost"), now, store.get("last_smart_boost")):
            store.set("last_smart_boost", now)
            self._smart_boost()
        if not store.setting("smart_notify"):
            return
        self._high_ticks = self._high_ticks + 1 if mem.percent >= MEM_ALERT_PERCENT else 0
        if should_alert_memory(mem.percent, self._high_ticks, now, self._last_mem):
            self._last_mem = now
            who = ", ".join(top) if top else "bazı uygulamalar"
            self.notify("mem-high", f"Bellek kullanımı yüksek (%{mem.percent:.0f})",
                        f"En çok bellek kullananlar: {who}", "apps:processes", "Uygulamaları aç")
        if should_alert_disk(disk.total, disk.free, now, self._last_disk):
            self._last_disk = now
            self.notify("disk-low", "Disk dolmak üzere",
                        f"Boş alan: {format_size(disk.free)}. Derin temizlik yer açabilir.", "cleanup", "Temizle")

    # ------------------------------------------------------------ otomatik ve hızlı eylemler
    def _record(self, kind: str, res: boost.BoostResult, title: str, notify_min: int = 0) -> None:
        store = self.ctx.store
        summary = boost.summarize(res)
        store.set("last_boost_freed", res.temp_freed)
        store.add_cleaned(res.temp_freed + res.cache_released)
        store.add_history(kind, res.temp_freed + res.cache_released, summary)
        if res.temp_freed >= notify_min:
            self.notify(kind, title, summary, "history", kind="result")

    def _smart_boost(self) -> None:
        """Akıllı Hızlandırma: boşta iken düzenli, güvenli (yalnızca eski geçici dosyalar) temizlik."""
        run_async(lambda: boost.boost(False),
                  lambda res: self._record("smart", res, "Akıllı Hızlandırma çalıştı", SMART_NOTIFY_MIN))

    def quick_boost(self) -> None:
        """Tepsiye orta tıkla: pencereyi açmadan hızlandır ve sonucu bildir."""
        run_async(lambda: boost.boost(False),
                  lambda res: self._record("quick", res, "RAM optimizasyonu tamamlandı"))
