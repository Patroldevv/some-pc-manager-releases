"""Ana pencere: özel başlık çubuğu, kenar çubuğu, sayfa yığını ve kayan bildirim."""
from __future__ import annotations

import os
import subprocess

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk, Pango  # noqa: E402

from . import anim
from .icons import Icon, illustration
from .page import Context, Page
from .widgets.common import SlideTrack, button, hbox, label, scrolled, vbox

WIDTH, HEIGHT = 415, 605

TABS = [
    ("home", "Ana Sayfa", "home"),
    ("protection", "Koruma", "shield"),
    ("storage", "Depolama", "pie"),
    ("apps", "Uygulamalar", "apps"),
    ("toolbox", "Araçlar", "toolbox"),
]
BOTTOM = [
    ("settings", "Ayarlar", "gear"),
    ("feedback", "Geri bildirim", "feedback"),
]


def _nav_button(text: str, icon: str, on_click) -> tuple[Gtk.Button, Icon]:
    b = Gtk.Button()
    b.add_css_class("nav-item")
    b.set_cursor_from_name("pointer")
    v = vbox(0)
    ic = Icon(icon, 22, "text")
    lb = label(text, "nav-label", xalign=0.5, wrap=True)
    lb.set_wrap_mode(Pango.WrapMode.WORD)
    lb.set_justify(Gtk.Justification.CENTER)
    v.append(ic)
    v.append(lb)
    b.set_child(v)
    b.connect("clicked", lambda *_: on_click())
    return b, ic


class Sidebar(Gtk.Box):
    def __init__(self, window: "MainWindow"):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("sidebar")
        self._buttons: dict[str, tuple[Gtk.Button, Icon]] = {}
        content = vbox(0)
        content.set_vexpand(True)
        for key, text, icon in TABS:
            content.append(self._add(window, key, text, icon))
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        content.append(spacer)
        for key, text, icon in BOTTOM:
            content.append(self._add(window, key, text, icon))
        self._track = SlideTrack(content, "bar")
        self._track.set_vexpand(True)
        self.append(self._track)
        self._active: str | None = None

    def _add(self, window, key, text, icon) -> Gtk.Button:
        b, ic = _nav_button(text, icon, lambda k=key: window.go(k))
        self._buttons[key] = (b, ic)
        return b

    def select(self, key: str, animate: bool = True) -> None:
        if key == self._active:
            return
        self._active = key
        for k, (b, ic) in self._buttons.items():
            on = k == key
            (b.add_css_class if on else b.remove_css_class)("active")
            ic.set_icon(role="blue" if on else "text", filled=on)
        self._track.move_to(self._buttons[key][0], animate)


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app, ctx: Context, page_classes: list[type[Page]]):
        super().__init__(application=app)
        self.ctx = ctx
        ctx.window = self
        self.add_css_class("pcm")
        self.set_title("Some PC Manager")
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_default_size(WIDTH, HEIGHT)
        self.set_size_request(WIDTH, HEIGHT)

        self._toasts = Adw.ToastOverlay()
        root = vbox(0)
        self._toasts.set_child(root)
        self.set_child(self._toasts)

        root.append(self._build_titlebar())
        body = hbox(0)
        body.set_vexpand(True)
        self.sidebar = Sidebar(self)
        body.append(self.sidebar)

        # Sayfalar crossfade ile değil, "söndür → değiştir → belir" ile geçer (yazılar üst üste binmez).
        self.stack = Gtk.Stack()
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
        self.stack.set_hhomogeneous(True)
        self.stack.set_vhomogeneous(True)

        # Kayan bildirim için katman: yığının üstünde, altta
        self._overlay = Gtk.Overlay()
        self._overlay.set_hexpand(True)
        self._overlay.set_vexpand(True)
        self._overlay.add_css_class("content-panel")
        self._overlay.set_child(self.stack)
        self._banner = Gtk.Revealer()
        self._banner.set_transition_type(Gtk.RevealerTransitionType.SLIDE_UP)
        self._banner.set_transition_duration(380)
        self._banner.set_valign(Gtk.Align.END)
        self._banner.set_halign(Gtk.Align.FILL)
        self._banner.set_margin_start(14)
        self._banner.set_margin_end(14)
        self._banner.set_margin_bottom(14)
        self._overlay.add_overlay(self._banner)
        body.append(self._overlay)
        root.append(body)

        self.pages: dict[str, Page] = {}
        for cls in page_classes:
            page = cls(ctx)
            self.pages[page.name] = page
            self.stack.add_named(self._wrap(page), page.name)
        self.current: str | None = None
        self._token = 0
        self._live = False     # geçerli sayfa şu an görünür/etkin mi (zamanlayıcılar çalışıyor mu)

        self.connect("map", lambda *_: GLib.timeout_add(300, self._hypr_float))
        self.connect("map", lambda *_: self.resume())
        self.connect("unmap", lambda *_: self.suspend())
        self._root = root
        root.set_opacity(0.0)
        self.connect("map", lambda *_: anim.fade(self._root, 1.0, 380))

    # ------------------------------------------------------------ sayfa kapsayıcısı
    def _wrap(self, page: Page) -> Gtk.Widget:
        """Kaydırılabilir sayfa + (varsa) altta sabit duran birincil eylem."""
        holder = vbox(0)
        holder.append(scrolled(page))
        if page.footer is not None:
            bar = hbox(0, "footer-bar")
            bar.append(page.footer)
            page.footer.set_hexpand(True)
            page.footer.bind_property("visible", bar, "visible", 0)   # düğmeyle birlikte gizlenir
            bar.set_visible(page.footer.get_visible())
            holder.append(bar)
        return holder

    # ------------------------------------------------------------ başlık çubuğu
    def _build_titlebar(self) -> Gtk.Widget:
        tb = hbox(0, "titlebar-pcm")
        self._back_rev = Gtk.Revealer()
        self._back_rev.set_transition_type(Gtk.RevealerTransitionType.SLIDE_RIGHT)
        self._back_rev.set_transition_duration(220)
        back = Gtk.Button()
        back.add_css_class("backbtn")
        back.set_focusable(False)
        back.set_child(Icon("back", 16))
        back.set_cursor_from_name("pointer")
        back.connect("clicked", lambda *_: self.go_back())
        self._back_rev.set_child(back)
        tb.append(self._back_rev)
        tb.append(Icon("app-logo", 20, None))
        tb.append(label("Some PC Manager", "app-title"))
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        tb.append(spacer)
        for icon, css, action in (("minimize", "", self.minimize), ("close", "close", self.close)):
            b = Gtk.Button()
            b.add_css_class("winbtn")
            b.set_focusable(False)
            if css:
                b.add_css_class(css)
            b.set_child(Icon(icon, 16))
            b.set_cursor_from_name("pointer")
            b.connect("clicked", lambda *_, a=action: a())
            tb.append(b)
        handle = Gtk.WindowHandle()
        handle.set_child(tb)
        return handle

    # ------------------------------------------------------------ gezinme
    def go(self, name: str, **kw) -> None:
        new = self.pages[name]
        old = self.pages.get(self.current) if self.current else None
        if old is new:
            new.on_show(**kw)
            return
        self._token += 1
        token = self._token
        self.current = name
        self.sidebar.select(new.tab, animate=old is not None)
        self._back_rev.set_reveal_child(new.parent is not None)
        self.hide_banner()
        if old:
            old.on_hide()

        def swap() -> None:
            if token != self._token:    # arada yeni bir gezinme başladıysa onu bekle
                return
            new.scroll_to_top()
            self.stack.set_visible_child_name(name)
            new.on_show(**kw)
            self._live = True
            new.animate_in()
            anim.animate(self.stack, self.stack.get_opacity(), 1.0, 160, self.stack.set_opacity)

        if old is None or anim.reduce_motion():
            self.stack.set_opacity(1.0)
            swap()
        else:
            anim.animate(self.stack, self.stack.get_opacity(), 0.0, 90, self.stack.set_opacity, swap,
                         anim.EASE_IN_OUT)

    def suspend(self) -> None:
        """Pencere gizlenince/simge durumuna alınınca sayfa zamanlayıcılarını durdurur."""
        page = self.pages.get(self.current) if self.current else None
        if page and self._live:
            page.on_suspend()
            self._live = False

    def resume(self) -> None:
        """Pencere yeniden görününce sayfayı canlandırır."""
        page = self.pages.get(self.current) if self.current else None
        if page and not self._live:
            self._live = True
            page.on_resume()
            page.animate_in()
            anim.fade(self._root, 1.0, 300)

    def go_back(self) -> None:
        page = self.pages.get(self.current)
        if page and page.parent:
            self.go(page.parent)

    # ------------------------------------------------------------ bildirimler
    def toast(self, text: str) -> None:
        t = Adw.Toast.new(text)
        t.set_timeout(2)
        self._toasts.add_toast(t)

    def show_banner(self, title: str, subtitle: str, on_done=None, done_label: str = "Bitti", warn: bool = False) -> None:
        """Pencerenin altında kayarak beliren yüzen kart (Sağlık Kontrolü tamamlandı vb.)."""
        card = hbox(14, "banner")
        art = Gtk.Overlay()
        art.set_child(illustration("laptop", 60, 45))
        badge = Gtk.CenterBox()
        badge.add_css_class("badge-warn" if warn else "badge-ok")
        badge.set_center_widget(Icon("warning" if warn else "check", 14, "white"))
        badge.set_halign(Gtk.Align.END)
        badge.set_valign(Gtk.Align.END)
        art.add_overlay(badge)
        art.set_valign(Gtk.Align.CENTER)
        card.append(art)
        col = vbox(2)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label(title, "title-2", wrap=True))
        col.append(label(subtitle, "muted", wrap=True))
        card.append(col)
        done = button(done_label, "secondary", on_done or self.hide_banner)
        done.set_valign(Gtk.Align.CENTER)
        card.append(done)
        self._banner.set_child(card)
        card.set_opacity(0.0)
        self._banner.set_reveal_child(True)
        anim.animate(card, 0.0, 1.0, 420, card.set_opacity)

    def hide_banner(self) -> None:
        self._banner.set_reveal_child(False)

    # ------------------------------------------------------------ Hyprland
    def _hypr_float(self) -> bool:
        """Hyprland'de küçük pencerenin kayan olması için yalnızca bu pencerenin durumunu ayarlar."""
        if not os.environ.get("HYPRLAND_INSTANCE_SIGNATURE") or not self.ctx.store.setting("auto_float"):
            return GLib.SOURCE_REMOVE
        pid = os.getpid()
        batch = (f"dispatch setfloating pid:{pid} ; "
                 f"dispatch resizewindowpixel exact {WIDTH} {HEIGHT},pid:{pid}")
        try:
            subprocess.Popen(["hyprctl", "--batch", batch],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
        return GLib.SOURCE_REMOVE
