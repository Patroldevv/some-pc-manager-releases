"""Çalışma anında yeniden renklendirilen SVG ikonlar."""
from __future__ import annotations

from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, GObject, Gtk  # noqa: E402

ICON_DIR = Path(__file__).resolve().parent.parent / "data" / "icons"
_cache: dict[tuple, "SizedTexture"] = {}


class SizedTexture(GObject.Object, Gdk.Paintable):
    """2x çözünürlüklü dokuyu mantıksal (w, h) boyutuyla gösterir; Gtk.Picture
    böylece doğal genişlik olarak 2x değil, istenen boyutu raporlar."""

    def __init__(self, tex: Gdk.Texture, w: int, h: int):
        super().__init__()
        self._tex, self._w, self._h = tex, w, h

    def do_snapshot(self, snapshot, width, height):
        self._tex.snapshot(snapshot, width, height)

    def do_get_intrinsic_width(self):
        return self._w

    def do_get_intrinsic_height(self):
        return self._h

    def do_get_flags(self):
        return Gdk.PaintableFlags.STATIC_SIZE | Gdk.PaintableFlags.STATIC_CONTENTS


def texture(name: str, size: int, color: str | None = None, box: tuple[int, int] | None = None,
            filled: bool = False) -> SizedTexture:
    """İkonu `size`'ın 2 katı çözünürlükte (HiDPI için) rasterize eder."""
    key = (name, size, color, box, filled)
    tex = _cache.get(key)
    if tex is None:
        svg = (ICON_DIR / f"{name}.svg").read_text()
        if color:
            svg = svg.replace("currentColor", color)
        if filled:  # etkin sekme: ana hattın içini hafifçe doldur
            svg = svg.replace('fill="none"', f'fill="{color or "#000"}" fill-opacity="0.18"', 1)
        stream = Gio.MemoryInputStream.new_from_bytes(GLib.Bytes.new(svg.encode()))
        pix = GdkPixbuf.Pixbuf.new_from_stream_at_scale(stream, size * 2, size * 2, True, None)
        tex = SizedTexture(Gdk.Texture.new_for_pixbuf(pix), *(box or (size, size)))
        _cache[key] = tex
    return tex


class Icon(Gtk.Image):
    """Tema rengini izleyen ikon. `role`: text | muted | blue | white | green | ..."""

    _instances: "list[Icon]" = []   # güçlü referans: sarmalayıcılar çöp toplanıp tema yenilemesini kaçırmasın
    theme = None  # Theme, uygulama başlarken atanır

    def __init__(self, name: str, size: int = 20, role: str | None = "text", filled: bool = False):
        super().__init__()
        self.icon_name, self.size, self.role, self.filled = name, size, role, filled
        self.set_pixel_size(size)
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self.set_can_target(False)
        Icon._instances.append(self)
        self.refresh()

    def refresh(self) -> None:
        color = self.theme.color(self.role) if (self.theme and self.role) else None
        self.set_from_paintable(texture(self.icon_name, self.size, color, None, self.filled))

    def set_icon(self, name: str | None = None, role: str | None = None, filled: bool | None = None) -> None:
        if name:
            self.icon_name = name
        if role:
            self.role = role
        if filled is not None:
            self.filled = filled
        self.refresh()

    @classmethod
    def refresh_all(cls) -> None:
        # Ebeveyni olmayan (kaldırılmış) ikonları ayıkla, kalanları yenile.
        cls._instances = [i for i in cls._instances if i.get_parent() is not None]
        for icon in cls._instances:
            icon.refresh()


def illustration(name: str, width: int, height: int) -> Gtk.Picture:
    """Sabit renkli çizim (laptop, disk, kalkan)."""
    pic = Gtk.Picture.new_for_paintable(texture(name, max(width, height), None, (width, height)))
    pic.set_size_request(width, height)
    pic.set_can_shrink(True)
    pic.set_content_fit(Gtk.ContentFit.CONTAIN)
    pic.set_halign(Gtk.Align.CENTER)
    pic.set_valign(Gtk.Align.CENTER)
    return pic
