"""Uygulama girişi ve yaşam döngüsü (arka planda çalışma dahil)."""
from __future__ import annotations

import os
import signal

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib  # noqa: E402

from ..core.store import Store
from . import anim
from .background import Background
from .icons import Icon
from .page import Context
from .theme import Theme
from .tray import Tray
from .window import MainWindow


def _page_classes():
    from .pages.apps import AppsPage
    from .pages.cleanup import CleanupPage
    from .pages.diskusage import DiskUsagePage
    from .pages.duplicates import DuplicatesPage
    from .pages.feedback import FeedbackPage
    from .pages.health import HealthPage
    from .pages.history import HistoryPage
    from .pages.home import HomePage
    from .pages.largefiles import LargeFilesPage
    from .pages.monitor import MonitorPage
    from .pages.protection import ProtectionPage
    from .pages.settings import SettingsPage
    from .pages.storage import StoragePage
    from .pages.toolbox import ToolboxPage
    return [HomePage, ProtectionPage, StoragePage, AppsPage, ToolboxPage, SettingsPage, FeedbackPage,
            HealthPage, CleanupPage, LargeFilesPage, DiskUsagePage, MonitorPage, DuplicatesPage, HistoryPage]


class App(Adw.Application):
    def __init__(self) -> None:
        super().__init__(application_id=os.environ.get("SPM_APP_ID", "dev.somepcmanager.PCManager"))  # SPM_APP_ID: testler gerçek örneği ezmesin
        GLib.set_application_name("Some PC Manager")
        GLib.set_prgname("some-pc-manager")
        self.win: MainWindow | None = None
        self.tray: Tray | None = None
        self.background: Background | None = None
        self._start_hidden = False
        self.add_main_option("background", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Pencere açmadan arka planda başlat", None)
        self.connect("handle-local-options", self._local_options)

        open_page = Gio.SimpleAction.new("open-page", GLib.VariantType.new("s"))
        open_page.connect("activate", lambda _a, p: self.show_page(p.get_string()))
        self.add_action(open_page)
        quit_ = Gio.SimpleAction.new("quit", None)
        quit_.connect("activate", lambda *_: self.quit())
        self.add_action(quit_)
        for sig in (signal.SIGTERM, signal.SIGINT):
            GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, sig, self._on_signal)

    def _on_signal(self) -> bool:
        self.quit()
        return GLib.SOURCE_REMOVE

    def _local_options(self, _app, options) -> int:
        self._start_hidden = options.contains("background")
        if self._start_hidden:
            try:
                self.register(None)
            except GLib.Error:
                return -1
            if self.get_is_remote():     # zaten çalışıyor: pencereyi açmadan çık
                return 0
        return -1

    # ------------------------------------------------------------ yaşam döngüsü
    def do_activate(self) -> None:
        if self.win is not None:
            self.show_page(None)
            return
        store = Store()
        theme = Theme()
        theme.mode = store.setting("theme")
        Icon.theme = theme
        theme.on_change(Icon.refresh_all)
        theme.attach()
        anim.set_reduce_motion(store.setting("reduce_motion"))
        ctx = Context(store, theme)
        self.win = MainWindow(self, ctx, _page_classes())
        self.win.connect("close-request", self._on_close)
        self.win.go(os.environ.get("SPM_PAGE", "home"))  # SPM_PAGE: geliştirme/test için
        self.hold()                                       # pencere kapansa da süreç yaşar

        if not os.environ.get("SPM_NO_BACKGROUND"):
            self.tray = Tray(self.toggle_window, lambda: self.background and self.background.quick_boost(),
                             lambda: self.show_page(None))
            self.background = Background(self, ctx, self.tray)
        if self._start_hidden:
            self.win.suspend()                            # görünmezken sayfa zamanlayıcıları çalışmasın
        else:
            self.win.present()
        self._start_hidden = False

    def show_page(self, spec: str | None) -> None:
        """Pencereyi öne getirir; `spec` 'sayfa' ya da 'sayfa:sekme' olabilir."""
        if self.win is None:
            return
        if spec:
            name, _, tab = spec.partition(":")
            if name in self.win.pages:
                self.win.go(name, **({"tab": tab} if tab else {}))
        self.win.present()

    def notify_user(self, nid: str, title: str, body: str, page: str = "home", button: str | None = None,
                    kind: str = "alert") -> None:
        """Masaüstü bildirimi gönderir. kind: 'alert' (Akıllı bildirimler ayarı), 'result' (İşlem sonuçları
        ayarı) ya da 'always'. Bildirime tıklayınca ilgili sayfa açılır."""
        if self.win is not None and kind != "always":
            if not self.win.ctx.store.setting("notify_results" if kind == "result" else "smart_notify"):
                return
        n = Gio.Notification.new(title)
        n.set_body(body)
        target = GLib.Variant("s", page)
        n.set_default_action_and_target("app.open-page", target)
        if button:
            n.add_button_with_target(button, "app.open-page", target)
        self.send_notification(nid, n)

    def toggle_window(self) -> None:
        if self.win is None:
            return
        if self.win.is_visible() and self.win.is_active():
            self.win.set_visible(False)
        else:
            self.win.present()

    def _on_close(self, win) -> bool:
        store = win.ctx.store
        if store.setting("background"):
            win.set_visible(False)           # yok etme: arka planda çalışmaya devam et
            try:
                if not store.get("bg_notice_shown") and self.background:
                    store.set("bg_notice_shown", True)
                    self.notify_user("bg-notice", "Some PC Manager arka planda çalışıyor",
                                           "Tepsi simgesine tıklayarak ya da uygulamayı yeniden açarak döndürebilirsin. "
                                           "Tamamen kapatmak için Ayarlar'daki Çık düğmesini kullan.", "settings",
                                           kind="always")
            except Exception:  # noqa: BLE001 - bildirim hatası pencerenin yok edilmesine yol açmasın
                import traceback
                traceback.print_exc()
            return True
        self.quit()
        return False

    def do_shutdown(self) -> None:
        if self.tray:
            self.tray.close()
        Adw.Application.do_shutdown(self)


def main() -> int:
    import sys
    return App().run(sys.argv)
