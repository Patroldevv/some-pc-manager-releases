"""Renk paletleri ve CSS üretimi (açık / koyu)."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path
from string import Template
from typing import Callable

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gtk  # noqa: E402

DATA = Path(__file__).resolve().parent.parent / "data"

LIGHT = {
    "text": "#1B1B1B", "muted": "#5E6A79", "blue": "#0F5FBF", "blue_hover": "#1A6AD0",
    "blue_press": "#0B4FA3", "link": "#0B5CAD", "green": "#2E9B4F", "danger": "#C42B1C",
    "card": "rgba(255,255,255,0.74)", "card_hover": "rgba(255,255,255,0.96)",
    "card_press": "rgba(255,255,255,0.60)", "card_border": "rgba(0,0,0,0.065)",
    "sidebar": "transparent", "row_hover": "rgba(0,0,0,0.055)",
    "track": "rgba(15,95,191,0.16)", "switch_off": "rgba(0,0,0,0.42)",
    "sep": "rgba(0,0,0,0.07)", "banner": "rgba(252,252,253,0.98)", "shadow": "rgba(0,0,0,0.16)",
    "rgb_bg_top": "236,243,251", "rgb_bg_bottom": "226,237,249",
    "rgb_frame": "219,230,245", "rgb_panel_top": "242,247,253", "rgb_panel_bottom": "233,241,250",
    "panel_edge": "rgba(255,255,255,0.75)", "blue_soft": "rgba(15,95,191,0.13)",
    "card_shadow": "0 2px 10px rgba(30,60,110,0.08)", "card_inset": "inset 0 1px 0 rgba(255,255,255,0.9)",
}
DARK = {
    "text": "#F3F6FA", "muted": "#A2AFBF", "blue": "#2F7DE1", "blue_hover": "#4790EE",
    "blue_press": "#2468C4", "link": "#6CB0FF", "green": "#5BC47B", "danger": "#FF6B5E",
    "card": "rgba(255,255,255,0.075)", "card_hover": "rgba(255,255,255,0.12)",
    "card_press": "rgba(255,255,255,0.05)", "card_border": "rgba(255,255,255,0.09)",
    "sidebar": "transparent", "row_hover": "rgba(255,255,255,0.08)",
    "track": "rgba(108,176,255,0.20)", "switch_off": "rgba(255,255,255,0.35)",
    "sep": "rgba(255,255,255,0.09)", "banner": "rgba(44,52,63,0.98)", "shadow": "rgba(0,0,0,0.45)",
    "rgb_bg_top": "30,40,54", "rgb_bg_bottom": "22,29,40",
    # Çerçeve rengi: kullanıcının referans görselindeki başlık çubuğundan ölçüldü (#222D3E).
    "rgb_frame": "34,45,62", "rgb_panel_top": "29,39,54", "rgb_panel_bottom": "23,31,44",
    "panel_edge": "rgba(255,255,255,0.06)", "blue_soft": "rgba(47,125,225,0.22)",
    "card_shadow": "0 4px 14px rgba(0,0,0,0.18)", "card_inset": "inset 0 1px 0 rgba(255,255,255,0.05)",
}


def hyprland_blur_enabled() -> bool:
    """Hyprland'de pencere bulanıklığı açıksa yarı saydam çizmek güvenlidir."""
    if not os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
        return False
    try:
        out = subprocess.run(["hyprctl", "getoption", "decoration:blur:enabled"],
                             capture_output=True, text=True, timeout=2).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return "int: 1" in out or "bool: true" in out


class Theme:
    """Mevcut paleti tutar; değişince dinleyicileri (ikonlar vb.) uyarır."""

    def __init__(self) -> None:
        self.mode = "system"          # system | light | dark
        self.dark = False
        self.translucent = hyprland_blur_enabled()
        self._listeners: list[Callable[[], None]] = []
        self._provider = Gtk.CssProvider()
        self._style = Adw.StyleManager.get_default()
        self._style.connect("notify::dark", lambda *_: self._apply())

    def attach(self) -> None:
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(display, self._provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)
        self.set_mode(self.mode)

    def on_change(self, fn: Callable[[], None]) -> None:
        self._listeners.append(fn)

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self._style.set_color_scheme({
            "light": Adw.ColorScheme.FORCE_LIGHT,
            "dark": Adw.ColorScheme.FORCE_DARK,
        }.get(mode, Adw.ColorScheme.DEFAULT))
        self._apply()

    @property
    def palette(self) -> dict[str, str]:
        return DARK if self._style.get_dark() else LIGHT

    def color(self, role: str) -> str:
        p = self.palette
        return {"white": "#FFFFFF"}.get(role) or p[role]

    def _apply(self) -> None:
        self.dark = self._style.get_dark()
        p = dict(self.palette)
        # Blur varsa yarı saydam, yoksa (okunaklılık için) neredeyse opak çiz.
        alpha = 0.95 if self.translucent else 0.99
        p["win_top"] = f"rgba({p['rgb_bg_top']},{alpha})"
        p["win_bottom"] = f"rgba({p['rgb_bg_bottom']},{alpha})"
        p["frame"] = f"rgba({p['rgb_frame']},{alpha})"
        p["panel_top"] = f"rgba({p['rgb_panel_top']},{alpha})"
        p["panel_bottom"] = f"rgba({p['rgb_panel_bottom']},{alpha})"
        css = Template((DATA / "style.css").read_text()).safe_substitute(p)
        self._provider.load_from_string(css)
        for fn in list(self._listeners):
            fn()
