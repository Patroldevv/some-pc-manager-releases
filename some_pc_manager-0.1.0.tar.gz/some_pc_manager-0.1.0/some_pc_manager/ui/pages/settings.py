"""Ayarlar."""
from __future__ import annotations

import os

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from ... import __version__
from ...core import autostart, privileged, sense, sysinfo
from .. import anim
from ..page import Page
from ..tasks import run_async
from ..widgets.common import Segmented, button, label, rows_card, setting_row, switch


class SettingsPage(Page):
    name = "settings"
    tab = "settings"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        s = ctx.store
        self.append(label("Ayarlar", "title-1"))

        theme = Segmented([("system", "Sistem"), ("light", "Açık"), ("dark", "Koyu")],
                          s.setting("theme"), self._on_theme)
        rows = [
            setting_row("Tema", None, theme, "sparkle"),
            setting_row("Animasyonları azalt", "Geçişleri ve hareketleri kapatır",
                        switch(s.setting("reduce_motion"), self._on_reduce), "gear"),
        ]
        drop = switch(s.setting("drop_caches"), lambda v: s.set_setting("drop_caches", v))
        if not privileged.available():
            drop.set_sensitive(False)
        rows.append(setting_row("RAM önbelleğini de boşalt", "Hızlandır sırasında yönetici parolası ister",
                                drop, "rocket"))
        if os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
            rows.append(setting_row("Hyprland'de kayan pencere", "Pencere açılışta kayan (floating) yapılır",
                                    switch(s.setting("auto_float"), lambda v: s.set_setting("auto_float", v)),
                                    "window"))
        rows.append(setting_row("Kapatınca arka planda çalış", "Pencere kapanınca uygulama tepside kalır",
                                switch(s.setting("background"), lambda v: s.set_setting("background", v)), "activity"))
        rows.append(setting_row("Akıllı bildirimler", "Bellek ya da disk dolmak üzereyken uyarır; hiçbir şeyi kendiliğinden silmez",
                                switch(s.setting("smart_notify"), lambda v: s.set_setting("smart_notify", v)), "bell"))
        rows.append(setting_row("İşlem sonucu bildirimleri", "RAM optimizasyonu, temizlik ve sağlık kontrolü bitince bildirim gönderir",
                                switch(s.setting("notify_results"), lambda v: s.set_setting("notify_results", v)), "bell"))
        rows.append(setting_row("Akıllı Hızlandırma", "Her 6 saatte bir eski geçici dosyaları otomatik temizler ve bildirir",
                                switch(s.setting("smart_boost"), self._on_smart_boost), "rocket"))
        rows.append(setting_row("Oturum açılışında başlat", "Arka planda, pencere açmadan başlar",
                                switch(autostart.is_enabled(), self._on_autostart), "power"))
        self._sense_busy = False
        self._sense_sw = switch(False, self._on_sense)
        rows.append(setting_row("Otomatik temizlik", "Her hafta önbellek ve geçici dosyaları temizler",
                                self._sense_sw, "clock"))
        self.append(rows_card(rows))

        quit_btn = button("Uygulamadan çık", "secondary", lambda: self.ctx.window.get_application().quit())
        quit_btn.set_halign(Gtk.Align.START)
        self.append(quit_btn)

        about = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        about.add_css_class("card")
        about.append(label("Some PC Manager", "card-title"))
        about.append(label(f"Sürüm {__version__} · {sysinfo.os_pretty_name()}", "muted"))
        self.append(about)

    def on_show(self, **kw) -> None:
        self._sense_busy = True
        run_async(sense.is_enabled, self._sense_loaded)

    def _sense_loaded(self, on: bool) -> None:
        self._sense_sw.set_active(on)
        self._sense_busy = False

    def _on_smart_boost(self, active: bool) -> None:
        import time
        self.ctx.store.set_setting("smart_boost", active)
        if active:   # açar açmaz değil, bir aralık sonra ilk kez çalışsın
            self.ctx.store.set("last_smart_boost", time.time())

    def _on_autostart(self, active: bool) -> None:
        ok = autostart.enable() if active else autostart.disable()
        self.ctx.store.set_setting("autostart", active and ok)
        if not ok:
            self.ctx.toast("Otomatik başlatma ayarlanamadı")

    def _on_theme(self, mode: str) -> None:
        self.ctx.store.set_setting("theme", mode)
        self.ctx.theme.set_mode(mode)

    def _on_reduce(self, v: bool) -> None:
        self.ctx.store.set_setting("reduce_motion", v)
        anim.set_reduce_motion(v)

    def _on_sense(self, active: bool) -> None:
        if self._sense_busy:
            return
        self._sense_busy = True

        def done(ok: bool) -> None:
            if not ok:
                self._sense_sw.set_active(not active)
                self.ctx.toast("Zamanlayıcı ayarlanamadı")
            else:
                self.ctx.toast("Otomatik temizlik açıldı" if active else "Otomatik temizlik kapatıldı")
            self._sense_busy = False

        run_async(lambda: sense.enable() if active else sense.disable(), done, lambda _e: done(False))
