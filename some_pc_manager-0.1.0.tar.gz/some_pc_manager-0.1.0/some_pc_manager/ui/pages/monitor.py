"""Canlı izleme: CPU, bellek ve ağ için akıcı kayan grafikler."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk  # noqa: E402

from ...core import metrics, sysinfo
from ...core.util import format_size
from ..icons import Icon
from ..page import Page
from ..widgets.chart import Sparkline
from ..widgets.common import hbox, label, vbox


class MonitorPage(Page):
    name = "monitor"
    tab = "toolbox"
    parent = "toolbox"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self._cpu = metrics.CpuSampler()
        self._net = metrics.NetSampler()
        self._timer = 0
        self.append(label("Canlı izleme", "title-1"))

        self._cpu_val, self._cpu_sub, self._cpu_chart = self._card("cpu", "İşlemci", Sparkline(1, max_value=100.0))
        self._mem_val, self._mem_sub, self._mem_chart = self._card("memory", "Bellek", Sparkline(1, max_value=100.0))
        self._net_val, self._net_sub, self._net_chart = self._card(
            "network", "Ağ", Sparkline(2, max_value=None, roles=("blue", "green")))
        self._bat = None

    def _card(self, icon: str, title: str, chart: Sparkline):
        card = vbox(6, "card chart-card")
        head = hbox(8)
        head.append(Icon(icon, 18))
        head.append(label(title, "card-title"))
        sp = Gtk.Box()
        sp.set_hexpand(True)
        head.append(sp)
        val = label("—", "title-2")
        head.append(val)
        card.append(head)
        card.append(chart)
        sub = label("", "muted small", wrap=True)
        card.append(sub)
        self.append(card)
        return val, sub, chart

    # ------------------------------------------------------------ yaşam döngüsü
    def on_show(self, **kw) -> None:
        self._tick()
        if not self._timer:
            self._timer = GLib.timeout_add(1000, self._tick)

    def on_hide(self) -> None:
        if self._timer:
            GLib.source_remove(self._timer)
            self._timer = 0

    def _tick(self) -> bool:
        cpu = self._cpu.percent()
        self._cpu_val.set_text(f"%{cpu:.0f}")
        self._cpu_chart.push(cpu)
        parts = []
        temp = metrics.read_temperature()
        if temp is not None:
            parts.append(f"{temp:.0f} °C")
        l1, l5, l15 = metrics.load_average()
        parts.append(f"Yük {l1:.2f} · {l5:.2f} · {l15:.2f}")
        bat = metrics.battery()
        if bat:
            parts.append(f"Pil %{bat[0]} ({bat[1]})")
        self._cpu_sub.set_text("  ·  ".join(parts))

        mem = sysinfo.memory()
        self._mem_val.set_text(f"%{mem.percent:.0f}")
        self._mem_chart.push(mem.percent)
        st, su = sysinfo.swap()
        swap = f" · Takas {format_size(su)} / {format_size(st)}" if st else " · Takas yok"
        self._mem_sub.set_text(f"{format_size(mem.used)} / {format_size(mem.total)}{swap}")

        down, up = self._net.rates()
        self._net_val.set_text(f"↓ {metrics.format_rate(down)}")
        self._net_chart.push(down, up)
        self._net_sub.set_text(f"↑ {metrics.format_rate(up)} yükleme")
        return GLib.SOURCE_CONTINUE
