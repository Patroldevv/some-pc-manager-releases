"""Geri bildirim: hata bildirimine eklenecek sistem bilgisini panoya kopyalar."""
from __future__ import annotations

import platform

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gtk  # noqa: E402

from ... import __version__
from ...core import sysinfo
from ..page import Page
from ..widgets.common import button, label, vbox


def diagnostics() -> str:
    return "\n".join([
        f"Some PC Manager {__version__}",
        f"Dağıtım: {sysinfo.os_pretty_name()}",
        f"Çekirdek: {platform.release()}",
        f"Python: {platform.python_version()}",
        f"GTK: {Gtk.get_major_version()}.{Gtk.get_minor_version()}.{Gtk.get_micro_version()}",
        f"libadwaita: {Adw.get_major_version()}.{Adw.get_minor_version()}.{Adw.get_micro_version()}",
    ])


class FeedbackPage(Page):
    name = "feedback"
    tab = "feedback"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self.append(label("Geri bildirim", "title-1"))
        card = vbox(8, "card")
        card.append(label("Bir sorunla mı karşılaştın?", "card-title"))
        card.append(label("Sistem bilgisini kopyalayıp hata bildirimine ekleyebilirsin. "
                          "Kişisel veri içermez.", "muted", wrap=True))
        self._info = label(diagnostics(), "muted small", wrap=True)
        self._info.set_selectable(True)
        card.append(self._info)
        card.append(button("Sistem bilgisini kopyala", "primary", self._copy))
        self.append(card)

    def _copy(self) -> None:
        Gdk.Display.get_default().get_clipboard().set(diagnostics())
        self.ctx.toast("Sistem bilgisi panoya kopyalandı")
