"""Disk analizi: bir klasörde en çok yer kaplayan öğeleri çubuklarla gösterir; klasörlere inilebilir."""
from __future__ import annotations

import os
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from ...core import diskusage
from ...core.util import format_size
from ..icons import Icon
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.bar import SmoothBar
from ..widgets.common import hbox, label, vbox

MAX_ROWS = 60


def tilde(path: str) -> str:
    home = str(Path.home())
    return "~" + path[len(home):] if path == home or path.startswith(home + os.sep) else path


class DiskUsagePage(Page):
    name = "diskusage"
    tab = "storage"
    parent = "storage"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self._path = str(Path.home())
        self._cancel = threading.Event()
        self._token = 0
        self._scanning = False

        self.append(label("Disk analizi", "title-1"))
        nav = hbox(6)
        self._up = Gtk.Button()
        self._up.add_css_class("icon-btn")
        self._up.set_child(Icon("folder-up", 18))
        self._up.set_cursor_from_name("pointer")
        self._up.connect("clicked", lambda *_: self._open(os.path.dirname(self._path) or "/"))
        nav.append(self._up)
        self._crumb = label("", "bold", ellipsize=True)
        self._crumb.set_hexpand(True)
        nav.append(self._crumb)
        self._refresh = Gtk.Button()
        self._refresh.add_css_class("icon-btn")
        self._refresh.set_child(Icon("refresh", 18))
        self._refresh.set_cursor_from_name("pointer")
        self._refresh.connect("clicked", lambda *_: self._scan())
        nav.append(self._refresh)
        self.append(nav)

        self._bar = SmoothBar(5)
        self.append(self._bar)
        self._status = label("", "muted", ellipsize=True)
        self.append(self._status)
        self._list = vbox(0, "rows-card")
        self._list.set_visible(False)
        self.append(self._list)

    # ------------------------------------------------------------ yaşam döngüsü
    def on_show(self, root: str | None = None, **kw) -> None:
        if root:
            self._path = str(Path.home()) if root == "/" else root
        self._scan()

    def on_suspend(self) -> None:   # pencere gizlenirken süren tarama/işlem iptal edilmez
        pass

    def on_resume(self) -> None:
        pass

    def on_hide(self) -> None:
        self._cancel.set()
        self._token += 1
        self._bar.set_indeterminate(False)

    def _open(self, path: str) -> None:
        self._path = path
        self._scan()

    # ------------------------------------------------------------ tarama
    def _clear(self) -> None:
        while (c := self._list.get_first_child()) is not None:
            self._list.remove(c)

    def _scan(self) -> None:
        self._cancel.set()
        self._cancel = threading.Event()
        self._token += 1
        token, cancel, path = self._token, self._cancel, self._path
        self._clear()
        self._list.set_visible(False)
        self._crumb.set_text(tilde(path))
        self._up.set_sensitive(path != "/")
        self._bar.set_indeterminate(True)
        self._bar.set_visible(True)
        self._status.set_text("Taranıyor…")
        self._scanning = True
        count = [0]

        def on_entry(e: diskusage.Entry) -> None:
            def ui() -> None:
                if token == self._token:
                    count[0] += 1
                    self._status.set_text(f"Taranıyor… {count[0]} öğe · {e.name}")
            call_ui(ui)

        run_async(lambda: diskusage.scan_children(path, on_entry, cancel),
                  lambda res: token == self._token and self._done(res, cancel.is_set()),
                  lambda _e: token == self._token and self._done([], False))

    def _done(self, entries: list[diskusage.Entry], cancelled: bool) -> None:
        self._scanning = False
        self._bar.set_indeterminate(False)
        total = sum(e.size for e in entries)
        self._status.set_text("İptal edildi" if cancelled else
                              (f"Toplam {format_size(total)} · {len(entries)} öğe" if entries else "Klasör boş ya da okunamadı"))
        if not entries:
            return
        top = max(e.size for e in entries) or 1
        for i, e in enumerate(entries[:MAX_ROWS]):
            self._list.append(self._row(e, e.size / top, e.size / total if total else 0, i == 0))
        self._list.set_visible(True)

    def _row(self, e: diskusage.Entry, rel: float, share: float, first: bool) -> Gtk.Widget:
        outer = vbox(0)
        if not first:
            sep = Gtk.Box()
            sep.add_css_class("row-sep")
            outer.append(sep)
        b = Gtk.Button()
        b.add_css_class("row-btn")
        b.set_cursor_from_name("pointer" if e.is_dir else "default")
        row = hbox(10)
        row.append(Icon("folder" if e.is_dir else "file", 20, "blue" if e.is_dir else "muted"))
        col = vbox(4)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        top = hbox(6)
        nm = label(e.name, ellipsize=True)
        nm.set_hexpand(True)
        top.append(nm)
        top.append(label(f"%{share * 100:.0f}", "muted small"))
        col.append(top)
        bar = SmoothBar(4, "warn" if share >= 0.5 else "blue")
        col.append(bar)
        row.append(col)
        size = label(format_size(e.size), "value-link")
        size.set_width_chars(8)
        size.set_xalign(1.0)
        row.append(size)
        b.set_child(row)
        if e.is_dir:
            b.connect("clicked", lambda *_: self._open(e.path))
        else:
            b.connect("clicked", lambda *_: self._reveal(e.path))
        outer.append(b)
        GLib.idle_add(lambda: (bar.animate_to(rel, 800), False)[1])   # çubuklar yerine süzülerek dolar
        return outer

    def _reveal(self, path: str) -> None:
        try:
            Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(os.path.dirname(path)).get_uri(), None)
        except GLib.Error:
            self.ctx.toast("Klasör açılamadı")
