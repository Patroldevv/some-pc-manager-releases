"""Ana sayfa: ipucu, PC Boost, kısayol kutucukları."""
from __future__ import annotations

import time

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk  # noqa: E402

from ...core import boost, cleaner, sysinfo
from ...core.apps import AppSampler
from ...core.util import carbon_kg, format_duration, format_number, format_size
from .. import anim
from ..icons import Icon, illustration
from ..page import Page
from ..tasks import run_async
from ..widgets.common import ProgressRing, StatBar, button, hbox, label, vbox

TIPS = [
    ("Arka plandaki gereksiz uygulamaları kapatıp belleği rahatlat.",
     "Uygulamalar", ("apps", {"tab": "processes"})),
    ("Gereksiz başlangıç uygulamalarını kapatarak açılışı hızlandır.",
     "Başlangıç", ("apps", {"tab": "startup"})),
    ("Eski paket önbelleği gigabaytlarca yer kaplayabilir.",
     "Derin temizlik", ("cleanup", {})),
    ("Haftalık otomatik temizlikle diskini temiz tut.",
     "Depolama algılama", ("storage", {})),
]
HIGH_MEMORY_PERCENT = 80.0   # Boost sonrası bu değerin üstündeyse uygulama kapatma önerilir
TEMP_BAR_SCALE = 4 * 1024**3   # çubuk bu miktarda dolu görünür


class HomePage(Page):
    name = "home"
    tab = "home"

    def __init__(self, ctx):
        super().__init__(ctx)
        self._sampler = AppSampler()
        self._boot_secs: float | None = None
        self._busy = False
        self._boosting = False
        self._timer = 0
        self._tip_timer = 0
        self._tip_i = 0
        self._shown = {"mem": 0.0, "temp": 0.0}
        self.append(self._build_tip())
        self.append(self._build_boost())
        self.append(self._build_grid())
        self.append(self._build_footer())
        self._update_static()

    # ------------------------------------------------------------ ipucu kartı
    def _build_tip(self) -> Gtk.Widget:
        card = hbox(14, "card")
        card.set_size_request(-1, 84)
        ring = Gtk.CenterBox()
        ring.add_css_class("tip-ring")
        ring.set_valign(Gtk.Align.CENTER)
        ring.set_center_widget(Icon("bulb", 22, "blue"))
        card.append(ring)
        self._tip_col = vbox(3)
        self._tip_col.set_hexpand(True)
        self._tip_col.set_valign(Gtk.Align.CENTER)
        self._tip_col.set_margin_end(56)   # dekoratif çizimin altında yazı kalmasın
        self._tip_col.append(label("Linux ipuçları", "card-title"))
        self._tip_text = label("", "muted", wrap=True, markup=True)
        self._tip_text.connect("activate-link", self._on_tip_link)
        self._tip_col.append(self._tip_text)
        card.append(self._tip_col)
        self._set_tip(0)
        # Referanstaki gibi sağ üstte soluk dekoratif çizim
        ov = Gtk.Overlay()
        ov.set_child(card)
        art = illustration("tip-art", 58, 34)
        art.set_halign(Gtk.Align.END)
        art.set_valign(Gtk.Align.START)
        art.set_opacity(0.6)
        art.set_margin_top(8)
        art.set_margin_end(10)
        art.set_can_target(False)
        ov.add_overlay(art)
        return ov

    def _set_tip(self, i: int) -> None:
        text, link, _target = TIPS[i]
        self._tip_text.set_markup(f'{GLib.markup_escape_text(text)} <a href="tip{i}">{GLib.markup_escape_text(link)}</a>')

    def _next_tip(self) -> bool:
        self._tip_i = (self._tip_i + 1) % len(TIPS)
        anim.fade_swap(self._tip_col, lambda: self._set_tip(self._tip_i), 160, 320)
        return GLib.SOURCE_CONTINUE

    def _on_tip_link(self, _lb, uri: str) -> bool:
        name, kw = TIPS[int(uri[3:])][2]
        self.ctx.go(name, **kw)
        return True

    # ------------------------------------------------------------ boost kartı
    def _build_boost(self) -> Gtk.Widget:
        card = vbox(10, "card")
        head = hbox(8)
        head.append(Icon("rocket", 18))
        head.append(label("PC Hızlandırma", "card-title"))
        card.append(head)

        row = hbox(8)
        self._boost_sub = label("", "muted", ellipsize=False)
        self._boost_sub.set_hexpand(True)
        self._boost_sub.set_ellipsize(3)  # END
        row.append(self._boost_sub)
        link = Gtk.Button()
        link.add_css_class("link-btn")
        link.set_cursor_from_name("pointer")
        lh = hbox(4)
        lh.append(Icon("clock", 13, "link"))
        lh.append(label("Otomatik temizlik", "small"))
        link.set_child(lh)
        link.connect("clicked", lambda *_: self.ctx.go("settings"))
        row.append(link)
        card.append(row)

        stats = hbox(0)
        stats.set_homogeneous(True)
        stats.set_margin_top(4)
        stats.set_margin_bottom(2)
        self._mem_bar, self._mem_val = StatBar(), label("%0", "stat-value")
        self._tmp_bar, self._tmp_val = StatBar(), label("0 B", "stat-value")
        for bar, val, cap in ((self._mem_bar, self._mem_val, "Bellek kullanımı"),
                              (self._tmp_bar, self._tmp_val, "Geçici dosyalar")):
            cell = hbox(10)
            cell.append(bar)
            col = vbox(0)
            col.set_valign(Gtk.Align.CENTER)
            col.append(val)
            col.append(label(cap, "muted"))
            cell.append(col)
            stats.append(cell)
        card.append(stats)

        self._boost_btn = Gtk.Button()
        self._boost_btn.add_css_class("primary")
        self._boost_btn.set_cursor_from_name("pointer")
        st = Gtk.Stack()
        st.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        st.set_transition_duration(180)
        st.set_halign(Gtk.Align.CENTER)
        st.add_named(label("Hızlandır", "bold"), "label")
        self._ring = ProgressRing(20, 2.6, "ring-white")
        st.add_named(self._ring, "spin")
        done = hbox(6)
        done.set_halign(Gtk.Align.CENTER)
        done.append(Icon("check", 16, "white"))
        done.append(label("Tamamlandı", "bold"))
        st.add_named(done, "done")
        self._boost_stack = st
        self._boost_btn.set_child(st)
        self._boost_btn.connect("clicked", lambda *_: self._on_boost())
        card.append(self._boost_btn)
        return card

    def _on_boost(self) -> None:
        if self._boosting:
            return
        self._boosting = True
        self._boost_btn.set_sensitive(False)
        self._boost_stack.set_visible_child_name("spin")
        self._ring.start()
        t0 = time.monotonic()
        drop = bool(self.ctx.store.setting("drop_caches"))

        def finish(res: boost.BoostResult) -> None:
            wait = max(0, int(900 - (time.monotonic() - t0) * 1000))
            GLib.timeout_add(wait, lambda: (self._boost_done(res), False)[1])

        run_async(lambda: boost.boost(drop), finish, lambda _e: self._boost_failed())

    def _boost_failed(self) -> None:
        self._ring.stop()
        self._boost_stack.set_visible_child_name("label")
        self._boost_btn.set_sensitive(True)
        self._boosting = False
        self.ctx.toast("Hızlandırma tamamlanamadı")

    def _boost_done(self, res: boost.BoostResult) -> None:
        store = self.ctx.store
        summary = boost.summarize(res)
        store.set("last_boost_freed", res.temp_freed)
        store.add_cleaned(res.temp_freed + res.cache_released)
        store.add_history("boost", res.temp_freed + res.cache_released, summary)
        msg = (f"{format_size(res.temp_freed)} geçici dosya serbest bırakıldı." if res.temp_freed
               else "Temizlenecek geçici dosya yoktu.")
        if res.cache_released:
            msg = f"{msg} (+{format_size(res.cache_released)} RAM önbelleği)"
        self._update_static()
        self._boost_sub.set_text(msg)   # son sonuç, kalıcı özetin üstüne yazılır
        if res.note:
            self.ctx.toast(res.note)
        self.ctx.notify("boost", "RAM optimizasyonu tamamlandı", summary, "history")
        self.refresh()
        # Bellek hâlâ yüksekse çözüm öner
        if res.mem_after and res.mem_after.percent >= HIGH_MEMORY_PERCENT:
            pct = res.mem_after.percent
            GLib.timeout_add(1800, lambda: (self.ctx.show_banner(
                f"Bellek hâlâ %{pct:.0f}", "Çok bellek kullanan uygulamaları kapatmak yardımcı olur",
                lambda: (self.ctx.hide_banner(), self.ctx.go("apps", tab="processes")),
                "Uygulamalar", warn=True), False)[1])

        # Halka kapanır, tik çizilir; sonra "Tamamlandı" belirir
        self._ring.play_success(lambda: self._boost_stack.set_visible_child_name("done"))

        def reset() -> bool:
            self._ring.reset()
            self._boost_stack.set_visible_child_name("label")
            self._boost_btn.set_sensitive(True)
            self._boosting = False
            return GLib.SOURCE_REMOVE

        GLib.timeout_add(2600, reset)

    # ------------------------------------------------------------ kutucuklar
    def _tile(self, icon: str, title: str, caption: str, on_click) -> tuple[Gtk.Button, Gtk.Label, Gtk.Label]:
        b = Gtk.Button()
        b.add_css_class("tile")
        b.set_cursor_from_name("pointer")
        b.set_hexpand(True)
        b.set_size_request(-1, 86)
        v = vbox(0)
        head = hbox(8)
        head.append(Icon(icon, 18))
        head.append(label(title, "card-title"))
        v.append(head)
        sp = Gtk.Box()
        sp.set_vexpand(True)
        v.append(sp)
        v.append(label(caption, "muted"))
        val = label("…", "value-link")
        v.append(val)
        b.set_child(v)
        b.connect("clicked", lambda *_: on_click())
        return b, v.get_first_child().get_next_sibling().get_next_sibling(), val

    def _build_grid(self) -> Gtk.Widget:
        g = Gtk.Grid(column_spacing=8, row_spacing=8)
        g.set_column_homogeneous(True)
        specs = [
            ("health", "Sağlık Kontrolü", "Son kontrol", lambda: self.ctx.go("health")),
            ("process", "Süreçler", "Çalışan", lambda: self.ctx.go("apps", tab="processes")),
            ("broom", "Derin Temizlik", "Yerel Disk (/)", lambda: self.ctx.go("cleanup")),
            ("power", "Başlangıç", "Açılış süresi", lambda: self.ctx.go("apps", tab="startup")),
        ]
        self._vals = []
        for i, (icon, title, cap, cb) in enumerate(specs):
            b, _cap, val = self._tile(icon, title, cap, cb)
            g.attach(b, i % 2, i // 2, 1, 1)
            self._vals.append(val)
        return g

    def _build_footer(self) -> Gtk.Widget:
        btn = Gtk.Button()
        btn.add_css_class("link-btn")
        btn.set_cursor_from_name("pointer")
        btn.set_halign(Gtk.Align.CENTER)
        btn.set_margin_top(6)
        row = hbox(6)
        row.append(Icon("leaf", 14, "green"))
        self._footer = label("", "muted small", xalign=0.5, wrap=True)
        self._footer.set_justify(Gtk.Justification.CENTER)
        self._footer.set_max_width_chars(46)
        row.append(self._footer)
        btn.set_child(row)
        btn.set_tooltip_text("İşlem geçmişini aç")
        btn.connect("clicked", lambda *_: self.ctx.go("history"))
        return btn

    # ------------------------------------------------------------ veri
    def _update_static(self) -> None:
        store = self.ctx.store
        last = store.get("last_boost_freed")
        self._boost_sub.set_text(f"{format_size(last)} geçici dosya serbest bırakıldı." if last
                                 else "Hızlandırmaya hazır.")
        total = store.get("total_cleaned")
        self._footer.set_text(
            f"Toplam {format_size(total, 2)} alan temizlendi ≈ {format_number(carbon_kg(total))} kg karbon emisyonu"
            if total else "Henüz alan temizlenmedi")
        d = store.get("last_health_check")
        self._vals[0].set_text(d.replace("-", "/") if d else "Henüz yapılmadı")

    def refresh(self) -> None:
        if self._busy:
            return
        self._busy = True

        def work():
            mem = sysinfo.memory()
            temp = cleaner.temporary_files_size()
            apps = self._sampler.sample()
            disk = sysinfo.disk("/")
            if self._boot_secs is None:
                self._boot_secs = sysinfo.boot_time_seconds() or 0.0
            return mem, temp, len(apps), disk, self._boot_secs

        def done(r) -> None:
            self._busy = False
            mem, temp, napps, disk, boot = r
            pct = mem.percent
            anim.animate_number(self, self._mem_val, self._shown["mem"], pct, lambda v: f"%{round(v)}")
            self._mem_bar.animate_to(pct / 100)
            anim.animate_number(self, self._tmp_val, self._shown["temp"], temp, lambda v: format_size(v))
            self._tmp_bar.animate_to(min(1.0, temp / TEMP_BAR_SCALE))
            self._shown.update(mem=pct, temp=float(temp))
            self._vals[1].set_text(f"{napps} Uygulama")
            self._vals[2].set_text(f"{format_size(disk.used, 0).replace(' ', '')} / {format_size(disk.total, 0).replace(' ', '')}")
            self._vals[3].set_text(format_duration(boot) if boot else "Bilinmiyor")

        run_async(work, done, lambda _e: setattr(self, "_busy", False))

    def on_show(self, **kw) -> None:
        self._update_static()
        self.refresh()
        if not self._timer:
            self._timer = GLib.timeout_add_seconds(6, self._tick)
        if not self._tip_timer:
            self._tip_timer = GLib.timeout_add_seconds(9, self._next_tip)

    def on_hide(self) -> None:
        for attr in ("_timer", "_tip_timer"):
            if getattr(self, attr):
                GLib.source_remove(getattr(self, attr))
                setattr(self, attr, 0)

    def _tick(self) -> bool:
        if not self._boosting:
            self.refresh()
        return GLib.SOURCE_CONTINUE
