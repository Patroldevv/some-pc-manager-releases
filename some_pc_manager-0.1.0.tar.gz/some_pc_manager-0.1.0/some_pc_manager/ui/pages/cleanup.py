"""Derin temizlik: tara → seç → temizle → sonuç."""
from __future__ import annotations

import threading

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from ...core import cleaner
from ...core.util import format_size
from .. import anim
from ..icons import Icon
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.common import button, hbox, label, vbox
from ..widgets.progress_header import ProgressHeader

STATUS_TEXT = {"cleaned": "Temizlendi", "skipped": "Atlandı", "error": "Hata"}


def result_row(title: str, status: str, note: str = "", first: bool = False) -> Gtk.Widget:
    outer = vbox(0)
    if not first:
        sep = Gtk.Box()
        sep.add_css_class("row-sep")
        outer.append(sep)
    row = hbox(10, "row")
    text = vbox(1)
    text.set_hexpand(True)
    text.append(label(title))
    if note:
        text.append(label(note, "muted", wrap=True))
    row.append(text)
    row.append(label(STATUS_TEXT.get(status, status), "green" if status == "cleaned" else "muted"))
    outer.append(row)
    return outer


class CleanupPage(Page):
    name = "cleanup"
    tab = "storage"
    parent = "storage"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(14)
        self._cancel = threading.Event()
        self._token = 0
        self._checks: dict[str, tuple[Gtk.CheckButton, cleaner.ScanItem]] = {}

        self.header = ProgressHeader("disk-art", (56, 64))
        self.append(self.header)
        self.list = vbox(0, "rows-card")
        self.append(self.list)

        self.btn_cancel = button("İptal", "secondary", self._on_cancel)
        self.btn_done = button("Bitti", "secondary", lambda: self.ctx.go("storage"))
        self.btn_clean = button("Temizle", "primary", self._start_clean)
        self.footer = self.btn_clean   # kaydırma alanının dışında, altta sabit

    # ------------------------------------------------------------ yaşam döngüsü
    def on_show(self, **kw) -> None:
        self._start_scan()

    def on_suspend(self) -> None:   # pencere gizlenirken süren tarama/işlem iptal edilmez
        pass

    def on_resume(self) -> None:
        pass

    def on_hide(self) -> None:
        self._cancel.set()
        self._token += 1

    def _on_cancel(self) -> None:
        self._cancel.set()
        self.ctx.go("storage")

    def _clear_list(self) -> None:
        while (c := self.list.get_first_child()) is not None:
            self.list.remove(c)
        self._checks.clear()

    def _set_side(self, *buttons: Gtk.Widget) -> None:
        while (c := self.header.side.get_first_child()) is not None:
            self.header.side.remove(c)
        for b in buttons:
            self.header.side.append(b)

    # ------------------------------------------------------------ tarama
    def _start_scan(self) -> None:
        self._cancel = threading.Event()
        self._token += 1
        token, cancel = self._token, self._cancel
        self._clear_list()
        self.header.reset()
        self.header.title.set_text("Gereksiz dosyalar taranıyor…")
        self.header.status.set_text("Bu birkaç saniye sürebilir")
        self._set_side(self.btn_cancel)
        self.btn_clean.set_visible(False)
        total = len(cleaner.TARGETS)
        count = [0]

        def on_item(item: cleaner.ScanItem) -> None:
            def ui() -> None:
                if token != self._token:
                    return
                count[0] += 1
                self._add_scan_row(item)
                self.header.set_progress(count[0] / total)
                self.header.status.set_text(f"{item.target.label} tarandı")
            call_ui(ui)

        run_async(lambda: cleaner.scan_all(progress=on_item, cancel=cancel),
                  lambda items: token == self._token and self._scan_done(items))

    def _add_scan_row(self, item: cleaner.ScanItem) -> None:
        t = item.target
        outer = vbox(0)
        if self._checks:
            sep = Gtk.Box()
            sep.add_css_class("row-sep")
            outer.append(sep)
        row = hbox(10, "row")
        usable = item.available and item.size > 0
        check = Gtk.CheckButton()
        check.set_active(usable and t.default_selected)
        check.set_sensitive(usable)
        check.connect("toggled", lambda *_: self._update_total())
        row.append(check)
        text = vbox(1)
        text.set_hexpand(True)
        title = hbox(6)
        title.append(label(t.label))
        if t.root:
            title.append(Icon("lock", 12, "muted"))
        text.append(title)
        text.append(label(item.note or t.description, "muted", wrap=True))
        row.append(text)
        row.append(label(format_size(item.size) if item.available else "—", "value-link"))
        outer.append(row)
        rev = Gtk.Revealer()
        rev.set_transition_type(Gtk.RevealerTransitionType.SLIDE_DOWN)
        rev.set_transition_duration(260)
        rev.set_child(outer)
        self.list.append(rev)
        rev.set_reveal_child(True)
        self._checks[t.id] = (check, item)

    def _selected(self) -> list[str]:
        return [tid for tid, (c, _i) in self._checks.items() if c.get_active()]

    def _update_total(self) -> None:
        total = sum(i.size for tid, (c, i) in self._checks.items() if c.get_active())
        self.btn_clean.set_label(f"Temizle ({format_size(total)})" if total else "Temizle")
        self.btn_clean.set_sensitive(bool(self._selected()))

    def _scan_done(self, items: list[cleaner.ScanItem]) -> None:
        total = sum(i.size for i in items if i.available and i.target.default_selected)
        self.header.set_progress(1.0)
        self._set_side(self.btn_done)
        self.btn_done.set_label("Vazgeç")
        if total <= 0 and not any(i.size for i in items):
            self.header.title.set_text("Temizlenecek bir şey bulunamadı")
            self.header.status.set_text("Diskin zaten temiz görünüyor.")
            self.btn_clean.set_visible(False)
            return
        self.header.title.set_text(f"{format_size(total)} temizlenebilir")
        self.header.status.set_text("Silinecek öğeleri seç, sonra Temizle'ye bas.")
        self.btn_clean.set_visible(True)
        self._update_total()

    def _group(self, title: str, results: list[cleaner.CleanResult], first: bool) -> Gtk.Widget:
        """Başlığa tıklayınca yumuşakça açılıp kapanan sonuç grubu (referanstaki 'Sistem temizliği')."""
        outer = vbox(0)
        if not first:
            sep = Gtk.Box()
            sep.add_css_class("row-sep")
            outer.append(sep)
        head = Gtk.Button()
        head.add_css_class("row-btn")
        head.set_cursor_from_name("pointer")
        hrow = hbox(8)
        hrow.append(label(title, "bold"))
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        hrow.append(spacer)
        chev = Icon("chevron-down", 14, "muted")
        hrow.append(chev)
        head.set_child(hrow)
        outer.append(head)
        rev = Gtk.Revealer()
        rev.set_transition_type(Gtk.RevealerTransitionType.SLIDE_DOWN)
        rev.set_transition_duration(anim.duration(260))
        body = vbox(0)
        for r in results:
            body.append(result_row(r.label, r.status, r.note, first=False))
        rev.set_child(body)
        rev.set_reveal_child(True)
        outer.append(rev)

        def toggle(*_) -> None:
            open_ = not rev.get_reveal_child()
            rev.set_reveal_child(open_)
            chev.set_icon("chevron-down" if open_ else "chevron")

        head.connect("clicked", toggle)
        return outer

    # ------------------------------------------------------------ temizleme
    def _start_clean(self) -> None:
        ids = self._selected()
        if not ids:
            return
        self._token += 1
        token = self._token
        self.btn_clean.set_visible(False)
        self._set_side()
        for c, _i in (v for v in self._checks.values()):
            c.set_sensitive(False)
        self.header.reset()
        self.header.title.set_text("Temizleniyor…")
        needs_root = any(cleaner.TARGETS[i].root for i in ids)
        self.header.status.set_text("Yönetici izni istenebilir" if needs_root else "Lütfen bekle")

        def progress(tid: str, done: int, total: int) -> None:
            def ui() -> None:
                if token != self._token:
                    return
                self.header.set_progress(done / total if total else 1.0, 300)
                if tid:
                    self.header.status.set_text(f"{cleaner.TARGETS[tid].label} temizleniyor…")
            call_ui(ui)

        run_async(lambda: cleaner.run_cleanup(ids, "deep", progress),
                  lambda rep: token == self._token and self._clean_done(rep),
                  lambda e: self._clean_failed(str(e)))

    def _clean_failed(self, msg: str) -> None:
        self.ctx.toast("Temizleme tamamlanamadı")
        self._set_side(self.btn_done)

    def _clean_done(self, report: cleaner.CleanupReport) -> None:
        freed = report.total_freed
        self.ctx.store.add_cleaned(freed)
        done = sum(1 for r in report.results if r.status == "cleaned")
        self.ctx.store.add_history("cleanup", freed, f"{done} kategori temizlendi")
        self.ctx.notify("cleanup", "Temizleme tamamlandı", f"{format_size(freed)} disk alanı boşaltıldı", "history")
        self._clear_list()
        groups: dict[str, list[cleaner.CleanResult]] = {}
        for r in report.results:
            groups.setdefault(cleaner.TARGETS[r.target_id].group, []).append(r)
        titles = {"user": "Kullanıcı dosyaları", "system": "Sistem temizliği"}
        first = True
        for g in ("user", "system"):
            if g in groups:
                self.list.append(self._group(titles[g], groups[g], first))
                first = False
        self.header.set_progress(1.0, 150)
        self.header.set_done(True)
        self.header.title.set_text("Temizleme tamamlandı")
        self.header.status.set_text(f"Disk alanından {format_size(freed)} boşaltıldı")
        self.btn_done.set_label("Bitti")
        self._set_side(self.btn_done)
