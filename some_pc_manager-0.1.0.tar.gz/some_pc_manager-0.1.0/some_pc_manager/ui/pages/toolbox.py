"""Araç kutusu: uygulama içi araçlar ve sistemde kurulu harici araçlara kısayollar."""
from __future__ import annotations

import shutil
import subprocess

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from ..icons import Icon
from ..page import Page
from ..widgets.common import hbox, label, vbox

INTERNAL = [
    ("activity", "Canlı izleme", "CPU, bellek, ağ", ("monitor", {})),
    ("chart-bar", "Disk analizi", "Klasör boyutları", ("diskusage", {})),
    ("copy", "Yinelenen dosyalar", "Kopyaları bul", ("duplicates", {})),
    ("timer", "Geçmiş", "Yapılan işlemler", ("history", {})),
    ("sparkle", "Depolama algılama", "Otomatik temizlik", ("storage", {})),
    ("file-search", "Büyük dosyalar", "Yer kaplayanları bul", ("largefiles", {})),
    ("power", "Başlangıç", "Açılışı hızlandır", ("apps", {"tab": "startup"})),
    ("process", "Süreçler", "Çalışan uygulamalar", ("apps", {"tab": "processes"})),
]
# (ikon, başlık, alt başlık, aday komutlar)
EXTERNAL = [
    ("health", "Sistem monitörü", "CPU, bellek, ağ",
     ["resources", "gnome-system-monitor", "plasma-systemmonitor", "missioncenter", "mate-system-monitor",
      "xfce4-taskmanager", "lxtask"]),
    ("pie", "Disk kullanımı", "Klasör boyutları", ["baobab", "filelight", "qdirstat", "k4dirstat"]),
    ("disk", "Diskler", "Bölümleri yönet", ["gnome-disks", "partitionmanager", "gparted", "kdiskmark"]),
    ("gear", "Sistem ayarları", "Masaüstü ayarları",
     ["systemsettings", "gnome-control-center", "cosmic-settings", "xfce4-settings-manager", "mate-control-center"]),
]


class ToolboxPage(Page):
    name = "toolbox"
    tab = "toolbox"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.append(label("Araç kutusu", "title-1"))
        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        grid.set_column_homogeneous(True)
        grid.set_margin_top(6)
        tiles = [self._tile(i, t, s, lambda tgt=tgt: self.ctx.go(tgt[0], **tgt[1])) for i, t, s, tgt in INTERNAL]
        for i, t, s, cmds in EXTERNAL:
            found = next((c for c in cmds if shutil.which(c)), None)
            if found:
                tiles.append(self._tile(i, t, s, lambda c=found: self._launch(c), external=True))
        for n, t in enumerate(tiles):
            grid.attach(t, n % 2, n // 2, 1, 1)
        self.append(grid)

    def _tile(self, icon: str, title: str, sub: str, on_click, external: bool = False) -> Gtk.Button:
        b = Gtk.Button()
        b.add_css_class("tile")
        b.set_cursor_from_name("pointer")
        v = vbox(4)
        head = hbox(0)
        ic = Icon(icon, 24, "blue")
        ic.set_halign(Gtk.Align.START)
        ic.set_hexpand(True)
        head.append(ic)
        if external:
            head.append(Icon("external", 13, "muted"))
        v.append(head)
        v.append(label(title, "card-title", wrap=True))
        v.append(label(sub, "muted small", wrap=True))
        b.set_child(v)
        b.set_size_request(-1, 96)
        b.connect("clicked", lambda *_: on_click())
        return b

    def _launch(self, cmd: str) -> None:
        try:
            subprocess.Popen([cmd], start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            self.ctx.toast("Araç açılamadı")
