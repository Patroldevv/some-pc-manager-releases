"""Depolama yönetimi: disk sekmeleri, derin temizlik, büyük dosyalar, depolama algılama."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from ...core import sense, sysinfo
from ...core.util import format_size
from .. import anim
from ..icons import Icon
from ..page import Page
from ..tasks import run_async
from ..widgets.bar import SmoothBar
from ..widgets.common import TabStrip, hbox, label, switch, vbox


class StoragePage(Page):
    name = "storage"
    tab = "storage"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(12)
        self.disks = sysinfo.list_disks()
        self._frac = 0.0
        self.append(label("Depolama yönetimi", "title-1"))
        self.tabs = TabStrip([d[0] for d in self.disks], self._on_disk)
        self.append(self.tabs)

        card = vbox(8, "card")
        self._usage = label("", "muted", wrap=True)
        card.append(self._usage)
        self._bar = SmoothBar(7)
        card.append(self._bar)
        self.append(card)

        self.append(self._link_tile("broom", "Derin temizlik", "Tam taramayla gereksiz dosyaları bul ve temizle",
                                    lambda: self.ctx.go("cleanup")))
        self.append(self._link_tile("file-search", "Büyük dosyaları yönet", "Büyük dosyaları bul, çöp kutusuna taşı",
                                    lambda: self.ctx.go("largefiles", root=self.disks[max(0, self.tabs.index)][1])))
        self.append(self._link_tile("copy", "Yinelenen dosyalar", "Aynı içerikli kopyaları bul, fazlasını çöp kutusuna taşı",
                                    lambda: self.ctx.go("duplicates", root=self.disks[max(0, self.tabs.index)][1])))
        self.append(self._link_tile("chart-bar", "Disk analizi", "Hangi klasör ne kadar yer kaplıyor",
                                    lambda: self.ctx.go("diskusage", root=self.disks[max(0, self.tabs.index)][1])))
        self.append(self._sense_card())
        self.tabs.select(0, animate=False, notify=False)

    def _link_tile(self, icon: str, title: str, sub: str, on_click) -> Gtk.Widget:
        b = Gtk.Button()
        b.add_css_class("tile")
        b.set_cursor_from_name("pointer")
        row = hbox(14)
        row.append(Icon(icon, 24))
        col = vbox(2)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label(title, "card-title"))
        col.append(label(sub, "muted", wrap=True))
        row.append(col)
        row.append(Icon("chevron", 14, "muted"))
        b.set_child(row)
        b.connect("clicked", lambda *_: on_click())
        return b

    def _sense_card(self) -> Gtk.Widget:
        card = hbox(14, "card")
        card.append(Icon("sparkle", 24))
        col = vbox(2)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label("Depolama algılama", "card-title"))
        col.append(label("Her hafta önbellek ve geçici dosyaları otomatik temizler", "muted", wrap=True))
        card.append(col)
        self._sense_busy = False
        self.sense_switch = switch(False, self._on_sense)
        self.sense_switch.set_valign(Gtk.Align.CENTER)
        card.append(self.sense_switch)
        return card

    def _on_sense(self, active: bool) -> None:
        if self._sense_busy:
            return
        self._sense_busy = True
        self.sense_switch.set_sensitive(False)

        def done(ok: bool) -> None:
            self._sense_busy = False
            self.sense_switch.set_sensitive(True)
            if not ok:
                self._sense_busy = True
                self.sense_switch.set_active(not active)
                self._sense_busy = False
                self.ctx.toast("Zamanlayıcı ayarlanamadı")
            else:
                self.ctx.toast("Otomatik temizlik açıldı" if active else "Otomatik temizlik kapatıldı")

        run_async(lambda: sense.enable() if active else sense.disable(), done, lambda _e: done(False))

    def _on_disk(self, i: int) -> None:
        self._show_usage(self.disks[i][1])

    def _show_usage(self, mount: str) -> None:
        d = sysinfo.disk(mount)
        f = d.used / d.total if d.total else 0.0
        self._usage.set_text(f"{format_size(d.used)} kullanılıyor · {format_size(d.free)} boş · {format_size(d.total)}")
        self._bar.set_tone("danger" if f >= 0.9 else "warn" if f >= 0.75 else "blue")
        self._bar.animate_to(f, 900)
        self._frac = f

    def on_show(self, **kw) -> None:
        self._show_usage(self.disks[max(0, self.tabs.index)][1])
        self._sense_busy = True
        self.sense_switch.set_active(False)
        run_async(sense.is_enabled, self._sense_loaded)

    def _sense_loaded(self, enabled: bool) -> None:
        self._sense_busy = True
        self.sense_switch.set_active(enabled)
        self._sense_busy = False
