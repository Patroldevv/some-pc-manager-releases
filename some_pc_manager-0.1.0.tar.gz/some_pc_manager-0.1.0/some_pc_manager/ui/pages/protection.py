"""Koruma: güvenlik duvarı, güncellemeler, ClamAV taraması."""
from __future__ import annotations

import threading

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gtk  # noqa: E402

from ...core import protection
from ...core.cleaner import pkg_manager
from .. import anim
from ..icons import Icon, illustration
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.common import ProgressRing, button, hbox, label, vbox

INSTALL_CMD = {"pacman": "sudo pacman -S clamav", "apt-get": "sudo apt install clamav", "dnf": "sudo dnf install clamav"}


class ProtectionPage(Page):
    name = "protection"
    tab = "protection"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self._token = 0
        self._cancel = threading.Event()
        self._scanning = False

        self.append(label("Koruma", "title-1"))
        head = hbox(16, "card")
        self._art = Gtk.Stack()
        self._art.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self._art.set_transition_duration(400)
        self._breath = None
        self._art.add_named(illustration("shield-art", 56, 64), "ok")
        self._art.add_named(illustration("shield-warn-art", 56, 64), "warn")
        head.append(self._art)
        col = vbox(3)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        self._title = label("Denetleniyor…", "title-2", wrap=True)
        self._sub = label("", "muted", wrap=True)
        col.append(self._title)
        col.append(self._sub)
        head.append(col)
        recheck = Gtk.Button()
        recheck.add_css_class("icon-btn")
        recheck.set_child(Icon("refresh", 16))
        recheck.set_valign(Gtk.Align.START)
        recheck.set_cursor_from_name("pointer")
        recheck.connect("clicked", lambda *_: self._check())
        head.append(recheck)
        self.append(head)

        self._fw = self._status_card("shield", "Güvenlik duvarı")
        self._upd = self._status_card("refresh", "Sistem güncellemeleri")
        self.append(self._fw["card"])
        self.append(self._upd["card"])
        self.append(self._build_av())

    def _status_card(self, icon: str, title: str) -> dict:
        card = hbox(12, "card")
        card.append(Icon(icon, 22))
        col = vbox(2)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label(title, "card-title"))
        sub = label("Denetleniyor…", "muted", wrap=True)
        col.append(sub)
        card.append(col)
        mark = Icon("info", 18, "muted")
        card.append(mark)
        return {"card": card, "sub": sub, "mark": mark}

    def _set_state(self, c: dict, text: str, ok: bool | None) -> None:
        c["sub"].set_text(text)
        c["mark"].set_icon("check" if ok else ("warning" if ok is False else "info"),
                           "green" if ok else ("danger" if ok is False else "muted"))

    # ------------------------------------------------------------ virüs taraması
    def _build_av(self) -> Gtk.Widget:
        card = vbox(8, "card")
        head = hbox(12)
        head.append(Icon("shield-check", 22))
        col = vbox(2)
        col.set_hexpand(True)
        col.append(label("Virüs taraması", "card-title"))
        self._av_sub = label("", "muted", wrap=True)
        col.append(self._av_sub)
        head.append(col)
        card.append(head)

        self._av_row = hbox(8)
        self._ring = ProgressRing(18, 2.4, "ring-blue")
        self._ring.set_visible(False)
        self._av_row.append(self._ring)
        self._av_file = label("", "muted small", ellipsize=True)
        self._av_file.set_hexpand(True)
        self._av_row.append(self._av_file)
        card.append(self._av_row)

        self._av_btn = button("Hızlı tara", "primary", self._scan_toggle)
        card.append(self._av_btn)
        self._av_copy = button("Kurulum komutunu kopyala", "secondary", self._copy_cmd)
        card.append(self._av_copy)
        if protection.clamav_available():
            self._av_sub.set_text("ClamAV ile İndirilenler ve Masaüstü klasörleri taranır.")
            self._av_copy.set_visible(False)
        else:
            cmd = INSTALL_CMD.get(pkg_manager() or "", "")
            self._av_sub.set_text("ClamAV yüklü değil." + (f" Kurmak için: {cmd}" if cmd else ""))
            self._av_btn.set_visible(False)
            self._av_copy.set_visible(bool(cmd))
        return card

    def _copy_cmd(self) -> None:
        cmd = INSTALL_CMD.get(pkg_manager() or "")
        if cmd:
            Gdk.Display.get_default().get_clipboard().set(cmd)
            self.ctx.toast("Komut panoya kopyalandı")

    def _scan_toggle(self) -> None:
        if self._scanning:
            self._cancel.set()
            return
        self._scanning = True
        self._cancel = threading.Event()
        token, cancel = self._token, self._cancel
        self._av_btn.set_label("İptal")
        self._ring.set_visible(True)
        self._ring.start()

        def on_file(path: str) -> None:
            call_ui(lambda: self._av_file.set_text(path))

        def done(res: protection.ScanResult) -> None:
            self._scanning = False
            self._ring.stop()
            self._ring.set_visible(False)
            self._av_btn.set_label("Hızlı tara")
            if res.error:
                self._av_file.set_text(res.error)
            elif res.cancelled:
                self._av_file.set_text("Tarama iptal edildi")
            elif res.infected:
                self._av_file.set_text(f"{len(res.infected)} tehdit bulundu: {res.infected[0]}")
                self._av_file.add_css_class("danger")
                return
            else:
                self._av_file.set_text("Tehdit bulunamadı")
            self._av_file.remove_css_class("danger")

        self._av_file.set_text("Taranıyor…")
        run_async(lambda: protection.clam_scan(protection.quick_scan_paths(), on_file, cancel), done,
                  lambda _e: done(protection.ScanResult(error="Tarama başlatılamadı")))

    # ------------------------------------------------------------ denetim
    def on_show(self, **kw) -> None:
        self._check()
        if self._breath is None:
            self._breath = anim.breathe(self._art)

    def on_hide(self) -> None:
        self._token += 1
        anim.stop(self._breath)
        self._breath = None
        self._art.set_opacity(1.0)

    def _check(self) -> None:
        self._token += 1
        token = self._token
        self._title.set_text("Denetleniyor…")
        self._sub.set_text("")
        self._set_state(self._fw, "Denetleniyor…", None)
        self._set_state(self._upd, "Denetleniyor…", None)

        def work():
            fw = protection.firewall_status()
            call_ui(lambda: token == self._token and self._show_fw(fw))
            return fw, protection.pending_updates()

        run_async(work, lambda r: token == self._token and self._show_all(*r))

    def _show_fw(self, fw: str) -> None:
        text, ok = {"active": ("Etkin ve çalışıyor", True), "inactive": ("Kapalı — etkinleştirmen önerilir", False),
                    "missing": ("Güvenlik duvarı yüklü değil", None)}[fw]
        self._set_state(self._fw, text, ok)

    def _show_all(self, fw: str, upd: int | None) -> None:
        if upd is None:
            self._set_state(self._upd, "Durum okunamadı", None)
        elif upd == 0:
            self._set_state(self._upd, "Sistem güncel", True)
        else:
            self._set_state(self._upd, f"{upd} güncelleme bekliyor", False)
        problems = int(fw == "inactive") + int(bool(upd))
        self._art.set_visible_child_name("warn" if problems else "ok")
        self._title.set_text("Dikkat gerekiyor" if problems else "Cihazın korunuyor")
        self._sub.set_text(f"{problems} öğe incelenmeli" if problems else "Önemli bir sorun bulunamadı")
