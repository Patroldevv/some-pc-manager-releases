"""Uygulamalar: çalışan süreçler, başlangıç öğeleri, yüklü uygulamalar."""
from __future__ import annotations

import os

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from ...core import apps as core_apps
from ...core import startup
from ...core.util import format_size
from .. import anim
from ..page import Page
from ..widgets.bar import SmoothBar
from ..tasks import run_async
from ..widgets.common import TabStrip, button, hbox, label, switch, vbox

TABS = ["Süreçler", "Başlangıç", "Yüklü"]
KEYS = ["processes", "startup", "installed"]


def app_icon(name: str, size: int = 28) -> Gtk.Image:
    img = Gtk.Image()
    if name.startswith("/") and os.path.exists(name):
        img.set_from_file(name)
    else:
        theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
        img.set_from_icon_name(name if name and not name.startswith("/") and theme.has_icon(name)
                               else "application-x-executable")
    img.set_pixel_size(size)
    return img


def separator() -> Gtk.Box:
    s = Gtk.Box()
    s.add_css_class("row-sep")
    return s


class AppsPage(Page):
    name = "apps"
    tab = "apps"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self._sampler = core_apps.AppSampler()
        self._timer = 0
        self._busy = False
        self._proc_rows: dict[str, dict] = {}
        self._startup_loaded = False
        self._installed: list[core_apps.DesktopEntry] | None = None

        self.append(label("Uygulamalar", "title-1"))
        self.tabs = TabStrip(TABS, self._on_tab)
        self.append(self.tabs)
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
        self.stack.set_vhomogeneous(False)
        self.append(self.stack)
        self.stack.add_named(self._build_processes(), "processes")
        self.stack.add_named(self._build_startup(), "startup")
        self.stack.add_named(self._build_installed(), "installed")
        self.tabs.select(0, animate=False, notify=False)

    # ------------------------------------------------------------ gezinme
    def on_show(self, tab: str | None = None, **kw) -> None:
        if tab in KEYS:
            self.tabs.select(KEYS.index(tab), animate=self.get_mapped(), notify=False)
            self.stack.set_visible_child_name(tab)
        self._activate(self.stack.get_visible_child_name())

    def on_hide(self) -> None:
        self._stop_timer()

    def _on_tab(self, i: int) -> None:
        self.scroll_to_top()
        anim.fade_swap(self.stack, lambda: self.stack.set_visible_child_name(KEYS[i]), 80, 200)
        self._activate(KEYS[i])

    def _activate(self, key: str) -> None:
        self._stop_timer()
        if key == "processes":
            self._refresh_processes()
            self._timer = GLib.timeout_add_seconds(2, lambda: (self._refresh_processes(), True)[1])
        elif key == "startup":
            self._load_startup()
        elif key == "installed":
            self._load_installed()

    def _stop_timer(self) -> None:
        if self._timer:
            GLib.source_remove(self._timer)
            self._timer = 0

    # ------------------------------------------------------------ süreçler
    def _build_processes(self) -> Gtk.Widget:
        v = vbox(8)
        self._proc_summary = label("Taranıyor…", "muted")
        v.append(self._proc_summary)
        self._proc_list = vbox(0, "rows-card")
        v.append(self._proc_list)
        return v

    def _refresh_processes(self) -> None:
        if self._busy:
            return
        self._busy = True
        run_async(self._sampler.sample, self._apply_processes, lambda _e: setattr(self, "_busy", False))

    def _apply_processes(self, apps: list[core_apps.RunningApp]) -> None:
        self._busy = False
        total = sum(a.mem for a in apps)
        self._proc_summary.set_text(f"{len(apps)} uygulama çalışıyor · toplam {format_size(total)} bellek")
        names = {a.name for a in apps}
        for n in [n for n in self._proc_rows if n not in names]:
            self._proc_list.remove(self._proc_rows.pop(n)["widget"])
        prev = None
        for a in apps:
            r = self._proc_rows.get(a.name)
            if r is None:
                r = self._make_proc_row(a)
                self._proc_rows[a.name] = r
                self._proc_list.append(r["widget"])
            r["app"] = a
            r["info"].set_text(f"{format_size(a.mem)} · CPU %{a.cpu:.0f}")
            self._proc_list.reorder_child_after(r["widget"], prev)
            prev = r["widget"]
        self._sync_separators()

    def _sync_separators(self) -> None:
        first = True
        c = self._proc_list.get_first_child()
        while c is not None:
            c.get_first_child().set_visible(not first)   # satırın üst ayırıcısı
            first = False
            c = c.get_next_sibling()

    def _make_proc_row(self, a: core_apps.RunningApp) -> dict:
        outer = vbox(0)
        outer.append(separator())
        row = hbox(10, "row")
        row.append(app_icon(a.icon))
        col = vbox(1)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label(a.name, "bold", ellipsize=True))
        info = label("", "muted")
        col.append(info)
        row.append(col)
        btn = button("Sonlandır", "secondary")
        btn.set_valign(Gtk.Align.CENTER)
        state = {"armed": 0}
        rec = {"widget": outer, "info": info, "app": a}

        def reset() -> bool:
            state["armed"] = 0
            btn.set_label("Sonlandır")
            btn.remove_css_class("danger-btn")
            return GLib.SOURCE_REMOVE

        def on_click() -> None:
            if not state["armed"]:
                btn.set_label("Emin misin?")
                btn.add_css_class("danger-btn")
                state["armed"] = GLib.timeout_add(3000, reset)
                return
            GLib.source_remove(state["armed"])
            reset()
            n = core_apps.terminate(rec["app"])
            self.ctx.toast(f"{rec['app'].name} sonlandırıldı" if n else "Uygulama sonlandırılamadı")
            GLib.timeout_add(900, lambda: (self._refresh_processes(), False)[1])

        btn.connect("clicked", lambda *_: on_click())
        row.append(btn)
        outer.append(row)
        return rec

    # ------------------------------------------------------------ başlangıç
    def _build_startup(self) -> Gtk.Widget:
        v = vbox(10)
        # Açılışı en çok geciktiren birimler (systemd-analyze blame)
        self._blame = vbox(8, "card")
        self._blame.append(label("Açılışı en çok geciktirenler", "card-title"))
        self._blame_rows = vbox(8)
        self._blame.append(self._blame_rows)
        self._blame.set_visible(False)
        v.append(self._blame)
        self._st_status = label("Yükleniyor…", "muted")
        v.append(self._st_status)
        self._st_apps = vbox(0, "rows-card")
        v.append(self._st_apps)
        self._st_svc_title = label("Kullanıcı hizmetleri (systemd)", "card-title")
        self._st_svc_title.set_margin_top(6)
        v.append(self._st_svc_title)
        self._st_svc_note = label("Dikkat: bazı hizmetler (ses, ağ vb.) sistemin çalışması için gereklidir.",
                                  "muted", wrap=True)
        v.append(self._st_svc_note)
        self._st_svcs = vbox(0, "rows-card")
        v.append(self._st_svcs)
        for w in (self._st_svc_title, self._st_svc_note, self._st_svcs):
            w.set_visible(False)
        return v

    def _load_startup(self) -> None:
        run_async(lambda: (startup.list_autostart(), startup.list_services()), self._fill_startup)
        run_async(startup.boot_blame, self._fill_blame)

    def _fill_blame(self, items: list[tuple[str, float]]) -> None:
        while (c := self._blame_rows.get_first_child()) is not None:
            self._blame_rows.remove(c)
        self._blame.set_visible(bool(items))
        if not items:
            return
        top = items[0][1] or 1.0
        for unit, secs in items[:6]:
            row = vbox(3)
            head = hbox(6)
            nm = label(unit.removesuffix(".service"), ellipsize=True)
            nm.set_hexpand(True)
            head.append(nm)
            head.append(label(f"{secs:.1f}".replace(".", ",") + " sn", "value-link"))
            row.append(head)
            bar = SmoothBar(4, "warn" if secs / top > 0.75 and secs > 5 else "blue")
            row.append(bar)
            self._blame_rows.append(row)
            GLib.idle_add(lambda b=bar, f=secs / top: (b.animate_to(f, 900), False)[1])

    def _fill_startup(self, data) -> None:
        entries, services = data
        for box in (self._st_apps, self._st_svcs):
            while (c := box.get_first_child()) is not None:
                box.remove(c)
        on = sum(1 for e in entries if e.enabled)
        self._st_status.set_text(f"{on} başlangıç uygulaması etkin" if entries else "Başlangıç uygulaması bulunamadı")
        for i, e in enumerate(entries):
            self._st_apps.append(self._startup_row(e.name, e.comment, e.icon, e.enabled,
                                                   lambda act, e=e: startup.set_autostart(e, act), i == 0))
        self._st_apps.set_visible(bool(entries))
        for w in (self._st_svc_title, self._st_svc_note, self._st_svcs):
            w.set_visible(bool(services))
        for i, s in enumerate(services[:40]):
            self._st_svcs.append(self._startup_row(s.name.removesuffix(".service"), "", "", s.enabled,
                                                   lambda act, s=s: startup.set_service(s.name, act), i == 0,
                                                   check=True))

    def _startup_row(self, name: str, sub: str, icon: str, enabled: bool, apply, first: bool, check: bool = False) -> Gtk.Widget:
        outer = vbox(0)
        if not first:
            outer.append(separator())
        row = hbox(10, "row")
        if icon:
            row.append(app_icon(icon, 26))
        col = vbox(1)
        col.set_hexpand(True)
        col.set_valign(Gtk.Align.CENTER)
        col.append(label(name, ellipsize=True))
        if sub:
            col.append(label(sub, "muted small", ellipsize=True))
        row.append(col)
        busy = {"v": False}
        sw = switch(enabled, lambda active: None)
        sw.set_valign(Gtk.Align.CENTER)

        def toggled(s, _p) -> None:
            if busy["v"]:
                return
            active = s.get_active()
            s.set_sensitive(False)

            def work():
                try:
                    r = apply(active)
                except OSError:
                    return False
                return True if r is None else bool(r)

            def done(ok: bool) -> None:
                s.set_sensitive(True)
                if not ok:
                    busy["v"] = True
                    s.set_active(not active)
                    busy["v"] = False
                    self.ctx.toast("Değişiklik uygulanamadı")

            run_async(work, done, lambda _e: done(False))

        sw.connect("notify::active", toggled)
        row.append(sw)
        outer.append(row)
        return outer

    # ------------------------------------------------------------ yüklü
    def _build_installed(self) -> Gtk.Widget:
        v = vbox(8)
        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("Uygulama ara")
        self._search.connect("search-changed", lambda *_: self._fill_installed())
        v.append(self._search)
        self._inst_count = label("", "muted")
        v.append(self._inst_count)
        self._inst_list = vbox(0, "rows-card")
        v.append(self._inst_list)
        return v

    def _load_installed(self) -> None:
        if self._installed is not None:
            return
        run_async(core_apps.installed_apps, self._installed_loaded)

    def _installed_loaded(self, entries: list[core_apps.DesktopEntry]) -> None:
        self._installed = entries
        self._fill_installed()

    def _fill_installed(self) -> None:
        while (c := self._inst_list.get_first_child()) is not None:
            self._inst_list.remove(c)
        q = self._search.get_text().strip().lower()
        entries = [e for e in (self._installed or []) if q in e.name.lower()]
        self._inst_count.set_text(f"{len(entries)} uygulama" + (" (ilk 60 gösteriliyor)" if len(entries) > 60 else ""))
        for i, e in enumerate(entries[:60]):
            outer = vbox(0)
            if i:
                outer.append(separator())
            row = hbox(10, "row")
            row.append(app_icon(e.icon, 26))
            col = vbox(1)
            col.set_hexpand(True)
            col.set_valign(Gtk.Align.CENTER)
            col.append(label(e.name, ellipsize=True))
            if e.comment:
                col.append(label(e.comment, "muted small", ellipsize=True))
            row.append(col)
            b = button("Aç", "secondary", lambda e=e: self._launch(e))
            b.set_valign(Gtk.Align.CENTER)
            row.append(b)
            outer.append(row)
            self._inst_list.append(outer)

    def _launch(self, e: core_apps.DesktopEntry) -> None:
        info = Gio.DesktopAppInfo.new_from_filename(e.path)
        try:
            ok = bool(info and info.launch([], None))
        except GLib.Error:
            ok = False
        self.ctx.toast(f"{e.name} açılıyor…" if ok else "Uygulama açılamadı")
