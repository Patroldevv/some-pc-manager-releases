"""Sağlık kontrolü: sorunları tara, düzeltilebilenleri tek tıkla temizle."""
from __future__ import annotations

import datetime
import threading

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk  # noqa: E402

from ...core import cleaner, protection, startup
from ...core.util import format_size
from ..icons import Icon
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.common import button, hbox, label, vbox
from ..widgets.progress_header import ProgressHeader

STARTUP_LIMIT = 8       # bundan fazla etkin başlangıç öğesi "sorun" sayılır
JUNK_ISSUE_BYTES = 50 * 1024**2

ROWS = [
    ("junk", "broom", "Gereksiz dosyalar", ""),
    ("startup", "power", "Başlangıç öğeleri", ""),
    ("security", "shield", "Güvenlik duvarı", ""),
    ("updates", "refresh", "Güncellemeler", ""),
]
REVIEW = {"startup": ("apps", {"tab": "startup"}), "security": ("protection", {}), "updates": ("protection", {})}


class HealthPage(Page):
    name = "health"
    tab = "home"
    parent = "home"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(14)
        self._cancel = threading.Event()
        self._token = 0
        self._items: list[cleaner.ScanItem] = []
        self._status: dict[str, Gtk.Label] = {}
        self._review: dict[str, Gtk.Button] = {}

        self.header = ProgressHeader("laptop", (88, 66))
        self.append(self.header)

        card = vbox(0, "rows-card")
        for i, (rid, icon, title, sub) in enumerate(ROWS):
            if i:
                sep = Gtk.Box()
                sep.add_css_class("row-sep")
                card.append(sep)
            row = hbox(12, "row")
            row.append(Icon(icon, 18))
            text = vbox(1)
            text.set_hexpand(True)
            text.set_valign(Gtk.Align.CENTER)
            text.append(label(title, wrap=True))
            if rid in REVIEW:
                b = button("Gözden geçir", "link-btn", lambda r=rid: self.ctx.go(REVIEW[r][0], **REVIEW[r][1]))
                b.set_halign(Gtk.Align.START)
                b.set_visible(False)
                text.append(b)
                self._review[rid] = b
            row.append(text)
            st = label("", "muted")
            st.set_valign(Gtk.Align.CENTER)
            row.append(st)
            self._status[rid] = st
            card.append(row)
        self.append(card)

        self.btn_cancel = button("İptal", "secondary", self._on_cancel)
        self.btn_done = button("Bitti", "secondary", lambda: self.ctx.go("home"))
        self.btn_fix = button("Tümünü düzelt", "primary", self._fix)
        self.footer = self.btn_fix


    # ------------------------------------------------------------ yaşam döngüsü
    def on_show(self, **kw) -> None:
        self._start()

    def on_suspend(self) -> None:   # pencere gizlenirken süren tarama/işlem iptal edilmez
        pass

    def on_resume(self) -> None:
        pass

    def on_hide(self) -> None:
        self._cancel.set()
        self._token += 1

    def _on_cancel(self) -> None:
        self._cancel.set()
        self.ctx.go("home")

    def _set_side(self, *buttons: Gtk.Widget) -> None:
        while (c := self.header.side.get_first_child()) is not None:
            self.header.side.remove(c)
        for b in buttons:
            self.header.side.append(b)

    # ------------------------------------------------------------ tarama
    def _start(self) -> None:
        self._cancel = threading.Event()
        self._token += 1
        token, cancel = self._token, self._cancel
        self._items = []
        self.ctx.hide_banner()
        self.btn_fix.set_visible(False)
        self.header.reset()
        self.header.title.set_text("Sorunlar aranıyor…")
        self.header.status.set_text("Gereksiz dosyalar taranıyor…")
        self._set_side(self.btn_cancel)
        for rid, st in self._status.items():
            st.set_text("Taranıyor…")
            st.remove_css_class("green")
            st.remove_css_class("value-link")
            st.add_css_class("muted")
        for b in self._review.values():
            b.set_visible(False)

        def step(i: int, text: str, rid: str | None = None, value: str = "", css: str = "muted") -> None:
            def ui() -> None:
                if token != self._token:
                    return
                self.header.set_progress(i / 4)
                if text:
                    self.header.status.set_text(text)
                if rid:
                    st = self._status[rid]
                    st.set_text(value)
                    for c in ("muted", "green", "value-link", "danger"):
                        st.remove_css_class(c)
                    st.add_css_class(css)
            call_ui(ui)

        def work() -> dict:
            issues = 0
            items = cleaner.scan_all(cancel=cancel)
            junk = sum(i.size for i in items if i.available and i.target.default_selected)
            if junk > JUNK_ISSUE_BYTES:
                issues += 1
            step(1, "Başlangıç öğeleri denetleniyor…", "junk", format_size(junk) if junk else "Temiz",
                 "value-link" if junk else "green")
            if cancel.is_set():
                return {}
            n = sum(1 for e in startup.list_autostart() if e.enabled)
            bad = n > STARTUP_LIMIT
            issues += bad
            call_ui(lambda: token == self._token and self._review["startup"].set_visible(bad))
            step(2, "Güvenlik denetleniyor…", "startup", f"{n} etkin", "danger" if bad else "green")
            fw = protection.firewall_status()
            text, css = {"active": ("Açık", "green"), "inactive": ("Kapalı", "danger"),
                         "missing": ("Kurulu değil", "muted")}[fw]
            issues += fw == "inactive"
            call_ui(lambda: token == self._token and self._review["security"].set_visible(fw == "inactive"))
            step(3, "Güncellemeler denetleniyor…", "security", text, css)
            upd = protection.pending_updates()
            if upd:
                issues += 1
            call_ui(lambda: token == self._token and self._review["updates"].set_visible(bool(upd)))
            step(4, "", "updates", "Bilinmiyor" if upd is None else (f"{upd} bekliyor" if upd else "Güncel"),
                 "muted" if upd is None else ("danger" if upd else "green"))
            return {"items": items, "junk": junk, "issues": issues}

        run_async(work, lambda r: token == self._token and self._done(r),
                  lambda e: self.ctx.toast("Sağlık kontrolü tamamlanamadı"))

    def _done(self, r: dict) -> None:
        if not r:
            return
        self._items = r["items"]
        self._issues, self._freed = r["issues"], 0
        self.ctx.store.set("last_health_check", datetime.date.today().isoformat())
        issues, junk = r["issues"], r["junk"]
        self.header.set_progress(1.0)
        self._set_side()
        self.header.title.set_text("Tarama tamamlandı")
        self.header.status.set_text(f"{issues} sorun bulundu" if issues else "Sorun bulunamadı")
        if junk > 0:
            self.btn_fix.set_visible(True)
            self.btn_fix.set_sensitive(True)
            self.btn_fix.set_label(f"Gereksiz dosyaları temizle ({format_size(junk)})")
            self._set_side(self.btn_done)
        else:
            self._finish()

    # ------------------------------------------------------------ düzeltme
    def _fix(self) -> None:
        ids = [i.target.id for i in self._items if i.available and i.size > 0 and i.target.default_selected]
        if not ids:
            self._finish()
            return
        self._token += 1
        token = self._token
        self.btn_fix.set_sensitive(False)
        self._set_side()
        self.header.reset()
        self.header.title.set_text("Düzeltiliyor…")
        self.header.status.set_text("Gereksiz dosyalar temizleniyor")

        def progress(tid: str, done: int, total: int) -> None:
            call_ui(lambda: token == self._token and self.header.set_progress(done / total if total else 1, 300))

        run_async(lambda: cleaner.run_cleanup(ids, "deep", progress),
                  lambda rep: token == self._token and self._fixed(rep),
                  lambda e: self.ctx.toast("Temizleme tamamlanamadı"))

    def _fixed(self, rep: cleaner.CleanupReport) -> None:
        freed = rep.total_freed
        self._freed = freed
        self.ctx.store.add_cleaned(freed)
        st = self._status["junk"]
        st.set_text(f"{format_size(freed)} temizlendi")
        st.remove_css_class("value-link")
        st.add_css_class("green")
        self.btn_fix.set_visible(False)
        self._finish()

    def _finish(self) -> None:
        issues, freed = getattr(self, "_issues", 0), getattr(self, "_freed", 0)
        note = f"{issues} sorun bulundu" + (f", {format_size(freed)} temizlendi" if freed else "")
        self.ctx.store.add_history("health", freed, note)
        self.ctx.notify("health", "Sağlık kontrolü tamamlandı", note, "history")
        self.header.set_progress(1.0, 150)
        self.header.set_done(True)
        self.header.title.set_text("Sağlık kontrolü bitti")
        self.header.status.set_text("Tüm işlemler tamamlandı")
        self._set_side()
        GLib.timeout_add(300, lambda: (self.ctx.show_banner("Sağlık kontrolü tamamlandı", "Tüm işlemler tamamlandı",
                                                            lambda: self.ctx.go("home")), False)[1])
