"""Yinelenen dosyalar: aynı içeriğe sahip dosyaları bul, fazlalıkları çöp kutusuna taşı."""
from __future__ import annotations

import os
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from ...core import duplicates
from ...core.util import format_size
from ..icons import Icon
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.bar import SmoothBar
from ..widgets.common import Segmented, button, hbox, label, vbox

SIZES = [("1", "1 MB"), ("10", "10 MB"), ("100", "100 MB")]
MAX_GROUPS = 25


class DuplicatesPage(Page):
    name = "duplicates"
    tab = "storage"
    parent = "storage"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self._root = str(Path.home())
        self._cancel = threading.Event()
        self._token = 0
        self._scanning = False
        self._groups: list[list[tuple[Gtk.CheckButton, str, int]]] = []

        self.append(label("Yinelenen dosyalar", "title-1"))
        self._folder_btn = Gtk.Button()
        self._folder_btn.add_css_class("secondary")
        self._folder_btn.set_cursor_from_name("pointer")
        fh = hbox(8)
        fh.append(Icon("folder", 16))
        self._folder_lbl = label("", ellipsize=True)
        self._folder_lbl.set_hexpand(True)
        fh.append(self._folder_lbl)
        self._folder_btn.set_child(fh)
        self._folder_btn.connect("clicked", lambda *_: self._pick_folder())
        self.append(self._folder_btn)

        row = hbox(8)
        self._seg = Segmented(SIZES, "1", lambda _k: None)
        self._seg.set_hexpand(True)
        self._seg.set_halign(Gtk.Align.START)
        row.append(self._seg)
        self._scan_btn = button("Tara", "primary", self._scan)
        row.append(self._scan_btn)
        self.append(row)

        self._bar = SmoothBar(5)
        self._bar.set_visible(False)
        self.append(self._bar)
        self._status = label("En az seçilen boyuttaki, içeriği birebir aynı dosyalar bulunur.", "muted", wrap=True)
        self.append(self._status)
        self._box = vbox(10)
        self.append(self._box)

        self._trash_btn = button("Seçilenleri çöp kutusuna taşı", "primary", self._trash)
        self._trash_btn.set_visible(False)
        self.footer = self._trash_btn

    # ------------------------------------------------------------ yaşam döngüsü
    def on_show(self, root: str | None = None, **kw) -> None:
        if root:
            self._root = str(Path.home()) if root == "/" else root
        self._folder_lbl.set_text(self._root)

    def on_suspend(self) -> None:   # pencere gizlenirken tarama sürer
        pass

    def on_resume(self) -> None:
        pass

    def on_hide(self) -> None:
        self._cancel.set()
        self._token += 1
        self._bar.set_indeterminate(False)
        self._scanning = False
        self._scan_btn.set_label("Tara")

    def _clear(self) -> None:
        while (c := self._box.get_first_child()) is not None:
            self._box.remove(c)
        self._groups.clear()
        self._trash_btn.set_visible(False)

    def _pick_folder(self) -> None:
        dlg = Gtk.FileDialog()
        dlg.set_title("Taranacak klasörü seç")
        dlg.set_initial_folder(Gio.File.new_for_path(self._root))

        def done(d, res) -> None:
            try:
                f = d.select_folder_finish(res)
            except GLib.Error:
                return
            if f and f.get_path():
                self._root = f.get_path()
                self._folder_lbl.set_text(self._root)

        dlg.select_folder(self.get_root(), None, done)

    # ------------------------------------------------------------ tarama
    def _scan(self) -> None:
        if self._scanning:
            self._cancel.set()
            return
        self._clear()
        self._cancel = threading.Event()
        self._token += 1
        token, cancel, root = self._token, self._cancel, self._root
        min_bytes = int(self._seg.value) * 1024**2
        self._scanning = True
        self._scan_btn.set_label("İptal")
        self._bar.set_visible(True)
        self._bar.set_indeterminate(True)
        self._status.set_text("Taranıyor…")

        def progress(phase: str, path: str) -> None:
            call_ui(lambda: token == self._token and self._status.set_text(f"{phase}: {os.path.basename(path)}"))

        def done(groups: list[duplicates.DupGroup]) -> None:
            if token != self._token:
                return
            self._scanning = False
            self._bar.set_indeterminate(False)
            self._bar.set_visible(False)
            self._scan_btn.set_label("Tara")
            self._fill(groups, cancel.is_set())

        run_async(lambda: duplicates.find_duplicates(root, min_bytes, 200, progress, cancel), done,
                  lambda _e: done([]))

    def _fill(self, groups: list[duplicates.DupGroup], cancelled: bool) -> None:
        if not groups:
            self._status.set_text("İptal edildi" if cancelled else "Yinelenen dosya bulunamadı")
            return
        wasted = sum(g.wasted for g in groups)
        self._status.set_text(f"{len(groups)} grup · geri kazanılabilir {format_size(wasted)}")
        for g in groups[:MAX_GROUPS]:
            self._box.append(self._group_card(g))
        self._update_trash()

    def _group_card(self, g: duplicates.DupGroup) -> Gtk.Widget:
        card = vbox(0, "rows-card")
        head = hbox(10, "row")
        head.append(Icon("file", 20, "blue"))
        col = vbox(1)
        col.set_hexpand(True)
        col.append(label(os.path.basename(g.paths[0]), "bold", ellipsize=True))
        col.append(label(f"{len(g.paths)} kopya · her biri {format_size(g.size)}", "muted small"))
        head.append(col)
        head.append(label(format_size(g.wasted), "value-link"))
        card.append(head)
        checks: list[tuple[Gtk.CheckButton, str, int]] = []
        for i, path in enumerate(g.paths):
            sep = Gtk.Box()
            sep.add_css_class("row-sep")
            card.append(sep)
            row = hbox(10, "row")
            check = Gtk.CheckButton()
            check.set_active(i > 0)          # en eski kopya saklanır, diğerleri önerilir
            check.connect("toggled", lambda c, grp=checks: self._on_toggle(c, grp))
            row.append(check)
            col2 = vbox(1)
            col2.set_hexpand(True)
            col2.append(label(os.path.basename(path), ellipsize=True))
            col2.append(label(os.path.dirname(path) + ("  ·  en eski, saklanması önerilir" if i == 0 else ""),
                              "muted small", ellipsize=True))
            row.append(col2)
            card.append(row)
            checks.append((check, path, g.size))
        self._groups.append(checks)
        return card

    def _on_toggle(self, check: Gtk.CheckButton, group) -> None:
        # Her grupta en az bir kopya kalmalı
        if all(c.get_active() for c, _p, _s in group):
            check.set_active(False)
            self.ctx.toast("Her gruptan en az bir kopya saklanmalı")
            return
        self._update_trash()

    def _selected(self) -> list[tuple[str, int]]:
        return [(p, s) for grp in self._groups for c, p, s in grp if c.get_active()]

    def _update_trash(self) -> None:
        sel = self._selected()
        self._trash_btn.set_visible(bool(self._groups))
        self._trash_btn.set_sensitive(bool(sel))
        self._trash_btn.set_label(
            f"Seçilenleri çöp kutusuna taşı ({len(sel)} · {format_size(sum(s for _p, s in sel))})" if sel
            else "Seçilenleri çöp kutusuna taşı")

    # ------------------------------------------------------------ çöp kutusu
    def _trash(self) -> None:
        sel = self._selected()
        if not sel:
            return
        self._trash_btn.set_sensitive(False)

        def work() -> list[str]:
            ok = []
            for path, _s in sel:
                try:
                    Gio.File.new_for_path(path).trash(None)
                    ok.append(path)
                except GLib.Error:
                    pass
            return ok

        def done(ok: list[str]) -> None:
            gone = set(ok)
            freed = sum(s for p, s in sel if p in gone)
            # Çöp kutusuna taşımak diski hemen boşaltmaz; geçmişe not olarak yazılır, toplama eklenmez.
            self.ctx.store.add_history("cleanup", 0, f"{len(ok)} yinelenen dosya çöp kutusuna taşındı ({format_size(freed)})")
            self.ctx.toast(f"{len(ok)} dosya çöp kutusuna taşındı" + (f", {len(sel) - len(ok)} taşınamadı" if len(ok) < len(sel) else ""))
            self._scan()   # listeyi yenile

        run_async(work, done)
