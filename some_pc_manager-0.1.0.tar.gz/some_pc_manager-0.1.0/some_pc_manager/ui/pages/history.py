"""Geçmiş: toplam kazanım, son 7 gün grafiği ve son işlemler."""
from __future__ import annotations

import datetime
import time

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk  # noqa: E402

from ...core.util import carbon_kg, format_ago, format_number, format_size
from ..icons import Icon
from ..page import Page
from ..widgets.bar import SmoothBar
from ..widgets.common import button, hbox, label, vbox

KINDS = {
    "boost": ("rocket", "RAM optimizasyonu"),
    "quick": ("rocket", "Hızlı optimizasyon (tepsi)"),
    "smart": ("sparkle", "Akıllı Hızlandırma"),
    "cleanup": ("broom", "Derin temizlik"),
    "health": ("health", "Sağlık kontrolü"),
}
WEEKDAYS = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"]
LIST_LIMIT = 30


class HistoryPage(Page):
    name = "history"
    tab = "home"
    parent = "home"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(10)
        self.append(label("Geçmiş", "title-1"))

        total = vbox(2, "card")
        total.append(label("Toplam temizlenen", "muted"))
        self._total = label("", "title-1")
        total.append(self._total)
        self._total_sub = label("", "muted small")
        total.append(self._total_sub)
        self.append(total)

        week = vbox(8, "card")
        week.append(label("Son 7 gün", "card-title"))
        self._week = vbox(6)
        week.append(self._week)
        self.append(week)

        self._list_title = label("Son işlemler", "card-title")
        self._list_title.set_margin_top(4)
        self.append(self._list_title)
        self._list = vbox(0, "rows-card")
        self.append(self._list)
        self._clear_btn = button("Geçmişi temizle", "secondary", self._clear)
        self._clear_btn.set_halign(Gtk.Align.START)
        self.append(self._clear_btn)

    def on_show(self, **kw) -> None:
        self._refresh()

    def _refresh(self) -> None:
        store = self.ctx.store
        total = int(store.get("total_cleaned"))
        hist = store.get("history")
        self._total.set_text(format_size(total, 2))
        self._total_sub.set_text(f"≈ {format_number(carbon_kg(total))} kg karbon emisyonu azaltıldı · {len(hist)} işlem")

        for box in (self._week, self._list):
            while (c := box.get_first_child()) is not None:
                box.remove(c)
        days = store.daily_totals(7)
        top = max((v for _d, v in days), default=0)
        if top <= 0:
            self._week.append(label("Bu hafta henüz temizlik yapılmadı.", "muted"))
        else:
            for iso, val in days:
                d = datetime.date.fromisoformat(iso)
                row = hbox(10)
                row.append(label(WEEKDAYS[d.weekday()], "muted history-day"))
                bar = SmoothBar(6, "green" if val else "blue")
                row.append(bar)
                size = label(format_size(val) if val else "—", "muted small")
                size.set_width_chars(8)
                size.set_xalign(1.0)
                row.append(size)
                self._week.append(row)
                GLib.idle_add(lambda b=bar, f=val / top: (b.animate_to(f, 900), False)[1])

        recent = list(reversed(hist))[:LIST_LIMIT]
        self._list_title.set_visible(bool(recent))
        self._list.set_visible(bool(recent))
        self._clear_btn.set_visible(bool(recent))
        now = time.time()
        for i, e in enumerate(recent):
            icon, title = KINDS.get(e.get("kind", ""), ("clock", "İşlem"))
            outer = vbox(0)
            if i:
                sep = Gtk.Box()
                sep.add_css_class("row-sep")
                outer.append(sep)
            row = hbox(12, "row")
            row.append(Icon(icon, 20, "blue"))
            col = vbox(1)
            col.set_hexpand(True)
            col.set_valign(Gtk.Align.CENTER)
            col.append(label(title, wrap=True))
            if e.get("note"):
                col.append(label(e["note"], "muted small", wrap=True))
            row.append(col)
            right = vbox(1)
            right.set_valign(Gtk.Align.CENTER)
            ago = label(format_ago(float(e.get("ts", now)), now), "muted small")
            ago.set_xalign(1.0)
            right.append(ago)
            if e.get("freed"):
                amount = label(format_size(e["freed"]), "value-link")
                amount.set_xalign(1.0)
                right.append(amount)
            row.append(right)
            outer.append(row)
            self._list.append(outer)

    def _clear(self) -> None:
        self.ctx.store.clear_history()
        self._refresh()
        self.ctx.toast("Geçmiş temizlendi")
