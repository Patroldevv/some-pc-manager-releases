"""Büyük dosyaları bul ve çöp kutusuna taşı."""
from __future__ import annotations

import datetime
import os
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from ...core import largefiles
from ...core.util import format_size
from ..icons import Icon
from ..page import Page
from ..tasks import call_ui, run_async
from ..widgets.bar import SmoothBar
from ..widgets.common import Segmented, button, hbox, label, scrolled, vbox

SIZES = [("100", "100 MB"), ("500", "500 MB"), ("1024", "1 GB")]


class LargeFilesPage(Page):
    name = "largefiles"
    tab = "storage"
    parent = "storage"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.set_spacing(12)
        self._root = str(Path.home())
        self._cancel = threading.Event()
        self._token = 0
        self._checks: list[tuple[Gtk.CheckButton, largefiles.BigFile, Gtk.Widget]] = []
        self._pulse = 0

        self.append(label("Büyük dosyalar", "title-1"))
        self._folder_btn = Gtk.Button()
        self._folder_btn.add_css_class("secondary")
        self._folder_btn.set_cursor_from_name("pointer")
        fh = hbox(8)
        fh.append(Icon("folder", 16))
        self._folder_lbl = label("", ellipsize=True)
        self._folder_lbl.set_hexpand(True)
        fh.append(self._folder_lbl)
        self._folder_btn.set_child(fh)
        self._folder_btn.connect("clicked", lambda *_: self._pick_folder())
        self.append(self._folder_btn)

        row = hbox(8)
        self._seg = Segmented(SIZES, "500", lambda _k: None)
        self._seg.set_hexpand(True)
        self._seg.set_halign(Gtk.Align.START)
        row.append(self._seg)
        self._scan_btn = button("Tara", "primary", self._scan)
        row.append(self._scan_btn)
        self.append(row)
        self._bar = SmoothBar(5)
        self._bar.set_visible(False)
        self.append(self._bar)
        self._status = label("", "muted", ellipsize=True)
        self.append(self._status)

        self._list = vbox(0, "rows-card")
        self._list.set_visible(False)
        self.append(self._list)
        self._trash_btn = button("Çöp kutusuna taşı", "secondary", self._trash)
        self._trash_btn.set_visible(False)
        self.footer = self._trash_btn

    def on_show(self, root: str | None = None, **kw) -> None:
        if root:
            self._root = str(Path.home()) if root == "/" else root
        self._folder_lbl.set_text(self._root)
        self._reset()

    def on_suspend(self) -> None:   # pencere gizlenirken süren tarama/işlem iptal edilmez
        pass

    def on_resume(self) -> None:
        pass

    def on_hide(self) -> None:
        self._cancel.set()
        self._stop_pulse()
        self._token += 1

    def _reset(self) -> None:
        self._cancel.set()
        self._token += 1
        self._stop_pulse()
        self._bar.set_visible(False)
        self._status.set_text("")
        self._trash_btn.set_visible(False)
        self._clear()
        self._scan_btn.set_label("Tara")
        self._scan_btn.set_sensitive(True)

    def _clear(self) -> None:
        while (c := self._list.get_first_child()) is not None:
            self._list.remove(c)
        self._checks.clear()
        self._list.set_visible(False)

    def _pick_folder(self) -> None:
        dlg = Gtk.FileDialog()
        dlg.set_title("Taranacak klasörü seç")
        dlg.set_initial_folder(Gio.File.new_for_path(self._root))

        def done(d, res) -> None:
            try:
                f = d.select_folder_finish(res)
            except GLib.Error:
                return
            if f and f.get_path():
                self._root = f.get_path()
                self._folder_lbl.set_text(self._root)

        dlg.select_folder(self.get_root(), None, done)

    # ------------------------------------------------------------ tarama
    def _start_pulse(self) -> None:
        self._bar.set_visible(True)
        self._bar.set_indeterminate(True)
        self._pulse = 1

    def _stop_pulse(self) -> None:
        if self._pulse:
            self._bar.set_indeterminate(False)
            self._pulse = 0

    def _scan(self) -> None:
        if self._scan_btn.get_label() == "İptal":
            self._cancel.set()
            return
        self._reset()
        self._cancel = threading.Event()
        token, cancel, root = self._token, self._cancel, self._root
        min_bytes = int(self._seg.value) * 1024**2
        self._scan_btn.set_label("İptal")
        self._start_pulse()

        def progress(path: str) -> None:
            call_ui(lambda: token == self._token and self._status.set_text(path))

        def done(files: list[largefiles.BigFile]) -> None:
            if token != self._token:
                return
            self._stop_pulse()
            self._bar.set_visible(False)
            self._scan_btn.set_label("Tara")
            self._fill(files, cancel.is_set())

        run_async(lambda: largefiles.find_large(root, min_bytes, 100, progress, cancel), done,
                  lambda _e: self._reset())

    def _fill(self, files: list[largefiles.BigFile], cancelled: bool) -> None:
        if not files:
            self._status.set_text("İptal edildi" if cancelled else "Bu boyutta büyük dosya bulunamadı")
            return
        total = sum(f.size for f in files)
        self._status.set_text(f"{len(files)} dosya · toplam {format_size(total)}")
        for i, f in enumerate(files):
            outer = vbox(0)
            if i:
                sep = Gtk.Box()
                sep.add_css_class("row-sep")
                outer.append(sep)
            row = hbox(10, "row")
            check = Gtk.CheckButton()
            check.connect("toggled", lambda *_: self._update_trash())
            row.append(check)
            col = vbox(1)
            col.set_hexpand(True)
            col.append(label(os.path.basename(f.path), "bold", ellipsize=True))
            date = datetime.datetime.fromtimestamp(f.mtime).strftime("%Y/%m/%d")
            col.append(label(f"{os.path.dirname(f.path)} · {date}", "muted small", ellipsize=True))
            row.append(col)
            row.append(label(format_size(f.size), "value-link"))
            outer.append(row)
            self._list.append(outer)
            self._checks.append((check, f, outer))
        self._list.set_visible(True)
        self._update_trash()

    def _update_trash(self) -> None:
        sel = [f for c, f, _w in self._checks if c.get_active()]
        self._trash_btn.set_visible(bool(self._checks))
        self._trash_btn.set_sensitive(bool(sel))
        self._trash_btn.set_label(
            f"Çöp kutusuna taşı ({len(sel)} · {format_size(sum(f.size for f in sel))})" if sel
            else "Çöp kutusuna taşı")

    # ------------------------------------------------------------ çöp kutusu
    def _trash(self) -> None:
        sel = [(f, w) for c, f, w in self._checks if c.get_active()]
        if not sel:
            return
        self._trash_btn.set_sensitive(False)

        def work() -> list[str]:
            ok = []
            for f, _w in sel:
                try:
                    Gio.File.new_for_path(f.path).trash(None)
                    ok.append(f.path)
                except GLib.Error:
                    pass
            return ok

        def done(ok: list[str]) -> None:
            gone = set(ok)
            for f, w in sel:
                if f.path in gone:
                    w.set_visible(False)
                    self._checks = [t for t in self._checks if t[1].path != f.path]
            self._update_trash()
            failed = len(sel) - len(ok)
            self.ctx.toast(f"{len(ok)} dosya çöp kutusuna taşındı" + (f", {failed} taşınamadı" if failed else ""))

        run_async(work, done)
