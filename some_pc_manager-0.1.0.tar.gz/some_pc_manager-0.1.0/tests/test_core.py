import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

from some_pc_manager.core import apps, autostart, boost, duplicates, cleaner, diskusage, largefiles, metrics, privileged, protection, sense, startup, sysinfo, util
from some_pc_manager.core.store import Store

ROOT = Path(__file__).resolve().parent.parent


class IsolatedHome(unittest.TestCase):
    """Her test için sahte HOME/XDG dizinleri: gerçek kullanıcı verisine dokunulmaz."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="spm-test-")
        base = Path(self.tmp.name)
        self.home = base / "home"
        self.home.mkdir()
        self._saved = dict(os.environ)
        os.environ["HOME"] = str(self.home)
        os.environ["XDG_CACHE_HOME"] = str(self.home / ".cache")
        os.environ["XDG_CONFIG_HOME"] = str(self.home / ".config")
        os.environ["XDG_DATA_HOME"] = str(self.home / ".local" / "share")
        os.environ["XDG_STATE_HOME"] = str(self.home / ".local" / "state")
        os.environ["XDG_CONFIG_DIRS"] = str(base / "etc-xdg")
        self.cache = self.home / ".cache"
        self.cache.mkdir()

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._saved)
        self.tmp.cleanup()

    def write(self, path: Path, data: bytes = b"x" * 4096, age_days: float = 0) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        if age_days:
            t = time.time() - age_days * 86400
            os.utime(path, (t, t))
        return path


class UtilTests(unittest.TestCase):
    def test_format_size(self):
        self.assertEqual(util.format_size(0), "0 B")
        self.assertEqual(util.format_size(1536), "1,5 KB")
        self.assertEqual(util.format_size(1024**3 * 2), "2,0 GB")

    def test_parse_size(self):
        self.assertEqual(util.parse_size("200M"), 200 * 1024**2)
        self.assertEqual(util.parse_size("1.5 GiB"), int(1.5 * 1024**3))
        self.assertEqual(util.parse_size("junk"), 0)

    def test_duration_and_carbon(self):
        self.assertEqual(util.format_duration(10.4), "10 sn")
        self.assertEqual(util.format_duration(125), "2 dk 5 sn")
        self.assertAlmostEqual(util.carbon_kg(int(10.24 * 1024**3)), 2.56, places=2)


class SysinfoTests(unittest.TestCase):
    def test_meminfo(self):
        m = sysinfo.parse_meminfo("MemTotal:  1000 kB\nMemAvailable:  250 kB\n")
        self.assertEqual(m.total, 1000 * 1024)
        self.assertEqual(m.used, 750 * 1024)
        self.assertAlmostEqual(m.percent, 75.0)

    def test_analyze(self):
        text = "Startup finished in 7.2s (firmware) + 3.1s (loader) + 2.5s (kernel) + 1min 4.5s (userspace) = 1min 17.3s \n"
        self.assertAlmostEqual(sysinfo.parse_analyze(text), 77.3)
        self.assertIsNone(sysinfo.parse_analyze("nothing"))
        self.assertAlmostEqual(sysinfo.parse_duration("850ms"), 0.85)


class CleanerTests(IsolatedHome):
    def test_guard_rejects_dangerous_roots(self):
        for bad in (Path("/"), self.home, Path("/etc"), Path("/usr/share")):
            with self.assertRaises(ValueError, msg=str(bad)):
                list(cleaner.iter_files(bad)) if bad.is_dir() else cleaner._guard(bad)
            with self.assertRaises(ValueError):
                cleaner._guard(bad)

    def test_only_regular_files_and_symlinks_not_followed(self):
        root = self.cache / "thumbnails"
        self.write(root / "a.png")
        outside = self.home / "keep"
        self.write(outside / "important.txt")
        (root / "link").symlink_to(outside)
        sock = root / "s.sock"
        srv = socket.socket(socket.AF_UNIX)
        srv.bind(str(sock))
        try:
            files = {Path(p).name for p, _ in cleaner.iter_files(root)}
        finally:
            srv.close()
        self.assertIn("a.png", files)
        self.assertNotIn("s.sock", files)
        self.assertNotIn("important.txt", files)

    def test_clean_thumbnails_leaves_outside_alone(self):
        self.write(self.cache / "thumbnails" / "large" / "a.png")
        keep = self.write(self.home / "Documents" / "doc.txt")
        res = cleaner._clean_user("thumbnails", "deep")
        self.assertEqual(res.status, "cleaned")
        self.assertGreater(res.freed, 0)
        self.assertFalse((self.cache / "thumbnails" / "large" / "a.png").exists())
        self.assertTrue(keep.exists())

    def test_user_cache_keeps_protected_and_browser_dirs(self):
        self.write(self.cache / "pip" / "wheel", age_days=3)
        self.write(self.cache / "huggingface" / "model.bin", age_days=30)
        self.write(self.cache / "mozilla" / "cache2" / "e", age_days=30)
        cleaner._clean_user("user_cache", "deep")
        self.assertFalse((self.cache / "pip" / "wheel").exists())
        self.assertTrue((self.cache / "huggingface" / "model.bin").exists())
        self.assertTrue((self.cache / "mozilla" / "cache2" / "e").exists())
        cleaner._clean_user("browser_cache", "deep")
        self.assertFalse((self.cache / "mozilla" / "cache2" / "e").exists())

    def test_min_age_respected_in_boost_mode(self):
        old = self.write(self.cache / "app" / "old", age_days=10)
        new = self.write(self.cache / "app" / "new", age_days=1)
        cleaner._clean_user("user_cache", "boost")
        self.assertFalse(old.exists())
        self.assertTrue(new.exists())

    def test_scan_matches_clean(self):
        for i in range(3):
            self.write(self.cache / "thumbnails" / f"{i}.png", b"y" * 8192)
        scanned = cleaner._scan_user("thumbnails", "deep")
        freed = cleaner._clean_user("thumbnails", "deep").freed
        self.assertEqual(scanned, freed)
        self.assertGreater(scanned, 0)

    def test_trash_cleanup(self):
        trash = self.home / ".local" / "share" / "Trash"
        self.write(trash / "files" / "f.txt")
        self.write(trash / "info" / "f.txt.trashinfo", b"[Trash Info]")
        res = cleaner._clean_user("trash", "deep")
        self.assertEqual(res.status, "cleaned")
        self.assertFalse((trash / "files" / "f.txt").exists())

    def test_parsers(self):
        self.assertEqual(cleaner.parse_paccache("==> finished dry run: 3 candidates (disk space saved: 183.50 MiB)"),
                         int(183.5 * 1024**2))
        self.assertEqual(cleaner.parse_paccache("==> no candidate packages found for pruning"), 0)
        self.assertEqual(cleaner.parse_journal_usage("Archived and active journals take up 1.4G in the file system."),
                         int(1.4 * 1024**3))

    def test_default_selection(self):
        self.assertFalse(cleaner.TARGETS["trash"].default_selected)
        self.assertTrue(cleaner.TARGETS["tmp"].default_selected)


class MountsAndSenseTests(unittest.TestCase):
    def test_parse_mounts(self):
        text = ("/dev/nvme0n1p2 / btrfs rw 0 0\n/dev/nvme0n1p2 /home btrfs rw 0 0\n"
                "/dev/nvme0n1p1 /boot/efi vfat rw 0 0\ntmpfs /tmp tmpfs rw 0 0\n"
                "/dev/sda1 /run/media/u/DISK ext4 rw 0 0\n")
        self.assertEqual(sysinfo.parse_mounts(text),
                         [("Yerel Disk (/)", "/"), ("DISK", "/run/media/u/DISK")])

    def test_sense_service_sets_pythonpath(self):
        svc = sense.render_service(ROOT)
        self.assertIn(f'PYTHONPATH={ROOT}', svc)
        self.assertIn("--auto-clean", svc)
        self.assertIn("OnCalendar=weekly", sense.TIMER_UNIT)


class MetricsTests(unittest.TestCase):
    def test_cpu_stat(self):
        a = metrics.parse_cpu_stat("cpu  100 0 50 800 50 0 0 0 0 0\ncpu0 1 1 1 1\n")
        self.assertEqual(a, (850, 1000))
        self.assertIsNone(metrics.parse_cpu_stat("intr 1"))

    def test_net_dev_skips_virtual(self):
        text = ("Inter-|   Receive\n face |bytes\n"
                "    lo: 999 1 0 0 0 0 0 0 999 1 0 0 0 0 0 0\n"
                "  eth0: 1000 1 0 0 0 0 0 0 400 1 0 0 0 0 0 0\n"
                "docker0: 5000 1 0 0 0 0 0 0 5000 1 0 0 0 0 0 0\n")
        self.assertEqual(metrics.parse_net_dev(text), (1000, 400))

    def test_format_rate_and_swap(self):
        self.assertEqual(metrics.format_rate(512), "512 B/sn")
        self.assertEqual(metrics.format_rate(1536 * 1024), "1,5 MB/sn")
        self.assertEqual(sysinfo.parse_swap("SwapTotal: 1000 kB\nSwapFree: 400 kB\n"), (1000 * 1024, 600 * 1024))


class DiskUsageTests(IsolatedHome):
    def test_children_sizes_sorted_and_symlinks_ignored(self):
        d = self.home / "data"
        self.write(d / "big" / "a.bin", b"0" * 40000)
        self.write(d / "big" / "sub" / "b.bin", b"0" * 40000)
        self.write(d / "small.txt", b"0" * 100)
        (d / "link").symlink_to(self.home)
        seen = []
        res = diskusage.scan_children(str(d), seen.append)
        self.assertEqual([e.name for e in res][0], "big")
        self.assertTrue(res[0].is_dir)
        self.assertGreaterEqual(res[0].size, 80000)
        self.assertLess(next(e for e in res if e.name == "link").size, 8192)  # bağ izlenmedi
        self.assertEqual(len(seen), 3)

    def test_cancel(self):
        ev = threading.Event()
        ev.set()
        self.assertEqual(diskusage.scan_children(str(self.home), cancel=ev), [])


class AutostartAndBlameTests(IsolatedHome):
    def test_autostart_roundtrip(self):
        self.assertFalse(autostart.is_enabled())
        self.assertTrue(autostart.enable())
        self.assertTrue(autostart.is_enabled())
        self.assertIn("--background", autostart.path().read_text())
        self.assertTrue(autostart.disable())
        self.assertFalse(autostart.is_enabled())

    def test_parse_blame(self):
        text = "1min 2.5s slow.service\n   850ms fast.service\n 12.0s mnt.mount\ngarbage\n"
        res = startup.parse_blame(text)
        self.assertEqual([u for u, _ in res], ["slow.service", "mnt.mount", "fast.service"])
        self.assertAlmostEqual(res[0][1], 62.5)


class BackgroundRulesTests(unittest.TestCase):
    def test_memory_alert_needs_sustained_high_usage_and_cooldown(self):
        from some_pc_manager.ui import background as bg
        now = 10_000.0
        self.assertFalse(bg.should_alert_memory(95, 2, now, 0))                 # yeterince uzun sürmedi
        self.assertFalse(bg.should_alert_memory(80, 5, now, 0))                 # eşik altında
        self.assertTrue(bg.should_alert_memory(95, 3, now, 0))
        self.assertFalse(bg.should_alert_memory(95, 9, now, now - 60))          # bekleme süresi dolmadı
        self.assertTrue(bg.should_alert_memory(95, 9, now + bg.MEM_COOLDOWN, now))

    def test_disk_alert(self):
        from some_pc_manager.ui import background as bg
        gb = 1024**3
        self.assertTrue(bg.should_alert_disk(100 * gb, 6 * gb, 1e6, 0))         # %6 boş
        self.assertTrue(bg.should_alert_disk(1000 * gb, 4 * gb, 1e6, 0))        # 5 GB altı
        self.assertFalse(bg.should_alert_disk(100 * gb, 50 * gb, 1e6, 0))
        self.assertFalse(bg.should_alert_disk(100 * gb, 6 * gb, 1000, 500))     # bekleme

    def test_smart_boost_schedule(self):
        from some_pc_manager.ui import background as bg
        self.assertFalse(bg.should_run_smart_boost(False, 1e9, 0))
        self.assertFalse(bg.should_run_smart_boost(True, 1000, 900))
        self.assertTrue(bg.should_run_smart_boost(True, 1e9, 0))
        self.assertTrue(bg.should_run_smart_boost(True, 900 + bg.SMART_INTERVAL, 900))

    def test_tray_pixmap_is_argb(self):
        from some_pc_manager.ui import tray
        w, h, data = tray.argb_pixmap(24)
        self.assertEqual(len(data), w * h * 4)
        self.assertTrue(any(data[i] > 0 for i in range(0, len(data), 4)))      # görünür piksel var


class HistoryTests(IsolatedHome):
    def test_history_totals_and_limit(self):
        s = Store(self.home / "state.json")
        now = time.time()
        s.add_history("boost", 1000, ts=now)
        s.add_history("cleanup", 500, ts=now - 86400)
        s.add_history("cleanup", 7, ts=now - 40 * 86400)         # pencere dışı
        days = s.daily_totals(7, now)
        self.assertEqual(len(days), 7)
        self.assertEqual(days[-1][1], 1000)
        self.assertEqual(days[-2][1], 500)
        for i in range(300):
            s.add_history("boost", 1)
        self.assertEqual(len(s.get("history")), Store.HISTORY_LIMIT)
        s.clear_history()
        self.assertEqual(s.get("history"), [])
        self.assertEqual(Store(self.home / "state.json").get("history"), [])

    def test_format_ago(self):
        self.assertEqual(util.format_ago(100, 130), "az önce")
        self.assertEqual(util.format_ago(0, 600), "10 dk önce")
        self.assertEqual(util.format_ago(0, 7200), "2 sa önce")
        self.assertEqual(util.format_ago(0, 86400 * 1.5), "dün")
        self.assertEqual(util.format_ago(0, 86400 * 4), "4 gün önce")

    def test_boost_summary(self):
        gb = 1024**3
        res = boost.BoostResult(temp_freed=50 * 1024**2, mem_before=sysinfo.Memory(8 * gb, 2 * gb),
                                mem_after=sysinfo.Memory(8 * gb, 2 * gb + 300 * 1024**2))
        text = boost.summarize(res)
        self.assertIn("50,0 MB geçici dosya temizlendi", text)
        self.assertIn("bellek kazanıldı", text)
        self.assertIn("bellek %7", text)
        self.assertIn("yoktu", boost.summarize(boost.BoostResult()))


class DuplicatesTests(IsolatedHome):
    def test_finds_identical_files_only(self):
        d = self.home / "data"
        same = b"A" * 5000
        a = self.write(d / "a.bin", same, age_days=5)
        b = self.write(d / "sub" / "b.bin", same, age_days=1)
        self.write(d / "c.bin", b"B" * 5000)                      # aynı boyut, farklı içerik
        self.write(d / "tiny.bin", b"A" * 10)                      # eşiğin altında
        os.link(a, d / "hardlink.bin")                              # sabit bağ: yinelenen sayılmaz
        (d / "symlink.bin").symlink_to(a)
        (d / ".cache").mkdir()
        self.write(d / ".cache" / "skip.bin", same)                 # atlanan dizin
        groups = duplicates.find_duplicates(str(d), min_bytes=1000)
        self.assertEqual(len(groups), 1)
        g = groups[0]
        self.assertEqual(g.size, 5000)
        names = [Path(p).name for p in g.paths]
        self.assertEqual(len(names), 2)                             # sabit bağ iki ad olsa da tek dosya sayıldı
        self.assertIn("b.bin", names)
        self.assertIn(names[0], ("a.bin", "hardlink.bin"))          # en eskisi önerilen 'saklanacak'
        self.assertEqual(g.wasted, 5000)

    def test_partial_hash_collision_resolved_by_full_hash(self):
        d = self.home / "data"
        head = b"X" * duplicates.PARTIAL_BYTES
        self.write(d / "p1.bin", head + b"1" * 2000)
        self.write(d / "p2.bin", head + b"2" * 2000)                # ilk 64 KB aynı, sonu farklı
        self.assertEqual(duplicates.find_duplicates(str(d), min_bytes=1000), [])

    def test_cancel(self):
        ev = threading.Event()
        ev.set()
        self.assertEqual(duplicates.find_duplicates(str(self.home), cancel=ev), [])


class PrivilegedTests(unittest.TestCase):
    def test_parse_output_ignores_unknown_actions(self):
        text = "\n".join([
            json.dumps({"action": "vacuum-journal", "ok": True, "freed": 5}),
            json.dumps({"action": "rm-rf", "ok": True, "freed": 9}),
            "not json",
        ])
        out = privileged.parse_output(text)
        self.assertEqual(set(out), {"vacuum-journal"})
        self.assertEqual(out["vacuum-journal"].freed, 5)

    def test_unknown_actions_filtered_before_exec(self):
        self.assertEqual(privileged.run(["rm -rf /", "bogus"]), {})

    def test_helper_rejects_without_root_or_unknown(self):
        helper = ROOT / "some_pc_manager" / "data" / "some-pc-manager-helper"
        r = subprocess.run([sys.executable, str(helper), "rm-rf"], capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse(json.loads(r.stdout.splitlines()[0])["ok"])

    def test_helper_only_whitelisted_actions(self):
        src = (ROOT / "some_pc_manager" / "data" / "some-pc-manager-helper").read_text()
        ns: dict = {"__name__": "helper"}
        exec(compile(src, "helper", "exec"), ns)
        self.assertEqual(set(ns["ACTIONS"]), set(privileged.ACTIONS))


class StartupTests(IsolatedHome):
    def setUp(self):
        super().setUp()
        self.sysdir = Path(os.environ["XDG_CONFIG_DIRS"]) / "autostart"
        self.write(self.sysdir / "foo.desktop",
                   b"[Desktop Entry]\nType=Application\nName=Foo\nExec=foo\n")

    def test_disable_and_enable_system_entry(self):
        (entry,) = startup.list_autostart()
        self.assertTrue(entry.enabled)
        startup.set_autostart(entry, False)
        (entry,) = startup.list_autostart()
        self.assertFalse(entry.enabled)
        self.assertTrue((startup.user_dir() / "foo.desktop").exists())
        startup.set_autostart(entry, True)
        (entry,) = startup.list_autostart()
        self.assertTrue(entry.enabled)
        self.assertFalse((startup.user_dir() / "foo.desktop").exists())  # geçersiz kılma kaldırıldı
        self.assertTrue((self.sysdir / "foo.desktop").exists())          # sistem dosyası bozulmadı

    def test_user_entry_toggle_keeps_file(self):
        self.write(startup.user_dir() / "bar.desktop", b"[Desktop Entry]\nType=Application\nName=Bar\nExec=bar\n")
        e = next(x for x in startup.list_autostart() if x.id == "bar.desktop")
        startup.set_autostart(e, False)
        e = next(x for x in startup.list_autostart() if x.id == "bar.desktop")
        self.assertFalse(e.enabled)
        startup.set_autostart(e, True)
        e = next(x for x in startup.list_autostart() if x.id == "bar.desktop")
        self.assertTrue(e.enabled)

    def test_parse_unit_files(self):
        text = "a.service enabled enabled\nb.service disabled enabled\nc.socket enabled enabled\nd@.service enabled -\n"
        names = {s.name: s.enabled for s in startup.parse_unit_files(text)}
        self.assertEqual(names, {"a.service": True, "b.service": False, "d@.service": True})

    def test_service_name_validation(self):
        self.assertFalse(startup.set_service("x; rm -rf /", True))


class AppsTests(IsolatedHome):
    def test_parse_desktop_and_exec(self):
        p = self.write(self.home / "a.desktop",
                       b"[Desktop Entry]\nType=Application\nName=Uyg\nName[tr]=Uygulama\nExec=env FOO=1 /usr/bin/Thing %U\nIcon=thing\n")
        entry, flags = apps.parse_desktop(p)
        self.assertEqual(entry.name, "Uygulama")
        self.assertEqual(entry.exec_name, "thing")
        self.assertFalse(flags["nodisplay"])

    def test_protected_pids_contains_self(self):
        self.assertIn(os.getpid(), apps.protected_pids())


class ProtectionTests(unittest.TestCase):
    def test_parsers(self):
        self.assertEqual(protection.parse_clam_line("/x/y: Eicar-Test-Signature FOUND\n"), "/x/y: Eicar-Test-Signature")
        self.assertIsNone(protection.parse_clam_line("Scanning /x/y"))
        self.assertEqual(protection.count_lines("a\n\nb\n"), 2)


class LargeFilesTests(IsolatedHome):
    def test_finds_top_n_sorted(self):
        d = self.home / "data"
        self.write(d / "a.bin", b"0" * 3000)
        self.write(d / "sub" / "b.bin", b"0" * 5000)
        self.write(d / "c.bin", b"0" * 100)
        res = largefiles.find_large(str(d), 1000, limit=5)
        self.assertEqual([Path(f.path).name for f in res], ["b.bin", "a.bin"])

    def test_cancel(self):
        ev = threading.Event()
        ev.set()
        self.assertEqual(largefiles.find_large(str(self.home), 1, cancel=ev), [])


class StoreTests(IsolatedHome):
    def test_roundtrip_and_corrupt_file(self):
        path = self.home / "state.json"
        s = Store(path)
        s.add_cleaned(1000)
        s.set_setting("theme", "dark")
        s2 = Store(path)
        self.assertEqual(s2.get("total_cleaned"), 1000)
        self.assertEqual(s2.setting("theme"), "dark")
        path.write_text("{broken")
        self.assertEqual(Store(path).get("total_cleaned"), 0)


if __name__ == "__main__":
    unittest.main()
