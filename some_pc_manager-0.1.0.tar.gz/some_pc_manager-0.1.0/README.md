# Some PC Manager

Microsoft PC Manager'dan esinlenen, Linux için kompakt ve akıcı bir PC yönetim aracı.
GTK4 + libadwaita (Python). Wayland (Hyprland dahil) ve X11'de çalışır.

## Özellikler
- **Ana Sayfa:** bellek/geçici dosya ölçümü, tek tıkla **Hızlandır**, sağlık kontrolü, süreçler, derin temizlik ve açılış süresi kısayolları.
- **Sağlık Kontrolü:** gereksiz dosyalar, başlangıç öğeleri, güvenlik duvarı ve güncellemeleri tarar; temizlenebilenleri düzeltir.
- **Depolama:** derin temizlik (önbellek, tarayıcı, çöp, paket önbelleği, journal), büyük dosya bulucu (çöp kutusuna taşır), haftalık otomatik temizlik (systemd kullanıcı zamanlayıcısı).
- **Uygulamalar:** çalışan uygulamalar (RAM/CPU, sonlandır), başlangıç öğeleri ve systemd kullanıcı hizmetleri (aç/kapat), yüklü uygulamalar.
- **Koruma:** güvenlik duvarı ve güncelleme durumu, ClamAV ile hızlı tarama (kuruluysa).
- **Canlı izleme:** CPU (sıcaklık, yük), bellek/takas ve ağ için akıcı kayan grafikler.
- **Disk analizi:** hangi klasör ne kadar yer kaplıyor; çubuklarla gösterir, klasörlere inilir (salt okunur).
- **Açılış analizi:** Başlangıç sekmesinde açılışı en çok geciktiren servisler.
- **Yinelenen dosyalar:** içeriği birebir aynı dosyaları bulur (boyut → kısmi → tam özet); her gruptan en az bir kopya saklanır, fazlalar çöp kutusuna taşınır.
- **Geçmiş:** toplam kazanım, son 7 gün grafiği ve yapılan işlemler (RAM optimizasyonu, temizlik, sağlık kontrolü).
- **Araç Kutusu, Ayarlar** (açık/koyu tema, animasyonları azalt), **Geri Bildirim**.

## Arka planda çalışma
Pencereyi kapatınca uygulama tepside çalışmaya devam eder (Ayarlar'dan kapatılabilir):
- **Tepsi simgesi** (StatusNotifierItem): sol tık pencereyi açar/gizler, orta tık pencere açmadan hızlandırır.
- **Akıllı bildirimler:** bellek 3 dakika boyunca %90'ın üstünde kalırsa ya da disk dolmak üzereyse uyarır. Yalnızca bildirim gönderir, kendiliğinden hiçbir şey silmez.
- **İşlem sonucu bildirimleri:** RAM optimizasyonu, temizlik ve sağlık kontrolü bitince masaüstü bildirimi gönderir; bildirime tıklayınca Geçmiş açılır.
- **Akıllı Hızlandırma (isteğe bağlı):** her 6 saatte bir yalnızca eski geçici dosyaları temizler ve sonucu bildirir.
- **Oturum açılışında başlat:** `some-pc-manager --background` ile pencere açmadan başlar.
- Uygulamayı yeniden başlatmak çalışan örneği öne getirir. Tamamen çıkmak için Ayarlar > **Uygulamadan çık**.

## Çalıştırma
Gereksinim: `python`, `python-gobject`, `gtk4`, `libadwaita` (CachyOS/Arch'ta genelde hazır).

```bash
./run.sh
```

Sistem geneli kurulum (polkit politikası ve root'a ait yardımcı betikle):

```bash
sudo ./packaging/install.sh
```

Kaldırmak için `sudo ./packaging/install.sh --uninstall`.

İsteğe bağlı: `pacman-contrib` (paket önbelleği için `paccache`), `clamav` (virüs taraması).

## Güvenlik
- Yalnızca beyaz listedeki yollar temizlenir (`~/.cache` alt dizinleri, küçük resimler, çöp kutusu, `/tmp` içindeki size ait 2 günden eski dosyalar). Yalnızca normal dosyalar silinir; sembolik bağlar izlenmez.
- Yetki gerektiren işler (paket önbelleği, journal, RAM önbelleği) `pkexec` ile tek bir yardımcı betik üzerinden yapılır; yalnızca 3 sabit eylemi kabul eder, parolayı polkit sorar.
- Büyük dosyalar yalnızca çöp kutusuna taşınır. Süreç sonlandırma onay ister.

## Hyprland
Uygulamanın sabit 415×605 boyutlu, kayan (floating) bir pencere olması gerekir. Kendi kuralın yoksa ekle
(sınıf adı `dev.somepcmanager.PCManager`):

```
# Eski (hyprlang) yapılandırma
windowrule = float, class:^(dev.somepcmanager.PCManager)$
windowrule = size 415 605, class:^(dev.somepcmanager.PCManager)$
windowrule = center, class:^(dev.somepcmanager.PCManager)$
```

Pencere yarı saydam çizilir; Hyprland'de `decoration:blur` açıksa otomatik algılanıp bulanık (mica benzeri) görünür, kapalıysa neredeyse opak çizilir.

## Derleme
Wheel, sdist ve pacman paketi (`.pkg.tar.zst`) üretir; testleri de çalıştırır:

```bash
./scripts/build.sh ../some-pc-manager      # çıktı dizini
sudo pacman -U ../some-pc-manager/some-pc-manager-*.pkg.tar.zst
```

Bu depo yalnızca kaynak kodu içerir; derlenmiş sürümler ayrı `some-pc-manager` deposunda tutulur.

## Geliştirme
```bash
python3 -m unittest discover -s tests -t .
```
Tasarım: `docs/superpowers/specs/2026-11-01-some-pc-manager-design.md`
